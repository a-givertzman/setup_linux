# s7-data-server
The wrapper for snap7 python plugin with socket server for frontend connections

git branch -m initial master
git fetch origin
git branch -u origin/master master
git remote set-head origin -a