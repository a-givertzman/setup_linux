import logging
import threading
import src.app_logger as app_logger
from time import sleep
from queue import Queue
from typing import Generic, TypeVar
from src.domain.core.result import CancelResult
from src.domain.core.locked_iterator import LockedIterator

log = app_logger.get_logger('MergeQueues', level = logging.INFO)

T = TypeVar('T')
class MergeQueues(Generic[T]):
    '''Merges incoming Queue objects into one stream (Generator) if stream() method was called
        or into Queue object which contains data of all incoming queues if queue() method was called'''
    def __init__(self,
        queues: list[Queue[T]],
        threadSafe: bool = False,
    ) -> None:
        self.__cancel = False
        self.__isActive = False
        self.__queues = queues
        self.__threadSafe = threadSafe

    @property
    def stream(self):
        '''Returns the stream (Generator) object of [DSDataPoint]'''
        if self.__threadSafe:
            return LockedIterator(self.__read())
        else:
            return self.__read()

    def __read(self):
        log.info(f'[started in thread: {threading.current_thread().name}')
        self.__isActive = True
        while not self.__cancel:
            # if threading.current_thread().name != 'DSDataSource.Thread':
            #     log.info(f'thread {threading.current_thread().name} count of queues: {len(self.__queues)}')
            for queue in self.__queues:
                if self.__cancel: 
                    break
                if not queue.empty():
                    event = queue.get(timeout = 0.01)
                    queue.task_done()
                    if threading.current_thread().name != 'DSDataSource.Thread':
                        log.debug(f'thread {threading.current_thread().name} event: {event}')
                    yield event
                    # if threading.current_thread().name != 'DSDataSource.Thread':
                    #     log.info(f'thread {threading.current_thread().name} yield event done')
            sleep(1 / 1000)
        self.__isActive = False
        log.info(f'exit')

    def addQueue(self, queue: Queue[T]):
        '''Adds new Queue object to merged'''
        self.__queues.append(queue)
    
    def removeQueue(self, queue: Queue[T]):
        '''Removes Queue object from merged'''
        self.__queues.remove(queue)

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        self.__cancel = True
        return CancelResult(
            done = True,
        )

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')
