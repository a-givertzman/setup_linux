import logging
import src.app_logger as app_logger
from typing import Callable, Generic, TypeVar
from src.domain.core.stream.stream import Stream
from src.domain.core.stream.stream_subscription import StreamSubscription

log = app_logger.get_logger('StreamController', level = logging.INFO)

T = TypeVar('T')
class StreamController(Generic[T]):
    '''
    Holds simple stream object, 
        provides to add data events to the stream, 
        provides to add error events to the stream, 
        provides to close stream, 
    '''
    def __init__(self,
        onPause: Callable = None,
        onResume: Callable = None,
        onCancel: Callable = None,
        onListen: Callable = None,
    ) -> None:
        assert callable(onPause) or onPause == None
        assert callable(onResume) or onResume == None
        assert callable(onCancel) or onCancel == None
        assert callable(onListen) or onListen == None
        self.done = True
        self.__hasListener = False
        self.isClosed = False
        self.isPaused = False
        self.onPause = onPause
        self.onResume = onResume
        self.onCancel = onCancel
        self.onListen = onListen
        # self.__buffer = queue.Queue()
        self.stream = Stream[T](
            onListen = self.__onListen,
        )

    def __onListen(self, subscription: StreamSubscription):
        self.__subscription = subscription
        if (callable(self.onListen)):
            self.onListen()

    def add(self, event: T = None):
        if (not self.isClosed):
            self.stream.sink.send(event)

    def addError(self, error: Exception) -> None:
        if (not self.isClosed):
            self.stream.sink.send(error)

    def close(self):
        self.isClosed = True
        self.__subscription.cancel()