from typing import Any, Callable, Generic, TypeVar

T = TypeVar('T')
class StreamSubscription(Generic[T]):
    def __init__(self,
        onData: Callable = None,
        onDone: Callable = None,
        onError: Callable = None,
    ) -> None:
        self.isPaused = False
        self.__isCanceled = False
        self.__done = False
        self.__onData = onData
        self.__onDone = onDone
        self.__onError = onError
    def cancel(self):
        self.__isCanceled = True
        self.onDone()
    def onData(self, data: T = None):
        if (not self.__done and callable(self.__onData)):
            self.__onData(data)
    def onDone(self):
        if (not self.__done):
            self.__done = True
            if (callable(self.__onDone)):
                self.__onDone()
    def onError(self, error: Exception = None):
        if (not self.__done and callable(self.__onError)):
            self.__onError(error)
    def pause(self):
        if (self.__isCanceled):
            return
        self.isPaused = True
    def resume(self):
        if (self.isPaused):
            self.isPaused = False
    def isCanceled(self):
        return self.__isCanceled