import logging
import src.app_logger as app_logger
from typing import Generic, TypeVar
from src.domain.core.stream.stream import Stream
from src.domain.core.stream.stream_controller import StreamController

log = app_logger.get_logger('StreamMerged', level = logging.DEBUG)

T = TypeVar('T')
class StreamMerged(Generic[T]):
    '''
    Объединяет несколько потоков [list[Stream[T]]] в единый поток [Stream[T]]
    '''
    def __init__(self,
        streams: list[Stream[T]] = [],
    ) -> None:
        self.__streams = streams
        self.__streamController = StreamController[T]()

    def __onListen(self):
        for stream in self.__streams:
            if not stream.hasListener:
                stream.listen(
                    onData = self.__onData,
                    onError = self.__onError,
                    onDone = self.__onDone,
                )

    def addStream(self, stream: Stream[T]):
        stream.listen(
            onData = self.__onData,
            onError = self.__onError,
            onDone = self.__onDone,
        )
        self.__streams.append(stream)
        log.debug(f'added new stream: {stream}')
        log.debug(f'currently has streams: {len(self.__streams)}')

    def removeStream(self, stream: Stream[T]):
        try:
            self.__streams.remove(stream)
            log.debug(f'removed new stream: {stream}')
            stream = None
        except:
            log.error(f'error removing stream: {stream}')
        log.debug(f'currently has streams: {len(self.__streams)}')

    @property
    def stream(self):
        self.__streamController.onListen = self.__onListen
        return self.__streamController.stream

    def __onData(self, event: T):
        log.debug(f'event: {event}')
        self.__streamController.add(event)
    
    def __onError(self, error: Exception):
        self.__streamController.addError(error)

    def __onDone(self):
        self.__streamController.close()
