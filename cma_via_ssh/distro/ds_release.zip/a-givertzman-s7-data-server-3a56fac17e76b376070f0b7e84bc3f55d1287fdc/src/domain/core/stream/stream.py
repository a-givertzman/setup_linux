# import queue
import logging
import src.app_logger as app_logger
from typing import Generator, Callable, Generic, Iterable, TypeVar
from src.domain.core.stream.stream_subscription import StreamSubscription

log = app_logger.get_logger('Stream', level = logging.INFO)

T = TypeVar('T')
class Stream(Generic[T]):
    def __init__(self, 
        onListen: Callable = None,
    ) -> None:
        assert callable(onListen) or onListen == None, 'onListen should bee callable or None'
        self.__cancelOnError = False
        self.hasListener = False
        # self.__buffer = queue.Queue()
        self.sink = self.__sink()
        self.sink.send(None)
        self.__onListen = onListen
    
    @classmethod
    def fromIterable(self, elements: Iterable[T]):
        __stream = None
        def __onListen(_):
            for e in elements:
                __stream.sink.send(e)
        __stream = Stream(onListen=__onListen)
        return __stream

    def listen(self,
        onData: Callable = None,
        onError: Callable = None,
        onDone: Callable = None,
        cancelOnError: bool = None,
    ):
        '''
        Args:
            onData(event: T): Callable, \n
            onError(error: Exception): Callable, \n
            onDone(event: T): Callable, \n
            cancelOnError: bool - if true stream will be auto canceled on Exception occurs, 
        ________________________\n
        Returns: 
            subscription: StreamSubscription
        '''
        self.__subscription = StreamSubscription(
            onDone = onDone,
            onData = onData,
            onError = onError,
        )
        self.hasListener = True
        self.__cancelOnError = cancelOnError
        if (callable(self.__onListen)):
            try:
                self.__onListen(self.__subscription)
            except Exception as error:
                log.error(f'error: {error}')
        return self.__subscription

    def __sendError(self, error: Exception):
        self.__subscription.onError(error)
        # if (self.hasListener):
        #     try:
        #         self.__subscription.onError(error)
        #     except Exception as error:
        #         log.warning(f'error: {error}')

    def __sendData(self, event):
        self.__subscription.onData(event)
            # try:
            #     self.__subscription.onData(event)
            # except Exception as error:
            #     log.warning(f'error: {error}')
            #     self.__sendError(error)

    def __sink(self) -> Generator:
        while True:
            # try:
            # log.info(f'yield')
            event = yield
            # log.info(f'event: {event}')
            if (self.hasListener):
                if (isinstance(event, Exception)):
                    self.__sendError(event)
            #     if (self.__cancelOnError):
            #         break
                else:
                    self.__sendData(event)
            # except Exception as error:
            #     log.warning(f'error: {error}')
        self.__subscription.onDone()

    def __del__(self):
        try:
            self.sink.close()
        except: pass