class StreamEvent:
    def __init__(self) -> None:
        pass