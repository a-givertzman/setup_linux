from typing import Generic, TypeVar

from domain.core.stream.stream import Stream

T = TypeVar('T')
class StreamSink(Generic[T]):
    def __init__(self,
        stream: Stream = None
    ) -> None:
        assert stream != None 
        assert stream is Stream
        self.done = False
        self.__stream = stream
    def add(self, event: T) -> None:
        self.__stream.add()
    def addError(self, error: Exception) -> None:
        ...
    def close(self):
        ...