import logging
import src.app_logger as app_logger
from abc import abstractclassmethod

log = app_logger.get_logger('ThresholdPli', level = logging.INFO)


class Threshold:
    '''Interface for Treshold classes'''
    @abstractclassmethod
    def y(self, x: float) -> float:  # type: ignore
        pass

class ThresholdPli(Threshold):
    '''Treshold based on Piecewise linear interpolation'''
    def __init__(self,
        conf: dict[str, float],
    ) -> None:
        self.__conf: dict[int, dict[str, float]] = {}
        self.__len = len(conf)
        index = 0
        log.debug(f'conf: {conf}')
        for xi, yi in conf.items():
            self.__conf.update({
                index: {
                    'x': float(xi),
                    'y': float(yi),
                }
            })
            index += 1
        log.debug(f'self.__conf: {self.__conf}')

    def y(self, x: float) -> float:
        x1 = self.__conf[0]['x']
        y1 = self.__conf[0]['y']
        index = 1
        while index < self.__len:
            x2 = self.__conf[index]['x']
            y2 = self.__conf[index]['y']
            if (x1 <= x < x2):
                y = y1+ (x - x1) * ((y2 - y1) / (x2 - x1))
                log.debug(f'x1: {x1}; y1: {y1}\tx2: {x2}; y2: {y2}')
                log.debug(f'value: {x}\tthreshold: {y}')
                return y
            x1 = x2
            y1 = y2
            index += 1
        th = self.__conf[self.__len -1]['y']
        log.debug(f'value: {x}\tthreshold: {th}')
        return th
