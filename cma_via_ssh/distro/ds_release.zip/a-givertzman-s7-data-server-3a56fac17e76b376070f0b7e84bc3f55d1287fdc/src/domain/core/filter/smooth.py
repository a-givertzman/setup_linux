

class Smooth:
    """
    factor: smooth factor (1, .. 1.5, .. 2, 4, 8, 16, .. 128), default = 1
    initialValue: initial value if input
    """
    def __init__(self,
        factor = 1,
        initialValue = 0,
    ):
        if (factor < 1 or factor > 128):
            raise Exception('factor should be in between 1...128')
        self.__factor = factor
        self.__out = initialValue
    def add(self, value):
        self.__out = self.__out + (value - self.__out) / self.__factor
    def out(self):
        return self.__out
