

class Filter:
    """
    filter added value using integral algorithm, that means:
    the less input value changes the slower it will be delivered to the output
    factor: filter factor (1, .. 1.5, .. 2, 4, 8, 16, .. 128), default = 1
    threshold: insensitive limit of input value (0..100)
    initialValue: initial value if input
    """
    def __init__(self,
        factor = 1.0,
        threshold = 0.0,
        initialValue = 0.0,
    ):
        if (factor < 1 or factor > 128):
            raise Exception('factor should be in between 1...128')
        if (threshold < 0.0 or threshold > 100.0):
            raise Exception('threshold should be in between 0...100')
        self.__factor = factor
        self.__threshold = threshold
        self.__out = initialValue
        self.__delta = 0
        self.__prevouse = 0
    
    def add(self, value):
        delta = abs(self.__prevouse - value)   # дельта изменения
        self.__prevouse = value
        self.__delta += delta * self.__factor
        if (self.__delta > self.__threshold):
            self.__delta = 0
            self.__out = value
    
    def out(self):
        return self.__out


            # delta  = abs(self.readingTime - dt)    # дельта изменения
            # deltaSum += delta * kSmooth / 10
            # if (deltaSum > deltaLim):
            #     deltaSum = 0
            #     arr = np.array(self.readingTimeBuffer)
            #     arr = np.roll(arr, -1)
            #     strDt = f'{dt:3d}'
            #     arr[11] = strDt
            #     self.readingTime = dt,
            #     self.readingTimeBuffer = arr,
