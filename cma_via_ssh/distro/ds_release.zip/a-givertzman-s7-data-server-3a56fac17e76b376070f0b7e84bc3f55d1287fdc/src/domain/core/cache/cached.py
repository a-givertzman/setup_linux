import logging
import src.app_logger as app_logger
from typing import Generic, TypeVar

log = app_logger.get_logger('Cached', level = logging.WARN)

T = TypeVar('T')
class Cached(Generic[T]):
    def __init__(self,
        origin: T,
    ) -> None:
        self.__origin = origin
        self.__cache = None
    def __getattr__(self, name):
        def _method_missing(*args, **kwargs):
            if (self.__cache == None):
                method = getattr(self.__origin, name)
                self.__cache = method(*args, **kwargs)
                log.info(f'value {self.__cache} cached')
            return self.__cache
        return _method_missing
