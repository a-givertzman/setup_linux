import logging
import threading
import src.app_logger as app_logger

log = app_logger.get_logger('LockedIterator', level = logging.INFO)

class LockedIterator(object):
    def __init__(self, it):
        self.lock = threading.Lock()
        self.it = iter(it)

    def __iter__(self): return self

    def __next__(self):
        with self.lock:
            return self.it.__next__()