from enum import Enum

class DSDataClass(Enum):
    '''
    Классифицирует сигнал/команду передаваемую между DataServer и клиентами:
    - [requestAll] - команда запрашивает все тэги, 
    - [requestPath] - команда запрашивает все тэги по указанному пути;
    - [requestList] - команда запрашивает списком имен тэгов, 
        ожидая что DataSetver отправит их последние значения в поток;
    - [requestAlarms] - команда запрашивает активные аварии;
    - [requestTime] - команда запрашивает текущее время с DataServer;
    - [syncTime] - команда синхронизации времени;
    - [commonCmd] - команда со значением типа Bool, Int, Real, etc...;
    - [commonData] - тэги со значением типа Bool, Int, Real, etc...;
    '''
    requestAll = 'requestAll'
    requestPath = 'requestPath'
    requestList = 'requestList'
    requestAlarms = 'requestAlarms'
    requestTime = 'requestTime'
    syncTime = 'syncTime'
    commonCmd = 'commonCmd'
    commonData = 'commonData'
    @classmethod
    def fromString(cls, value: str):
        if (value == DSDataClass.requestAll.value):
            return DSDataClass.requestAll
        if (value == DSDataClass.requestPath.value):
            return DSDataClass.requestPath
        if (value == DSDataClass.requestList.value):
            return DSDataClass.requestList
        if (value == DSDataClass.requestAlarms.value):
            return DSDataClass.requestAlarms
        if (value == DSDataClass.requestTime.value):
            return DSDataClass.requestTime
        if (value == DSDataClass.syncTime.value):
            return DSDataClass.syncTime
        if (value == DSDataClass.commonCmd.value):
            return DSDataClass.commonCmd
        if (value == DSDataClass.commonData.value):
            return DSDataClass.commonData
        else:
            raise Exception(f'Uncnown data class: {value}')
