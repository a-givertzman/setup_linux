from enum import Enum


class DSDataTypeStruct:
    def __init__(self,
        name: str,
        length: int,
    ) -> None:
        '''- name: str - the name of the data type
            - lenth: int - count of bits in the S7 IED address area'''
        self.name = name
        self.length = length

class DSDataType(Enum):
    Bool = DSDataTypeStruct(
        name = 'Bool',
        length = 2,
    )
    Int = DSDataTypeStruct(
        name = 'Int',
        length = 2,
    )
    UInt = DSDataTypeStruct(
        name = 'UInt',
        length = 2,
    )
    DInt = DSDataTypeStruct(
        name = 'DInt',
        length = 4,
    )
    Word = DSDataTypeStruct(
        name = 'Word',
        length = 2,
    )
    LInt = DSDataTypeStruct(
        name = 'LInt',
        length = 8,
    )
    Real = DSDataTypeStruct(
        name = 'Real',
        length = 4,
    )
    Time = DSDataTypeStruct(
        name = 'Time',
        length = 4,
    )
    Date_And_Time = DSDataTypeStruct(
        name = 'Date_And_Time',
        length = 8,
    )
    @classmethod
    def fromString(cls, value: str):
        if (value == 'Bool'):
            return DSDataType.Bool
        if (value == 'Int'):
            return DSDataType.Int
        if (value == 'UInt'):
            return DSDataType.UInt
        if (value == 'DInt'):
            return DSDataType.DInt
        if (value == 'Word'):
            return DSDataType.Word
        if (value == 'LInt'):
            return DSDataType.LInt
        if (value == 'Real'):
            return DSDataType.Real
        if (value == 'Time'):
            return DSDataType.Time
        if (value == 'Date_And_Time'):
            return DSDataType.Date_And_Time
        else:
            raise Exception(f'Uncnown data type: {value}')