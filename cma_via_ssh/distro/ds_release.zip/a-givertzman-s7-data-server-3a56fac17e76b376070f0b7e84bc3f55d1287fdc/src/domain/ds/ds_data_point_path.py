import logging
import src.app_logger as app_logger

log = app_logger.get_logger('DSDataPointPath', level = logging.INFO)

class DSDataPointPath:
    def __init__(self,
        value: str,
    ):
        assert value != None
        assert value != ''
        assert value.count('.') == 2 and value.split('.')[0] != '' and value.split('.')[1] != '' and value.split('.')[2] != ''
        # self.__value = value
        self.__parts = value.split('.')

    def line(self):
        return self.__parts[0]

    def ied(self):
        return self.__parts[1]
    
    def db(self):
        return self.__parts[2]
