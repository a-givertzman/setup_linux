import json
import logging
import datetime
from typing import Any
import src.app_logger as app_logger
from src.domain.ds.ds_data_class import DSDataClass
from src.domain.ds.ds_data_type import DSDataType
from src.domain.ds.ds_status import DSStatus

log = app_logger.get_logger('DSDataPoint', level = logging.DEBUG)

class DSDataPoint:
    '''
    data point to be passed from S7ParseStream to Socket Data Server
        dsClass: S7DataClass.name - 'IntCmd', 'RealCmd', 'syncTime', 'requestList' etc.
        type: S7DataType.name - 'Int', 'UInt', 'Real' etc.
        path: str - the path of the data point such 'line-name/ied-name/...'
        name: str - the name of the data point to identify it within the whole project
        timestamp: UTC ISO string contains date and time when the data point was registered on the data server
    '''
    def __init__(self,
        dsClass: DSDataClass,
        type: DSDataType,
        name: str,
        value: Any,
        status: DSStatus,
        history: int,
        alarm: int,
        # fr: bool,
        # frParams: DSFaultParams | None,
        timestamp: datetime.datetime,
        path: str = '',
    ):
        self.dsClass = dsClass
        self.type = type
        self.path = path
        self.name = name
        self.value = value
        self.status = status
        self.history = history
        self.alarm = alarm
        # self.fr = fr
        # self.frParams = frParams
        self.timestamp = timestamp

    def toMap(self):
        return {
            'class': self.dsClass.name,
            'type': self.type.name,
            'path': self.path,
            'name': self.name,
            'value': str(self.value),
            'status': self.status.value,
            'history': self.history,
            'alarm': self.alarm,
            'timestamp': self.timestamp.strftime('%Y-%m-%d %H:%M:%S.%f'),
        }

    def toJson(self) -> str:
        return json.dumps(self.toMap())

    @classmethod
    def fromBytes(cls, data: bytes):
        try:
            jsonData = data.decode('utf-8')
        except Exception as error:
            log.debug(f'on bytes: {data} convertion error:\n\t{error}')
            return None
        return DSDataPoint.fromJson(jsonData)

    @classmethod
    def fromJson(cls, jsonData: str):
        # try:
        raw: dict = json.loads(jsonData)
        return DSDataPoint.fromMap(raw)

    @classmethod
    def fromMap(cls, raw: dict):
        try:
            return DSDataPoint(
                dsClass = DSDataClass.fromString(raw['class']),
                type = DSDataType.fromString(raw['type']),
                path = raw['path'],
                name = raw['name'],
                value = raw['value'],
                status = DSStatus.fromString(raw['status']),
                history = raw['history'] if 'history' in raw else 0,
                alarm = raw['alarm'] if 'alarm' in raw else 0,
                # fr = True if 'fr' in raw else False,
                # frParams = DSFaultParams(
                #     nom = raw['fr']['nom'] if 'nom' in raw['fr'] else None,
                #     act = raw['fr']['act'] if 'act' in raw['fr'] else None,
                # ) if 'fr' in raw else None,
                timestamp = raw['timestamp'],
            )
        except Exception as error:
            log.debug(f'on raw data: {raw} convertion error:\n\t{error}')
            return None

    def __repr__(self) -> str:
        return f'DSDataPoint(\n\tclass: {self.dsClass} | type: {self.type}\
            \n\t\tpath: {self.path}\
            \n\t\tname: {self.name}\
            \n\t\tvalue: {self.value}\
            \n\t\tstatus: {self.status}\
            \n\t\thistory: {self.history} | alarm: {self.alarm}\
            \n\t\ttimestamp: {self.timestamp})'

            # \n\t\tfr: {self.fr} | frParams: {self.frParams}\