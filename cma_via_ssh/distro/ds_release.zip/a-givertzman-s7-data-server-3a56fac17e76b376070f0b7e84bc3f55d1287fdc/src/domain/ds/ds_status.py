import logging
import src.app_logger as app_logger
from enum import Enum

log = app_logger.get_logger('DSStatus', level = logging.INFO)

class DSStatus(Enum):
    '''Классифицирует сигнал/команду передаваемую между DataServer и клиентами:
        - [ok] - 0, в норме, 
        - [obsolete] - ,2 устаревшее значение, тэг не обновлен;
        - [timeInvalid] - 3, недостоверная метка времени;
        - [invalid] - 10, недостоверное значение, возникает при обрыве связи'''
    ok = 0
    obsolete = 2
    timeInvalid = 3
    invalid = 10
    uncnown = 99
    @classmethod
    def fromString(cls, rawValue: str):
        try:
            value = int(rawValue)
            if (value == DSStatus.ok.value):
                return DSStatus.ok
            if (value == DSStatus.obsolete.value):
                return DSStatus.obsolete
            if (value == DSStatus.timeInvalid.value):
                return DSStatus.timeInvalid
            if (value == DSStatus.invalid.value):
                return DSStatus.invalid
            else:
                log.error(f'Uncnown status: {value}')
                return DSStatus.uncnown
                # raise Exception(f'Uncnown status: {value}')
        except Exception as error:
            log.error(f'parse status "{rawValue}" error: {error}')
            return DSStatus.uncnown
