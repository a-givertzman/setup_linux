from enum import Enum

class DSDataPointAttribute(Enum):
    '''Классифицирует атрибуты тэгов [DSDataPOint] DataServer:
        - [id] - идентификатор тэга в базе данных
        - [dataClass] - класс тэга, 
        - [dataType] - тип данных [value] тэга Bool, Int, Real, etc...;
        - [path] - путь тэга, 
        - [name] - имя тэга;
        - [value] - значение данных тэга;
        - [status] - статус тэга;
        - [history] - признак "исторический" - изменения будут сохранены в базу данных;
        - [alarm] - признак "аварийный" - изменения будут отображены в списке аварий;
        - [fr] - признак "Fault Registrator" - изменения будут сохранены в ригистраторе аварий и параметры настройки регистрации;
        - [timestamp] - метка времени последнего изменения тэга;'''
    id = 'id'
    pointClass = 'class'
    pointType = 'type'
    pointPath = 'path'
    pointName = 'name'
    pointValue = 'value'
    pointStatus = 'status'
    history = 'history'
    alarm = 'alarm'
    fr = 'fr'
    timestamp = 'timestamp'
    @classmethod
    def fromString(cls, value: str):
        if (value == DSDataPointAttribute.id.value):
            return DSDataPointAttribute.id
        if (value == DSDataPointAttribute.pointClass.value):
            return DSDataPointAttribute.pointClass
        if (value == DSDataPointAttribute.pointType.value):
            return DSDataPointAttribute.pointType
        if (value == DSDataPointAttribute.pointPath.value):
            return DSDataPointAttribute.pointPath
        if (value == DSDataPointAttribute.pointName.value):
            return DSDataPointAttribute.pointName
        if (value == DSDataPointAttribute.pointValue.value):
            return DSDataPointAttribute.pointValue
        if (value == DSDataPointAttribute.pointStatus.value):
            return DSDataPointAttribute.pointStatus
        if (value == DSDataPointAttribute.history.value):
            return DSDataPointAttribute.history
        if (value == DSDataPointAttribute.alarm.value):
            return DSDataPointAttribute.alarm
        if (value == DSDataPointAttribute.fr.value):
            return DSDataPointAttribute.fr
        if (value == DSDataPointAttribute.timestamp.value):
            return DSDataPointAttribute.timestamp
        else:
            raise Exception(f'Uncnown data class: {value}')
