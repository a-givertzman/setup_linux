import logging

# _log_format = f"%(asctime)s - [%(levelname)s] - %(name)s - (%(filename)s).%(funcName)s(%(lineno)d) - %(message)s"
_log_format = f"%(asctime)s | %(levelname)s | %(name)s.%(funcName)s(%(lineno)d) | %(message)s"

def get_stream_handler(format, level):
    stream_handler = logging.StreamHandler()
    stream_handler.setLevel(level)
    stream_handler.setFormatter(logging.Formatter(format))
    return stream_handler

def get_file_handler(format, level):
    file_handler = logging.FileHandler("app.log")
    file_handler.setLevel(level)
    file_handler.setFormatter(logging.Formatter(format))
    return file_handler

def get_logger(name, format = _log_format, level = logging.INFO, fileName = None):
    logger = logging.getLogger(name)
    # logging.basicConfig(datefmt='%H:%M:%S')
    logger.setLevel(level)
    if (fileName != None):
        logger.addHandler(get_file_handler(format, level))
    streamHandler = get_stream_handler(format, level)
    streamHandler.setFormatter(
        logging.Formatter(
            fmt = format,
            datefmt='%H:%M:%S'
        )
    )
    logger.addHandler(streamHandler)
    return logger
