import logging
import src.app_logger as app_logger
import mysql.connector as MySql

log = app_logger.get_logger('MySqlResult', level = logging.INFO)

class MySqlResult:
    def __init__(self,
        errCount: int = 0,
        errors: dict[int, str] = {},
        pending: bool = False,
        data: dict = None,
    ) -> None:
        self.hasData = data != None
        self.hasError = (errCount > 0) or (len(errors) > 0)
        self.errors = errors
        self.pending = pending
        self.data = data
        self.errCount = errCount

    def __repr__(self) -> str:
        return f'MySqlResult(\n\thasData: {self.hasData} | data: {self.data} | hasError: {self.hasError} | errCount: {self.errCount} | errors: {self.errors} | pending: {self.pending})'
