import logging
import src.app_logger as app_logger
import mysql.connector as MySql
from src.infrostructure.mysql.mysql_connect import MySqlConnect
from src.infrostructure.mysql.mysql_request import MySqlRequest
from src.infrostructure.mysql.mysql_result import MySqlResult

log = app_logger.get_logger('MySqlSelect', level = logging.INFO)

class MySqlSelect:
    def __init__(self,
        connection: MySqlConnect
    ) -> None:
        self.__connection = connection

    def execute(self, request: MySqlRequest):
        log.debug(f'request: {request}')
        mySqlRequest = request.sql
        if (mySqlRequest.hasData):
            sql = mySqlRequest.data
            log.info(f'sql: {sql}')
            connectResult = self.__connection.connect()
            if (connectResult.hasData):
                cnx = connectResult.connection
                cursor = cnx.cursor(dictionary=True)
                rows = []
                result = {}
                errCount = 0
                errors = []
                try:
                    cursor.execute(sql)
                    fetched = cursor.fetchall()
                    if (fetched):
                        rows.extend(fetched)
                    cnx.commit()
                except MySql.Error as err:
                    log.info(f'error: {err}')
                    errors.append(err)
                    errCount += 1
                finally:
                    cursor.close()
                index = 0
                for row in rows:
                    result[index] = row
                    index += 1
                    # log.debug(row)
                log.info(f'result: {result}')
                if (errCount > 0):
                    log.info(f'errors: {errors}')
                return MySqlResult(
                    data = result,
                    errCount = errCount,
                    errors = {i: f'{errors[i]}' for i in range(0, len(errors))},
                )
            else:
                log.info(f'Mysql connection errors: {connectResult.errors}')
                return MySqlResult(
                    errCount = 1,
                    errors = {
                        i: f'{connectResult.errors[i]}' for i in range(0, len(connectResult.errors))
                    },
                )
        else:
            log.info(f'Building sql request error: {mySqlRequest.error}')
            return MySqlResult(
                errCount = 1,
                errors = {
                    0: f'Building sql request error: {mySqlRequest.error}'
                },
            )





    # def __extractParam(self, params, key, default):
    #     return json.loads(params[key]) if key in params else default

    # def __buildSql(self, params):
    #     _sql = self.__extractParam(params, 'sql', default = None)
    #     if (_sql != None):
    #         return _sql
    #     else:
    #         tableName = self.__extractParam(params, 'tableName', default = '')
    #         keys = self.__extractParam(params, 'keys', default = ['*'])
    #         groupBy = self.__extractParam(params, 'groupBy', default = '')
    #         orderBy = self.__extractParam(params, 'orderBy', default = ['id'])
    #         order = self.__extractParam(params, 'order', default = ['ASC'])
    #         where = self.__extractParam(params, 'where', default = [])
    #         limit = self.__extractParam(params, 'limit', default = [])
    #         _sql = "SELECT "
    #         _sql += self.__keysExpression(keys)
    #         _sql += f'\nFROM `{tableName}`'
    #         _sql += self.__whereExpression(where)
    #         _sql += self.__orderExpression(orderBy, order)
    #         _sql += self.__limitExpression(limit)
    #         _sql += ';'
    #         return _sql

    # def __keysExpression(self, keys: list[str]):
    #     keysExpression = ''
    #     if (keys):
    #         for field in keys:
    #             if (re.search(r'[\(,\),\*]', field)):
    #                 keysExpression += f'\n\t{field},'
    #             else:
    #                 keysExpression += f'\n\t`{field}`,'
    #         keysExpression = keysExpression[:(len(keysExpression) - 1)]
    #     return keysExpression

    # def __orderExpression(self, orderBy: list, order: str):
    #     orderExpression = ''
    #     if (orderBy != None and len(orderBy) > 0):
    #         orderExpression += f'\n\tORDER BY '
    #         index = 0
    #         for field in orderBy:
    #             orderDirection = 'ASC'
    #             if (index < len(order)):
    #                 orderDirection = order[index]
    #             orderExpression += f'`{field}` {orderDirection},'
    #             index += 1
    #         orderExpression = orderExpression[:(len(orderExpression) - 1)]
    #     return orderExpression

    # def __limitExpression(self, limit: list):
    #     limitExpression = ''
    #     if (len(limit) > 0):
    #         if (len(limit) > 1):
    #             limitExpression += f'\n\tLIMIT {limit[0]},{limit[1]}'
    #         else:
    #             limitExpression += f'\n\tLIMIT {limit[0]}'
    #     return limitExpression

    # def __whereExpression(self, where: list):
    #     query = ''
    #     if (len(where) > 0):
    #         for clauese in  where:
    #             # clauese = (array) clauese
    #             log.info(f'clause: {clauese}')
    #             operator = clauese['operator']
    #             table = f"`{clauese['table']}`" if ('table' in clauese) else ''
    #             field = clauese['field']
    #             cond = clauese['cond']
    #             value = clauese['value'] if ('value' in clauese) else None
    #             sufix = clauese['sufix'] if ('sufix' in clauese) else None
    #             query += f"\n\t{operator} {table}`{field}` {cond}"
    #             query += f" '{value}'" if (value != None) else ''
    #             query += f" {sufix}" if (sufix != None) else ''
    #     return query

