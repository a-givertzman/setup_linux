import re
import json
import logging
import src.app_logger as app_logger
from typing import Any
from src.domain.core.result import Result

log = app_logger.get_logger('MySqlRequest', level = logging.DEBUG)


class MySqlRequest:
    '''Парсит входные данные из bytes/bytearray -> json -> dict,
        затеп по запрсу из соответствующего метода готовит SQL
        запрос SELECT / INSERT / UPDATE / etc...'''
    def __init__(self,
        raw: bytearray | bytes
    ) -> None:
        self.__raw = raw
        self.__sql: Result[str] = Result[str](
            error = Exception('Sql is not ready yet.')
        )
        self.__parsed: dict = {}
        # self.__parsed: Result[dict] = Result[dict](
        #     error = Exception('Parsed is not ready yet.')
        # )
        self._isBuilt = False

    @property
    def apiSql(self):
        if (not self._isBuilt):
            self.__sql = self.__buildSql()
        return self.__parsed['api-sql']

    @property
    def ready(self):
        if (not self._isBuilt):
            self.__sql = self.__buildSql()
        return self.__sql.hasData

    @property
    def sql(self) -> Result[str]:
        if (not self._isBuilt):
            self.__sql = self.__buildSql()
        return self.__sql


    def __buildSql(self) -> Result[str]:
        self._isBuilt = True
        result = self.__parse(self.__raw)
        if (result.hasData):
            params = result.data
            params['api-sql'] = json.loads(params['api-sql'])
            if (params['api-sql'] == 'select'):
                log.info(f'SELECT request')
                return Result[str](
                    data = self.__buildSqlSelect(params)
                )
            elif (params['api-sql'] == 'insert'):
                log.info(f'INSERT request')
                return Result[str](
                    data = self.__buildSqlInsert(params)
                )
            elif (params['api-sql'] == 'keep-alive'):
                log.info(f'KEEP ALIVE request')
                return Result[str](
                    data = self.__buildSqlSelect(params)
                )
            elif (params['api-sql'] == 'insert-keep-alive'):
                log.info(f'INSERT KEEP ALIVE request')
                return Result[str](
                    data = self.__buildSqlInsert(params)
                )
            elif (params['api-sql'] == 'sql'):
                log.info(f'SQL request')
                return Result[str](
                    data = self.__extractParam(params, 'sql', default = '')
                )
            else:
                log.debug(f'Uncnown request or wrong operator in the request: {params}')
                return Result[str](
                    error = Exception(f'Uncnown operator in the request: {params}')
                )
        return Result[str](
            error = result.error
        )

    def __parse(self, raw: bytearray | bytes):
        if (raw):
            try:
                self.__parsed = json.loads(raw.decode('utf-8'))
                if ('api-sql' in self.__parsed):
                    return Result[dict](
                        data = self.__parsed,
                    )
                else:
                    log.warning(f'Uncnown type of request: {self.__parsed}\n\tProper API sql request must have key "api-sql"')
                    return Result[dict](
                        error = Exception('Request is enpty.'),
                    )
            except Exception as error:
                log.warning(f'Request parsing error: {raw}\n\t details: {error}')
                return Result[dict](
                    error = error,
                )
        else:
            return Result[dict](
                error = Exception('Request is enpty.'),
            )

    def __extractParam(self, params, key, default):
        return json.loads(params[key]) if key in params else default

    def __buildSqlSelect(self, params: dict[str, Any]):
        _sql = self.__extractParam(params, 'sql', default = None)
        if (_sql != None):
            return _sql
        else:
            tableName = self.__extractParam(params, 'tableName', default = '')
            keys = self.__extractParam(params, 'keys', default = ['*'])
            groupBy = self.__extractParam(params, 'groupBy', default = '')
            orderBy = self.__extractParam(params, 'orderBy', default = ['id'])
            order = self.__extractParam(params, 'order', default = ['ASC'])
            where = self.__extractParam(params, 'where', default = [])
            limit = self.__extractParam(params, 'limit', default = [])
            _sql = "SELECT "
            _sql += self.__keysExpression(keys)
            _sql += f'\nFROM `{tableName}`'
            _sql += self.__whereExpression(where)
            _sql += self.__orderExpression(orderBy, order)
            _sql += self.__limitExpression(limit)
            _sql += ';'
            return _sql

    def __buildSqlInsert(self, params: dict[str, Any]):
        _sql = self.__extractParam(params, 'sql', default = None)
        if (_sql != None):
            return _sql
        else:
            tableName = self.__extractParam(params, 'tableName', default = '')
            # procName = self.__extractParam(params, 'procName', default = '')
            # procParams = self.__extractParam(params, 'procParams', default = 0)
            keys = self.__extractParam(params, 'keys', default = [])
            values = self.__extractParam(params, 'values', default = [[]])
            _sql = f"INSERT INTO `{tableName}` ("
            _sql += self.__keysExpression(keys)
            _sql += '\n) VALUES'
            for row in values:
                _sql += '\nROW ('
                _sql += self.__rowExpression(row)
                _sql += '),'
            _sql = _sql[:(len(_sql) - 1)]
            _sql += ';'
            return _sql

    def __keysExpression(self, keys: list[str]):
        keysExpression = ''
        if (keys):
            for field in keys:
                if (re.search(r'[\(,\),\*]', field)):
                    keysExpression += f'\n\t{field},'
                else:
                    keysExpression += f'\n\t`{field}`,'
            keysExpression = keysExpression[:(len(keysExpression) - 1)]
        return keysExpression

    def __rowExpression(self, row: list):
        rowExpression = ''
        if (row != None and len(row) > 0):
            for value in row:
                rowExpression += f'\n\t\'{value}\','
            rowExpression = rowExpression[:(len(rowExpression) - 1)]
        return rowExpression

    def __orderExpression(self, orderBy: list, order: list[str]):
        orderExpression = ''
        if (orderBy != None and len(orderBy) > 0):
            orderExpression += f'\n\tORDER BY '
            index = 0
            for field in orderBy:
                orderDirection = 'ASC'
                if (index < len(order)):
                    orderDirection = order[index]
                orderExpression += f'`{field}` {orderDirection},'
                index += 1
            orderExpression = orderExpression[:(len(orderExpression) - 1)]
        return orderExpression

    def __limitExpression(self, limit: list):
        limitExpression = ''
        if (len(limit) > 0):
            if (len(limit) > 1):
                limitExpression += f'\n\tLIMIT {limit[0]},{limit[1]}'
            else:
                limitExpression += f'\n\tLIMIT {limit[0]}'
        return limitExpression

    def __whereExpression(self, where: list):
        query = ''
        if (len(where) > 0):
            for clauese in  where:
                # clauese = (array) clauese
                log.info(f'clause: {clauese}')
                operator = clauese['operator']
                table = f"`{clauese['table']}`" if ('table' in clauese) else ''
                field = clauese['field']
                cond = clauese['cond']
                value = clauese['value'] if ('value' in clauese) else None
                sufix = clauese['sufix'] if ('sufix' in clauese) else None
                query += f"\n\t{operator} {table}`{field}` {cond}"
                query += f" '{value}'" if (value != None) else ''
                query += f" {sufix}" if (sufix != None) else ''
        return query

    def __repr__(self) -> str:
        if (self._isBuilt):
            return f'MySqlRequest({self.__parsed})'
        else:
            return f'MySqlRequest({self.__raw})'
