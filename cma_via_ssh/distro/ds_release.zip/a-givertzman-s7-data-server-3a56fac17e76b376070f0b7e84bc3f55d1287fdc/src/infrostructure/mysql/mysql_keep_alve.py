import json
import logging
import socket
import threading
import mysql.connector as MySql
import src.app_logger as app_logger
from time import sleep
from queue import Queue
from src.infrostructure.core.api_service import APIService
from src.infrostructure.core.socket_server_client import SocketServerClient
from src.infrostructure.mysql.mysql_connect import MySqlConnect
from src.infrostructure.mysql.mysql_request import MySqlRequest
from src.infrostructure.mysql.mysql_result import MySqlResult

log = app_logger.get_logger('MySqlKeepAlive', level = logging.INFO)


class MySqlKeepAlive(threading.Thread, APIService):
    def __init__(self,
        connection: MySqlConnect,
        clientSocket: socket.socket
    ) -> None:
        self.__cancel = False
        self.__isActive = False
        self.__connection = connection
        self.__socketClient = SocketServerClient(
            id = 0,
            socket = clientSocket.dup(),
            # onError = 
        )
        super(MySqlKeepAlive, self).__init__(
            name = f'MySqlKeepAlive.Thread',
            daemon = True
        )

    def run(self):
        log.info(f'MySqlInsertKeepAlive starting in thread: {threading.current_thread().name}...')
        self.__socketClient.start()
        self.__isActive = True
        while (self.__socketClient.connected) and (not self.__cancel):
            sqlResult = self.__execute()
            if (sqlResult and isinstance(sqlResult, MySqlResult)):
                log.info(f'response.data: {sqlResult.data}')
                log.info(f'response.errCount: {sqlResult.errCount}')
                log.info(f'response.errors: {sqlResult.errors}')
                response = {
                    'data': sqlResult.data,
                    'errCount': sqlResult.errCount,
                    'errDump': sqlResult.errors,
                }
                _jsonData = json.dumps(response)
                _bytes = _jsonData.encode('utf-8')
                self.__socketClient.send(_bytes)
            sleep(100 / 1000)
        self.__isActive = False
        log.info(f'exit')

    def __readQueue(self, queue: Queue[bytes]):
        requests: list[bytes] = []
        if (not queue.empty()):
            log.debug(f'reading queue of size {queue.qsize()}')
            while not queue.empty():
                request = queue.get()
                requests.append(request)
            queue.task_done()
        return requests

    def __execute(self):
        requests = self.__readQueue(self.__socketClient.queue)
        for request in requests:
            log.debug(f'request: {request}')
            mySqlRequest = MySqlRequest(request).sql
            if (mySqlRequest.hasData):
                sql = mySqlRequest.data
                log.info(f'sql: {sql}')
                connectResult = self.__connection.connect()
                if (connectResult.hasData):
                    cnx = connectResult.connection
                    cursor = cnx.cursor(dictionary=True)
                    rows = []
                    result = {}
                    errCount = 0
                    errors = []
                    try:
                        cursor.execute(sql)
                        fetchedRows = cursor.fetchall()
                        if (fetchedRows):
                            rows.extend(fetchedRows)
                        cnx.commit()
                    except MySql.Error as err:
                        log.info(f'error: {err}')
                        errors.append(err)
                        errCount += 1
                    finally:
                        cursor.close()
                    index = 0
                    for row in rows:
                        result[index] = row
                        index += 1
                        # log.debug(row)
                    log.info(f'result: {result}')
                    if (errCount > 0):
                        log.info(f'errors: {errors}')
                    return MySqlResult(
                        data = result,
                        errCount = errCount,
                        errors = {i: f'{errors[i]}' for i in range(0, len(errors))},
                    )
                else:
                    log.info(f'Mysql connection errors: {connectResult.errors}')
                    return MySqlResult(
                        errCount = 1,
                        errors = {
                            i: f'{connectResult.errors[i]}' for i in range(0, len(connectResult.errors))
                        },
                    )
            else:
                log.info(f'Building sql request error: {mySqlRequest.error}')
                return MySqlResult(
                    errCount = 1,
                    errors = {
                        0: f'Building sql request error: {mySqlRequest.error}'
                    },
                )

    def cancel(self):
        self.__cancel = True
        self.__connection.close()
        if self.__socketClient:
            self.__socketClient.close()

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')









    # def __extractParam(self, params: dict, key: str, default):
    #     # try:
    #     #     decoded = json.loads(params[key]) if key in params else default
    #     # except Exception as error:
    #     #     log.info(f'json.loads errors on key: {key}\tin params: \n\t{params}\n\t{error}')
    #     #     return ''
    #     return json.loads(params[key]) if key in params else default

    # def __buildSelectSql(self, params):
    #     tableName = self.__extractParam(params, 'tableName', default = '')
    #     keys = self.__extractParam(params, 'keys', default = ['*'])
    #     groupBy = self.__extractParam(params, 'groupBy', default = '')
    #     orderBy = self.__extractParam(params, 'orderBy', default = ['id'])
    #     order = self.__extractParam(params, 'order', default = ['ASC'])
    #     where = self.__extractParam(params, 'where', default = [])
    #     limit = self.__extractParam(params, 'limit', default = [])
    #     _sql = "SELECT "
    #     _sql += self.__keysExpression(keys)
    #     _sql += f'\nFROM `{tableName}`'
    #     _sql += self.__whereExpression(where)
    #     _sql += self.__orderExpression(orderBy, order)
    #     _sql += self.__limitExpression(limit)
    #     _sql += ';'
    #     return _sql

    # def __orderExpression(self, orderBy: list, order: str):
    #     orderExpression = ''
    #     if (orderBy != None and len(orderBy) > 0):
    #         orderExpression += f'\n\tORDER BY '
    #         index = 0
    #         for field in orderBy:
    #             orderDirection = 'ASC'
    #             if (index < len(order)):
    #                 orderDirection = order[index]
    #             orderExpression += f'`{field}` {orderDirection},'
    #             index += 1
    #         orderExpression = orderExpression[:(len(orderExpression) - 1)]
    #     return orderExpression

    # def __limitExpression(self, limit: list):
    #     limitExpression = ''
    #     if (len(limit) > 0):
    #         if (len(limit) > 1):
    #             limitExpression += f'\n\tLIMIT {limit[0]},{limit[1]}'
    #         else:
    #             limitExpression += f'\n\tLIMIT {limit[0]}'
    #     return limitExpression

    # def __whereExpression(self, where: list):
    #     query = ''
    #     if (len(where) > 0):
    #         for clauese in  where:
    #             # clauese = (array) clauese
    #             log.info(f'clause: {clauese}')
    #             operator = clauese['operator']
    #             table = f"`{clauese['table']}`" if ('table' in clauese) else ''
    #             field = clauese['field']
    #             cond = clauese['cond']
    #             value = clauese['value'] if ('value' in clauese) else None
    #             sufix = clauese['sufix'] if ('sufix' in clauese) else None
    #             query += f"\n\t{operator} {table}`{field}` {cond}"
    #             query += f" '{value}'" if (value != None) else ''
    #             query += f" {sufix}" if (sufix != None) else ''
    #     return query

    # def __buildInsertSql(self, params):
    #     tableName = self.__extractParam(params, 'tableName', default = '')
    #     keys = self.__extractParam(params, 'keys', default = [])
    #     values = self.__extractParam(params, 'values', default = [[]])
    #     _sql = f"INSERT INTO `{tableName}` ("
    #     _sql += self.__keysExpression(keys)
    #     _sql += '\n) VALUES'
    #     for row in values:
    #         _sql += '\nROW ('
    #         _sql += self.__rowExpression(row)
    #         _sql += '),'
    #     _sql = _sql[:(len(_sql) - 1)]
    #     _sql += ';'
    #     return _sql

    # def __keysExpression(self, keys: list):
    #     keysExpression = ''
    #     if (keys != None and len(keys) > 0):
    #         for field in keys:
    #             keysExpression += f'\n\t`{field}`,'
    #         keysExpression = keysExpression[:(len(keysExpression) - 1)]
    #     return keysExpression

    # def __rowExpression(self, row: list):
    #     rowExpression = ''
    #     if (row != None and len(row) > 0):
    #         for value in row:
    #             rowExpression += f'\n\t\'{value}\','
    #         rowExpression = rowExpression[:(len(rowExpression) - 1)]
    #     return rowExpression

    # def __receiveAll(self, sock: socket.socket):
    #     data = bytearray()
    #     buff_size = 4096
    #     while True: 
    #         part = sock.recv(buff_size)
    #         data.extend(part)
    #         if len(part) < buff_size:
    #             break
    #     return data

