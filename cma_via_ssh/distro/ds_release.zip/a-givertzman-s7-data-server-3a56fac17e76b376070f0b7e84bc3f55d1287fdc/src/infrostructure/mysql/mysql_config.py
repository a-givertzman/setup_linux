import logging
import src.app_logger as app_logger
import mysql.connector as MySql

log = app_logger.get_logger('MySqlConfig', level = logging.INFO)

class MySqlConfig:
    def __init__(self,
        host: str,
        database: str,
        user: str,
        password: str,
        converter_class: MySql.conversion.MySQLConverterBase = None,
        raise_on_warnings: bool = True,
        raw: bool = False,
    ) -> None:
        self.host = host
        self.database = database
        self.user = user
        self.password = password
        self.raw = raw
        self.converter_class = converter_class
        self.raise_on_warnings = raise_on_warnings
