import logging
import src.app_logger as app_logger
import mysql.connector as MySql

log = app_logger.get_logger('MySqlConnectResult', level = logging.INFO)

class MySqlConnectResult:
    def __init__(self,
        errCount: int = 0,
        errors: list = [],
        pending: bool = False,
        connection: MySql.CMySQLConnection | MySql.MySQLConnection | None = None,
    ) -> None:
        self.hasData = connection != None
        self.hasError = (errCount > 0) or (len(errors) > 0)
        self.errors = errors
        self.pending = pending
        if (connection):
            self.__connection = connection
        self.errCount = errCount

    @property
    def connection(self):
        if (self.__connection):
            return self.__connection
        else:
            raise Exception('empty connection requested')