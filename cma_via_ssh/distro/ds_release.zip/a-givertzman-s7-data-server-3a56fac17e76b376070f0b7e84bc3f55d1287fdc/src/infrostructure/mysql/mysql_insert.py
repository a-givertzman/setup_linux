import logging
import src.app_logger as app_logger
import mysql.connector as MySql
from src.infrostructure.mysql.mysql_connect import MySqlConnect
from src.infrostructure.mysql.mysql_request import MySqlRequest
from src.infrostructure.mysql.mysql_result import MySqlResult

log = app_logger.get_logger('MySqlInsert', level = logging.INFO)

class MySqlInsert:
    def __init__(self,
        connection: MySqlConnect
    ) -> None:
        self.__connection = connection

    def execute(self, request: MySqlRequest):
        log.debug(f'request: {request}')
        mySqlRequest = request.sql
        if (mySqlRequest.hasData):
            sql = mySqlRequest.data
            log.info(f'sql: {sql}')
            connectResult = self.__connection.connect()
            if (connectResult.hasData):
                cnx = self.__connection.connect().connection
                cursor = cnx.cursor(dictionary=True)
                rows = []
                result = {}
                errCount = 0
                errors = []
                try:
                    cursor.execute(sql)
                    fetched = cursor.fetchall()
                    if (fetched):
                        rows.extend(fetched)
                    # if ('insert' in params['api-sql']):
                    cnx.commit()
                except MySql.Error as err:
                    log.info(f'error: {err}')
                    errors.append(err)
                    errCount += 1
                finally:
                    cursor.close()
                # log.debug(result)
                index = 0
                for row in rows:
                    result[index] = row
                    index += 1
                    # log.debug(row)
                log.info(f'result: {result}')
                if (errCount > 0):
                    log.info(f'errors: {errors}')
                return MySqlResult(
                    data = result,
                    errCount = errCount,
                    errors = {i: f'{errors[i]}' for i in range(0, len(errors))},
                )
            else:
                log.info(f'Mysql connection errors: {connectResult.errors}')
                return MySqlResult(
                    errCount = 1,
                    errors = {
                        i: f'{connectResult.errors[i]}' for i in range(0, len(connectResult.errors))
                    },
                )
        else:
            log.info(f'Building sql request error: {mySqlRequest.error}')
            return MySqlResult(
                errCount = 1,
                errors = {
                    0: f'Building sql request error: {mySqlRequest.error}'
                },
            )



    # def __extractParam(self, params, key, default):
    #     try:
    #         decoded = json.loads(params[key]) if key in params else default
    #     except Exception as error:
    #         log.info(f'json.loads errors on value: \n\t{params[key]}\n\t{error}')
    #         return ''
    #     return decoded

    # def __buildSql(self, params):
    #     _sql = self.__extractParam(params, 'sql', default = None)
    #     if (_sql != None):
    #         return _sql
    #     else:
    #         tableName = self.__extractParam(params, 'tableName', default = '')
    #         # procName = self.__extractParam(params, 'procName', default = '')
    #         # procParams = self.__extractParam(params, 'procParams', default = 0)
    #         keys = self.__extractParam(params, 'keys', default = [])
    #         values = self.__extractParam(params, 'values', default = [[]])
    #         _sql = f"INSERT INTO `{tableName}` ("
    #         _sql += self.__keysExpression(keys)
    #         _sql += '\n) VALUES'
    #         for row in values:
    #             _sql += '\nROW ('
    #             _sql += self.__rowExpression(row)
    #             _sql += '),'
    #         _sql = _sql[:(len(_sql) - 1)]
    #         _sql += ';'
    #         return _sql

    # def __keysExpression(self, keys: list):
    #     keysExpression = ''
    #     if (keys != None and len(keys) > 0):
    #         for field in keys:
    #             keysExpression += f'\n\t`{field}`,'
    #         keysExpression = keysExpression[:(len(keysExpression) - 1)]
    #     return keysExpression

    # def __rowExpression(self, row: list):
    #     rowExpression = ''
    #     if (row != None and len(row) > 0):
    #         for value in row:
    #             rowExpression += f'\n\t\'{value}\','
    #         rowExpression = rowExpression[:(len(rowExpression) - 1)]
    #     return rowExpression

