import logging
import src.app_logger as app_logger
import mysql.connector as MySql

log = app_logger.get_logger('MySqlConvertToString', level = logging.INFO)

class MySqlConvertToString(MySql.conversion.MySQLConverterBase):
    def to_python(self, vtype, value):
        if isinstance(value, bytearray):
            return value.decode('utf-8')
        super().to_python(vtype, value)
