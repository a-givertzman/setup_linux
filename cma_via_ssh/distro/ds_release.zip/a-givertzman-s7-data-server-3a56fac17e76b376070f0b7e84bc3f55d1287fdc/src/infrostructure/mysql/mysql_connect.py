import logging
import src.app_logger as app_logger
import mysql.connector as MySql
from src.infrostructure.mysql.mysql_config import MySqlConfig
from src.infrostructure.mysql.mysql_connect_result import MySqlConnectResult

log = app_logger.get_logger('MySqlConnect', level = logging.INFO)

class MySqlConnect:
    def __init__(self,
        config: MySqlConfig
    ) -> None:
        self.__config = config
        self.__connection: MySql.CMySQLConnection | MySql.MySQLConnection

    def connect(self):
        connection: MySql.CMySQLConnection | MySql.MySQLConnection
        try:
            connection = MySql.connect(**self.__config.__dict__)  # type: ignore
            self.__connection = connection
            log.info('connection done')
            return MySqlConnectResult(
                connection = connection
            )
        except MySql.Error as error:
            log.info(f'error: {error}')
            # if (connection):
                # connection.close()
            return MySqlConnectResult(
                errCount = 1,
                errors = [error],
            )

    def close(self):
        if (self.__connection):
            if self.__connection.is_connected():
                self.__connection.close()
                log.info('connection closed')
            else:
                log.info('connection already closed')
        else:
            log.info('connection doesn`t exists')


    def __del__(self):
        if (hasattr(self, '__connection') and self.__connection):
            if self.__connection.is_connected():
                self.__connection.close()
            log.info('connection closed')
        log.info('deleted')