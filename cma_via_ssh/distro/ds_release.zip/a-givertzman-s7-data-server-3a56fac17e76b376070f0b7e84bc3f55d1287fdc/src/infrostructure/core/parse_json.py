import json
from typing import Any

class ParseJson:
    def __init__(self,
        rawBytes: bytes | bytearray | None,
    ) -> None:
        self.__rawBytes = rawBytes
        self.__parsed = False
        self.__data: dict[str, Any] = {}

    def __parse(self):
        if (self.__rawBytes):
            result = self.__rawBytes.decode('utf-8')
            jsonResult: dict = json.loads(result)
            self.__data = jsonResult['data']
            self.__errCount = jsonResult['errCount']
            self.__errDump = jsonResult['errDump']
        self.__parsed = True
        
    @property
    def data(self):
        if (not self.__parsed):
            self.__parse()
        return self.__data if self.__data else None

    @property
    def errCount(self):
        if (not self.__parsed):
            self.__parse()
        return int(self.__errCount) if self.__errCount else None

    @property
    def errDump(self):
        if (not self.__parsed):
            self.__parse()
        return self.__errDump if self.__errDump else None
