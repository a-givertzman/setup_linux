import socket
import logging
import threading
import src.app_logger as app_logger
from time import sleep
from typing import Any, Callable

log = app_logger.get_logger('SocketClient', level = logging.INFO)

class SocketClient(threading.Thread):
    '''Устанавливает и/или поддерживает, восстанавливает подключение (TCP socket) с сервером.
        Получаемые данные в форбате [bytes] отдает в потоке.
        Отправляемые данные в формате [butes] принимаает в методе [send(bytes)]
        и отправляет в TCP - socket.'''
    def __init__(self,
        address = ('127.0.0.1', 16688),
        reconnectTimeout: int = 0,        # milliseconds
        onConnected: Callable[[socket.socket], None] | None = None,
        daemon: bool = False,
    ) -> None:
        '''- onConnected: Callable[[Any, socket.socket], None] - метод, который будет вызван при удачном подключении,
            - address: tuple[str, int] - (ip, port) адрес сервера, на который будет выполняться подключение,
            - reconnectTimeout: int - таймаут в миллисекундах для повторной попытки подключения, если 0 то попытка подключения одна; 
            - daemon: bool - режим потока, в котором будет запужен данный сервис. 
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__onConnected = onConnected
        self.__address = address
        self.__reconnectTimeout = reconnectTimeout
        self.__cancel = False
        self.__connected = False
        self.__socket: socket.socket | None = None
        super(SocketClient, self).__init__(
            name = 'SocketClient.Thread',
            daemon = daemon,
        )

    @property
    def stream(self):
        '''Поток (Generator) сообщений, приходящих из сети (TCP socket).'''
        return self.__readSocket()

    def send(self, buffer: bytes) -> int:
        '''Отправляет серверу данные в формате [bytes].
            Возвращает 0 если успешно или код ошибки при неудаче'''
        if (self.__socket and self.__connected):
            try:
                sent = self.__socket.send(buffer)
                if sent <= 0:
                    self.__closeSocket()
                    log.error(f'send error: sentCount: {sent}, buffer whas: {buffer}')
                    return 1
                return 0
            except OSError as error:
                log.error(f'send error:\n\t{type(error)}\n\t{error.args}')
                self.__closeSocket()
                return error.errno
        else:
            log.error(f'send error: not connected')
            return 1

    def __closeSocket(self):
        self.__connected = False
        if self.__socket:
            self.__socket.close()
        self.__socket = None


    def run(self):
        '''Устанавливает подключение к серверу'''
        log.debug(f'starting...')
        while not self.__cancel:
            self.__connected = self.__socket and self.__socket.fileno() >= 0
            while ((not self.__connected) and (not self.__cancel)):
                try:
                    self.__socket = None
                    self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                except OSError as error:
                    log.error(f'open socket failed:\n\t{type(error)}\n\t{error.args}')
                    self.__socket = None
                    if self.__reconnectTimeout: 
                        sleep(self.__reconnectTimeout / 1000)
                        continue
                    else:
                        break
                try:
                    self.__socket.connect(self.__address)
                    log.info(f'connected to:\n\t{self.__socket}')
                    self.__connected = True
                    if callable(self.__onConnected): 
                        self.__onConnected(self.__socket)
                except OSError as error:
                    log.warn(f'connect error:\n\t{type(error)}\n\t{error.args}')
                    self.__closeSocket()
                    if self.__reconnectTimeout: 
                        sleep(self.__reconnectTimeout / 1000)
                        continue
                    else:
                        break
            if self.__reconnectTimeout: 
                sleep(self.__reconnectTimeout / 1000)
            else:
                break
        self.__closeSocket()
        log.info(f'exit')

    def __readSocket(self):
        '''Читает данные из соккета'''
        log.debug(f'reading...')
        while (not self.__cancel):
            log.debug(f'looping...')
            if self.__connected:
                try:
                    log.debug(f'await rawEvent (client cmd)')
                    rawEvent = self.__recvAll(self.__socket)
                    log.debug(f'received rawEvent:\n\t{rawEvent}')
                    if (len(rawEvent) > 0):
                        self.__readEmptyCount = 0
                        yield rawEvent
                    else:
                        yield None
                        self.__readEmptyCount += 1
                        if (self.__readEmptyCount > 3):
                            log.error(f'recv empty message count={self.__readEmptyCount}\n\tit seems the clien closed connection')
                            self.__closeSocket()
                            sleep(100 / 1000)
                except OSError as error:
                    log.error(f'recv error:\n\t{type(error)}\n\t{error.args}')
                    self.__closeSocket()
                    sleep(100 / 1000)
            else:
                log.error(f'recv error: not connected')
                sleep(self.__reconnectTimeout / 1000)
        log.info(f'exit')

    def __recvAll(self, sock: socket.socket | None):
        data = bytearray()
        if (sock):
            buff_size = 4096
            while (self.__connected and (not self.__cancel)):
                part = sock.recv(buff_size)
                data.extend(part)
                if len(part) < buff_size:
                    break
        return data

    @property
    def connected(self):
        return self.__connected

    def cancel(self):
        self.__cancel = True
        self.__connected = False
        try:
            if (self.__socket):
                self.__socket.shutdown(socket.SHUT_RDWR)
                self.__socket = None
        except OSError as error:
            log.error(f'socket shutdown error:\n\t{type(error)}\n\t{error.args}')
