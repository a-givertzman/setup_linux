import socket
import logging
import threading
import src.app_logger as app_logger
from time import sleep
from typing import Callable
from src.domain.core.result import CancelResult
from src.domain.core.merge_queues import MergeQueues
from src.infrostructure.core.socket_server_client import SocketServerClient

log = app_logger.get_logger('SocketServer', level = logging.INFO)

class SocketServer(threading.Thread):
    '''Принимает входящие подключения (TCP socket) от клиентов.
        Отправляемые всем клиентам данные в методе [send(byres)] в формате [butes] 
        Получаемые данные в форбате [bytes] отдает в потоке.
        Работает в отдельном потоке.'''
    def __init__(self,
        address = ('127.0.0.1', 16688),
        reconnectTimeout: int = 3000,        # milliseconds
        daemon: bool = False,
        onClient: Callable[[SocketServerClient], None] | None = None,
    ) -> None:
        '''- address: tuple[str, int] - адрес (пара IP & Port) на локальной машине, где будет запущен TCP Server,
            - reconnectTimeout: int - таймаут ожидания в миллисекундах при неудачном поднятии сервера,
            - daemon: bool - режим потока, в котором будет запужен данный сервис,
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event;
            - onClient: Callable[[SocketServerClient], None] - метод будет вызван при успешном подключении клиента.'''
        self.__cancel = False
        self.__isActive = False
        self.__connected = False
        self.__address = address
        self.__reconnectTimeout = reconnectTimeout
        self.__onClient = onClient
        self.__meargeQueues = MergeQueues[bytes](
            queues = [], 
            # threadSafe = True,
        )
        self.__socket: socket.socket | None = None
        self.__clients: dict[int, SocketServerClient] = {}
        super(SocketServer, self).__init__(
            name = f'SocketServer.Thread',
            daemon = daemon,
        )

    @property
    def stream(self):
        '''Исходящий поток (Generator) сообщений (команд), 
            приходящих от клиента из сети (TCP socket).'''
        # self.__streamMearged.onListen = self.__onListen
        return self.__meargeQueues.stream

    def send(self, buffer: bytes):
        '''Отправляет всем подключенным клиентам данные в формате [bytes]
            Возвращает 0 если успешно или код ошибки при неудаче'''
        # log.debug(f'sending to: {self.__clients}')
        clientKeys = list(self.__clients)
        # TODO Сделать отдельный буффер для каждого клиента, что бы при неудачной отправке сервер помнил буффер до следующего подключения того же клиента
        result = 0
        for clientKey in clientKeys:
            if clientKey in self.__clients.keys():
                clientResult = self.__clients[clientKey].send(buffer)
                if clientResult > 0:
                    result = clientResult
        return result

    def __onClientError(self, clientId: int):
        '''Закрывает и удаляет клиента если в нем ошибка'''
        log.error(f'on error removing client: {clientId}')
        self.__removeClient(clientId)

    def __removeClient(self, clientId: int):
        if (clientId in self.__clients.keys()):
            client = self.__clients[clientId]
            self.__meargeQueues.removeQueue(client.queue)
            self.__clients.pop(clientId)
            client = None

    def connected(self):
        return self.__connected

    def run(self):
        self.__isActive = True
        while not self.__cancel:
            while (not self.__connected) and (not self.__cancel):
                try:
                    self.__socket = None
                    self.__socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    self.__socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                except OSError as error:
                    self.__connected = False
                    log.warn(f'open socket erroe:\n\t{type(error)}\n\t{error.args}')
                    log.info(f'...sleeping reconnect timeout: {self.__reconnectTimeout}')
                    sleep(self.__reconnectTimeout / 1000)
                    continue
                try:
                    self.__socket.bind(self.__address)
                    self.__socket.listen(5)
                    self.__connected = True
                    log.info(f'server socket connected on:\n\t{self.__socket}')
                except OSError as error:
                    log.warn(f'server socket bind/listen error:\n\t{type(error)}\n\t{error.args}')
                    self.__connected = False
                    self.__clients = {}
                    if self.__socket:
                        self.__socket.close()
                    log.info(f'...sleeping reconnect timeout: {self.__reconnectTimeout}')
                    sleep(3000 / 1000)
                    continue
            while (self.__connected and (not self.__cancel)):
                try:
                    if self.__socket:
                        clientSocket, addr = self.__socket.accept()
                        if self.__cancel:
                            clientSocket.close()
                            break
                        log.info(f'client accepted:\n\t{clientSocket}')
                        clientId = self.__generateClientId()
                        socketServerClient = SocketServerClient(
                            id = clientId,
                            socket = clientSocket,
                            onError = self.__onClientError,
                            daemon = self.daemon,
                        )
                        if self.__onClient != None:
                            log.debug(f'client id: {clientId} passed to self.__onClient(client)')
                            self.__onClient(socketServerClient)
                        else:
                            log.debug(f'client id: {clientId} added to self.__streamMearged')
                            self.__meargeQueues.addQueue(socketServerClient.queue)
                        self.__clients[clientId] = socketServerClient
                        socketServerClient.start()
                        log.debug(f'client id: {clientId} started')
                        log.debug(f'clients: {self.__clients}')
                    else:
                        self.__connected = False
                        self.__clearClients()
                        break
                except OSError as error:
                    log.warn(f'socket.accept failed: {type(error)} : {error.args}')
                    # self.__clients.remove(conn)
                    # conn.close()
                    clientSocket = None
                    addr = None
                    continue
        self.__isActive = False
        log.info(f'exit')

    def __generateClientId(self):
        if (len(self.__clients.keys()) > 0):
            return max(self.__clients.keys()) + 1
        return 1

    def __clearClients(self):
        '''Удаляем всех клиентов, очищаем список клиентов'''
        for client in self.__clients.values():
            if client:
                client.close()
                client = None
        self.__clients = {}

    def cancel(self):
        self.__cancel = True
        self.__connected = False
        for client in self.__clients.values():
            if client:
                client.close()
        self.__clients = {}
        self.__meargeQueues.cancel()
        if (self.__socket):
            try:
                # self.__socket.close()
                self.__socket.shutdown(socket.SHUT_RD)
            except OSError as error:
                log.error(f'socket shutdown error:\n\t{type(error)}\n\t{error.args}')

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')
