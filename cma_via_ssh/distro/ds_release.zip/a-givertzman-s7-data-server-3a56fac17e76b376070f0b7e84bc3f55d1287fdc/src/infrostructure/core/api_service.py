class APIService:
    def cancel(self):
        pass