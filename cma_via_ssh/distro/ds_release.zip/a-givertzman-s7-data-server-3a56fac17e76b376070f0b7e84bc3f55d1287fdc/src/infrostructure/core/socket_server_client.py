import socket
import logging
import src.app_logger as app_logger
from time import sleep
from queue import Queue
from typing import Callable
from threading import Thread
from src.domain.core.result import CancelResult

log = app_logger.get_logger('SocketServerClient', level = logging.INFO)

class SocketServerClient(Thread):
    '''Порождается классом [SocketServer]
        Реализует общение с одним клиентом (TCP socket)
        Принимает входящие сообщения (команд) от клиента из сети (TCP socket)
        и выдает в формате [bytes] в очереди [Queue].
        Отправляемые клиентe данные в методе [send(byres)] в формате [butes]
        Работает в отдельном потоке.'''
    def __init__(self,
        id: int,
        socket: socket.socket,
        onError: Callable | None = None,
        daemon: bool = False,
    ) -> None:
        '''- id: int - идентификатор сервера,
            - socket = socket.socket - инстанс сетевого подключения,
            - onError: Callable - метод, который будет вызван при возникновении ошибки связи,
            - daemon: bool - режим потока, в котором будет запужен данный сервис. 
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''    
        self.id = id
        self.__cancel = False
        self.__connected = True
        self.__readEmptyCount = 0
        self.__socket = socket
        self.__onError = onError
        self.__queue = Queue[bytes]()
        super(SocketServerClient, self).__init__(
            name = f'SocketServerClient.Thread',
            daemon = daemon,
        )

    @property
    def queue(self) -> Queue[bytes]:
        '''Исходящая очередь сообщений (команд),
            приходящих от клиента из сети (TCP socket).'''
        return self.__queue

    @property
    def connected(self) -> bool:
        '''Возвращает текущее состояние подключения с клиентом.'''
        return self.__connected

    def send(self, buffer: bytes) -> int:
        '''Отправляет клиенту данные в формате [bytes]
            Возвращает 0 если успешно или код ошибки при неудаче'''
        if self.__connected:
            try:
                sent = self.__socket.send(buffer)
                if sent <= 0:
                    self.close()
                    if self.__onError: self.__onError(clientId = self.id)
                    log.error(f'send error: sentCount: {sent}, buffer whas: {buffer}')
                    return 1
                return 0
            except OSError as error:
                log.error(f'send error:\n\t{type(error)}\n\t{error.args}')
                self.close()
                if self.__onError: self.__onError(clientId = self.id)
                return error.errno
        else:
            log.error(f'send error: not connected')
            return 1

    def run(self):
        log.debug(f'starting...')
        while (not self.__cancel):
            log.debug(f'looping...')
            if self.__connected and (not self.__cancel):
                try:
                    log.debug(f'await rawEvent (client cmd)')
                    rawEvent = self.__recvAll(self.__socket)
                    log.debug(f'received rawEvent:\n\t{rawEvent}')
                    if (len(rawEvent) > 0):
                        self.__readEmptyCount = 0
                        self.__queue.put(rawEvent)
                    else:
                        self.__readEmptyCount += 1
                        if (self.__readEmptyCount > 3):
                            log.error(f'recv empty message count={self.__readEmptyCount}\n\tit seems the clien closed connection')
                            self.close()
                            if self.__onError: self.__onError(clientId = self.id)
                            break
                except OSError as error:
                    log.error(f'recv error:\n\t{type(error)}\n\t{error.args}')
                    self.close()
                    if self.__onError: self.__onError(clientId = self.id)
                    break
            else:
                log.error(f'recv error: not connected')
            sleep(100 / 1000)
        log.info(f'exit')

    def __recvAll(self, sock: socket.socket):
        data = bytearray()
        buff_size = 4096
        while (self.__connected and (not self.__cancel)):
            if sock:
                part = sock.recv(buff_size)
                data.extend(part)
                if len(part) < buff_size:
                    break
            else: break
        return data

    def close(self):
        '''Закрывает текущее подключение (TCP socket) с клиентом,
            выставляет текущее состояние connected = false,
            закрывает исходящий поток.'''
        self.__cancel = True
        self.__connected = False
        try:
            self.__socket.shutdown(socket.SHUT_RDWR)
        except OSError as error:
            log.error(f'socket shutdown error:\n\t{type(error)}\n\t{error.args}')
        log.info(f'closed:\n\t{self}')
