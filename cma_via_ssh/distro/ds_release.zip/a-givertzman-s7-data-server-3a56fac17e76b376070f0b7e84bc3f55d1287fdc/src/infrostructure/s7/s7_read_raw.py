import datetime
import logging
import threading
import src.app_logger as app_logger
from src.domain.core.result import ReadResult
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_client import S7Client

log = app_logger.get_logger('S7ReadRaw', level = logging.WARNING)


class S7ReadRaw:
    '''
    Этот класс читает один блок данных из S7Client
    '''
    def __init__(self, 
        dbConfig: S7DbConfig,
        s7Client: S7Client,
    ):
        assert type(s7Client) is S7Client, 's7Client must be of "S7Client" type'
        assert type(dbConfig) is S7DbConfig, 'dbConfig must be of S7DbConfig type'
        self.__s7Client = s7Client
        # self.__connection = s7Client.connection
        self.__config = dbConfig
        self.__errCount = 0

    def getIedInfo(self):
        if (self.__s7Client.connected):
            connection = self.__s7Client.connection
            if connection:
                iedInfo = connection.get_cpu_info()
                cpuState = connection.get_cpu_state()
                cpuInfo = connection.get_cp_info()
                # plcBlockInfo = self.connection.get_block_info('DB', 17)
                # log.info(f'block info: {plcBlockInfo}')
                log.info(f'\n\tied info: {iedInfo}')
                log.info(f'\n\tcpu info: {cpuInfo}')
                log.info(f'\n\tcpu state: {cpuState}')
                return {
                    'iedInfo': iedInfo,
                    'cpuInfo': cpuInfo,
                    'cpuState': cpuState,
                }
        else:
            return None

    def read(self) -> ReadResult[bytes]:
        self.reading = True
        if (self.__s7Client.connected):
            connection = self.__s7Client.connection
            if connection:
                try:
                    dbData = connection.db_read(self.__config.dbNumber, self.__config.dbOffset, self.__config.dbSize)
                    time = datetime.datetime.now()
                    self.__errCount = 0
                    # print('[S7ReadRaw.__read] thread: ', threading.current_thread().name, f'\tdt: {dt}')
                    return ReadResult[bytes](
                        data = dbData,
                        time = time,
                    )
                except Exception as err:
                    log.warning(f'[{threading.current_thread().name}] read failed (dbNumber: {self.__config.dbNumber}):\n\t{type(err)} : {err.args}')
                    self.__s7Client.disconnect()
                    return ReadResult(
                        error = err,
                        time = datetime.datetime.now(),
                    )
            else:
                return ReadResult(
                    error = Exception('Read failed, S7Client is not connected'),
                    time = datetime.datetime.now(),
                )
        else:
            # log.warning(f'read failed (dbNumber: {self.__config.dbNumber}): {type(err)} : {err.args}')
            return ReadResult(
                error = Exception('Read failed, S7Client is not connected'),
                time = datetime.datetime.now(),
            )

    def __del__(self):
        self.__config.path
        log.info(f'{self.__config.path}/{self.__config.name} deleted')
