import struct
import logging
import threading
from time import sleep
import src.app_logger as app_logger
from typing import Callable
from datetime import datetime, timedelta
from src.domain.core.result import CancelResult
from src.domain.core.filter.filter import Filter
from src.domain.ds.ds_status import DSStatus
from src.domain.ds.ds_data_type import DSDataType
from src.domain.ds.ds_data_class import DSDataClass
from src.domain.ds.ds_data_point import DSDataPoint
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_parse_point import S7ParsePoint
from src.infrostructure.s7.s7_read_raw import ReadResult
from src.infrostructure.s7.s7_raw_stream import S7RawStream


log = app_logger.get_logger('S7ParseStream', level = logging.INFO)

class S7ParseStream:
    '''Этот класс читает сырые данные из S7RawStream
        и выдает их в stream (Generator) в разобранном формате, 
        преобразует byteArray <-> DSDataPoint[type]:
            - int
            - float
            - string
            - DateTime\n
        как читать данные и как их разбирать класс знает из конфигурации S7Config.'''
    def __init__(self, 
        path: str,
        name: str,
        config: S7DbConfig,
        rawStream: S7RawStream,
    ):
        self.__cancel = False
        self.__isActive = False
        self.__requestAll = False
        self.__requestList = None
        self.__path = path
        self.__name = name
        self.__rawStream = rawStream
        self.__readDelay = timedelta(milliseconds = config.delay) if config.delay > 0 else None
        self.__systemPoints: dict[str, S7ParsePoint] = {}
        self.__points: dict[str, S7ParsePoint] = {}
        self.__lastReadTime = datetime.now()
        for pointKey, pointConf in config.data.items():
            if pointConf.name.split('.')[0] == 'system':
                self.__systemPoints[pointConf.name] = S7ParsePoint(
                    type = pointConf.type,
                    path = pointConf.path + '/' + self.__name,
                    name = pointConf.name,
                    history = pointConf.history if pointConf.history else 0,
                    alarm = pointConf.alarm if pointConf.alarm else 0,
                    offset = pointConf.offset if pointConf.offset else 0,
                )
            else:
                self.__points[pointConf.name] = S7ParsePoint(
                    type = pointConf.type,
                    path = pointConf.path + '/' + self.__name,
                    name = pointConf.name,
                    history = pointConf.history if pointConf.history else 0,
                    alarm = pointConf.alarm if pointConf.alarm else 0,
                    offset = pointConf.offset if pointConf.offset else 0,
                    bit = pointConf.boolBit if pointConf.boolBit else 0,
                    filter = Filter(
                        factor = 1,
                        threshold = pointConf.threshold,
                        initialValue = 0, #pointConf.initialValue,
                    ) if (pointConf.threshold and pointConf.threshold > 0) else None,
                )

    @property
    def name(self):
        return self.__name

    def delayExceeded(self):
        '''Возвращает True если таймаут цикла чтения истек и блок готов к очередному чтению из контроллера'''
        if not self.__readDelay:
            return True
        timePassed = datetime.now() - self.__lastReadTime
        # log.info(f'{self.__path}/{self.__name} timePassed: {timePassed}')
        # log.info(f'{self.__path}/{self.__name} readDelay: {self.__readDelay}')
        # log.info(f'{self.__path}/{self.__name} timePassed > readDelay: {timePassed > self.__readDelay}')
        return timePassed > self.__readDelay

    def __setSystemPoint(self, name: str, value):
        if name in self.__systemPoints.keys():
            point = self.__systemPoints[name]
            point.add(
                value = value,
                status = DSStatus.ok,
                time = datetime.now(),
            )

    @property
    def stream(self):
        '''Returns the stream (Generator) object of DSDataPoint'''
        return self.__read()

    def __read(self):
        self.__isActive = True
        stream = self.__rawStream.stream
        while (not self.__cancel) and stream:
            try:
                self.__lastReadTime = datetime.now()
                rawEvents = next(stream)
                # log.info(f'rawEvent: {rawEvent}')
            except StopIteration:
                self.__isActive = False
                self.cancel()
                break
            events = self.__parseRawEvents(rawEvents)
            # log.info(f'event: {event}')
            yield from events
            if self.__requestAll:
                self.__requestAll = False
                yield from self.__storedEvents()
            if self.__requestList != None:
                pointNames = self.__requestList
                self.__requestList = None
                yield from self.__requestedEvents(pointNames)
            yield None
        self.__isActive = False
        log.info(f'{self.__path}/{self.__name} exit')

    def __parseRawEvents(self, event: ReadResult[bytes]):
        if (event.hasError):
            log.debug(f'{self.__path}/{self.__name} has error: {event}')
            self.__setSystemPoint(f'system.{self.__name}.status', 10)
            for key in self.__points:
                point = self.__points[key]
                point.addStatus(
                    status = DSStatus.invalid,
                    time = event.time,
                )
                if (point.changed):
                    yield point.dsPoint(DSDataClass.commonData)
                    # log.debug(f'[{threading.current_thread().name}] point: {dsPoint}')
                del point
        else:
            # log.info(f'{self.__path}/{self.__name} has data: {event}')
            self.__setSystemPoint(f'system.{self.__name}.status', 0)
            for key in self.__points:
                point = self.__points[key]
                # log.info(f'{self.__path}/{self.__name} point : {point.name}')
                point.addRaw(
                    data = event.data,
                    status = DSStatus.ok,
                    time = event.time,
                )
                if (point.changed):
                    yield point.dsPoint(DSDataClass.commonData)
                    # log.debug(f'[{threading.current_thread().name}] point: {dsPoint}')
                del point
        for key in self.__systemPoints:
            point = self.__systemPoints[key]
            if (point.changed):
                yield point.dsPoint(DSDataClass.commonData)
            del point
        del event

    def __storedEvents(self):
        '''Гененрирует поток всех хранимых тэгов'''
        log.info(f'{self.__path}/{self.__name} sending all tags...')
        # log.info(self.__points)
        for key in self.__systemPoints:
            point = self.__systemPoints[key]
            if (point.value != None):
                yield point.dsPoint(DSDataClass.commonData)
        for key in self.__points:
            point = self.__points[key]
            if (point.value != None):
                yield point.dsPoint(DSDataClass.commonData)

    def __requestedEvents(self, pointNames: set[str]):
        '''Гененрирует поток списка запрошенных тэгов'''
        for key in pointNames:
            if key in self.__systemPoints.keys():
                point = self.__systemPoints[key]
                if (point.value != None):
                    yield point.dsPoint(DSDataClass.commonData)
        for key in pointNames:
            if key in self.__points.keys():
                point = self.__points[key]
                if (point.value != None):
                    yield point.dsPoint(DSDataClass.commonData)

    def requestAll(self):
        '''Входящий запрос прислать все тэги'''
        log.debug(f'{self.__path}/{self.__name} all tags requested')
        self.__requestAll = True

    def requestList(self, pointNames: set[str]):
        '''Входящий запрос прислать список тэгов'''
        log.debug(f'{self.__path}/{self.__name} list of tags requested: {pointNames}')
        self.__requestList = pointNames

    def writeInt(self, 
        name: str, 
        value: int,
        onDone: Callable | None = None,
        length: int = 2,
        byteOrder: str = 'big',
        signed: bool = True
    ):
        '''Отправляет команду со значением типа int
            name: имя сигнала в db конфигурации,
            value: int value to be written to ied current connection
            onDone: callback on write complete'''
        if (name in self.__points.keys()):
            return self.__rawStream.write(
                offset = self.__points[name].start,
                buffer = intToBytearray(value, length, byteOrder, signed),
                onDone = onDone,
            )
        else:
            log.warning(f'write failed: key \"{name}\" is not in configured data list')

    def writeReal(self, 
        name: str, 
        value: float,
        onDone: Callable | None = None,
        length: int = 4,
        byteOrder: str = 'big',
    ):
        '''Отправляет команду со значением типа Real
            name: имя сигнала в db конфигурации,
            value: int value to be written to ied current connection
            onDone: callback on write complete'''
        if (name in self.__points.keys()):
            return self.__rawStream.write(
                offset = self.__points[name].start,
                buffer = floatToBytearray(value, length, byteOrder),
                onDone = onDone,
            )
        else:
            log.warning(f'write failed: key \"{name}\" is not in configured data list')

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        log.debug(f'{self.__name} cancel in thread: {threading.current_thread().name}...')
        self.__rawStream.cancel()
        while self.__rawStream.isActive:
            log.debug(f'{self.__name} wait for self.__rawStream in thread: {threading.current_thread().name}...')
            sleep(100 / 1000)
        self.__cancel = True
        return CancelResult(done = True)

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'{self.__path}/{self.__name} deleted')

def intToBytearray(value, length, byteOrder, signed):
    _bytes = int(value).to_bytes(byteorder = byteOrder, signed = signed, length = length)
    # log.info(f'_bytes: {_bytes}')
    # buffer = bytearray(_bytes)
    # log.info(f'buffer: {buffer}')
    return _bytes #buffer

def floatToBytearray(value, length, byteOrder):
    _bytes = struct.pack('>f', value)
    # log.info(f'_bytes: {_bytes}')
    # buffer = bytearray(_bytes)
    # log.info(f'buffer: {buffer}')
    return _bytes #buffer

