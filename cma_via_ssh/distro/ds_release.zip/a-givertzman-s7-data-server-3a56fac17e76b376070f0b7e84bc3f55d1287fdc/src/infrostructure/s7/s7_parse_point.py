import datetime
import numpy as np
import logging
import src.app_logger as app_logger
from typing import Callable
from src.domain.ds.ds_status import DSStatus
from src.domain.ds.ds_data_class import DSDataClass
from src.domain.ds.ds_data_type import DSDataType
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.core.filter.filter import Filter


log = app_logger.get_logger('S7ParsePoint', level = logging.INFO)

class S7ParsePoint:
    '''
    data point parse process object for S7 Client Parse Stream
        holds type, path???, name of the data point, 
        holds offset address of data points in the raw data to fast access during parse cycle
        holds current value of the data point, 
        holds configured filter, 
    '''
    def __init__(self,
        type: DSDataType,
        path: str,
        name: str,
        history: int,
        alarm: int,
        offset: int,
        bit: int = 0x00,
        filter: Filter | None = None,
    ):
        self.type = type
        self.name = name
        self.path = path
        self.history = history
        self.alarm = alarm
        self.start = offset
        self.end = offset + self.type.value.length
        self.bit = bit
        self.isFiltered = filter != None
        self.filter = filter
        self.changed = False
        self.__value = self.__initValue(type)
        self.__status: DSStatus = DSStatus.ok
        self.__time: datetime.datetime = datetime.datetime.now()
        self.__convert = self.__converters(type)

    # @classmethod
    # def fromConf(cls, pointClass: DSDataClass, value: Any, status: DSStatus, timestamp: datetime.datetime, path: str, name: str, conf: DSPointConfig):
    #     try:
    #         return DSDataPoint(
    #             dsClass = pointClass,
    #             type = conf.type,
    #             path = conf.path,
    #             name = conf.name,
    #             value = conf.value,
    #             status = status,
    #             history = conf.history,
    #             alarm = conf.alarm,
    #             fr = conf.fr,
    #             frParams = conf.frParams,
    #             timestamp = timestamp,
    #         )
    #     except Exception as error:
    #         log.debug(f'on conf data: {conf} convertion error:\n\t{error}')
    #         return None


    def __initValue(self, type: DSDataType):
        if type == DSDataType.Bool:
            return 0
        if type in [DSDataType.Int, DSDataType.UInt, 
                    DSDataType.DInt, DSDataType.Word, 
                    DSDataType.LInt, DSDataType.Real]:
            return 0
        if type == DSDataType.Time:
            return 0

    def addRaw(self, data: bytes, status: DSStatus, time: datetime.datetime):
        '''Updates current value from raw bytes'''
        try:
            value = self.__convert(data)
            if (self.isFiltered and self.filter):
                self.filter.add(value)
                if (self.__value != self.filter.out() or self.__status != status):
                    self.changed = True
                    self.__value = self.filter.out()
                    self.__status = status
                    self.__time = time
                else:
                    self.changed = False
            else:
                if (self.__value != value or self.__status != status):
                    self.changed = True
                    self.__value = value
                    self.__status = status
                    self.__time = time
                else:
                    self.changed = False
        except Exception as error:
            log.error(f'parsing error: {error}')
            self.__status = DSStatus.invalid
            self.changed = True

    def add(self, value, status: DSStatus, time: datetime.datetime):
        '''Direct updates current value'''
        if (self.isFiltered and self.filter):
            self.filter.add(value)
            if (self.__value != self.filter.out() or self.__status != status):
                self.changed = True
                self.__value = self.filter.out()
                self.__status = status
                self.__time = time
            else:
                self.changed = False
        else:
            if (self.__value != value or self.__status != status):
                self.changed = True
                self.__value = value
                self.__status = status
                self.__time = time
            else:
                self.changed = False

    def addStatus(self, status: DSStatus, time: datetime.datetime):
        '''Updates current status & time only, without value'''
        if (self.__status.value != status.value):
            self.__status = status
            self.__time = time
            self.changed = True
        else:
            self.changed = False
        # if (self.__time != time):
        #     self.__time = time
        #     self.changed = True

    def dsPoint(self, dsClass: DSDataClass):
        return DSDataPoint(
            dsClass = dsClass, # DSDataClass.commonData,
            type = self.type,
            path = self.path,
            name = self.name,
            value = self.__value,
            status = self.__status,
            history = self.history,
            alarm = self.alarm,
            timestamp = self.__time,
        )        

    @property
    def value(self):
        '''last stored value of data point'''
        return self.__value

    @property
    def status(self):
        '''last stored status of data point'''
        return self.__status

    @property
    def time(self):
        '''last stored value timestamp'''
        return self.__time

    def __repr__(self) -> str:
        return f'S7ParsePoint( type: {self.type} | name: {self.name} | value: {self.value} | status: {self.status} | start: {self.start} | end: {self.end} | bit: {self.bit} | filter: {self.filter})'

    def __converters(self, type: DSDataType):
        '''Настраивает функцию конвертации для каждого поддерживаемого типа данных'''
        converters: dict[DSDataType, Callable] = {
            DSDataType.Bool: self.__boolFromRaw,
            DSDataType.Int: self.__intFromRaw,
            DSDataType.UInt: self.__uIntFromRaw,
            DSDataType.DInt: self.__dIntFromRaw,
            DSDataType.Word: self.__wordFromRaw,
            DSDataType.LInt: self.__lIntFromRaw,
            DSDataType.Real: self.__realFromRaw,
            DSDataType.Time: self.__timeFromRaw,
            DSDataType.Date_And_Time: self.__datetimeFromRaw,
        }
        if (type in converters.keys()):
            return converters[type]
        else:
            log.error(f'unknoun data type: {type}')
            raise TypeError(f'unknoun data type: {type}')

    def __boolFromRaw(self, value):
        try:
            # if (point.name == 'HPU.Pump1.Active' or point.name == 'HPU.Pump1.Alarm' or point.name == 'HPU.Pump2.Active' or point.name == 'HPU.Pump2.Alarm'):
            # if self.start == 8:
            #     log.info(f'path/name: {self.path}/{self.name}')
            #     log.info(f'value: {value}')
            #     log.info(f'bit: {self.bit}')
            #     log.info(f'value[start:end]: {value[self.start:self.end]}')
            #     # log.info(f'value[start:end] & self.bit: {value[self.start:self.end] & self.bit}')
            #     log.info(f'value[start:end][0]: {value[self.start:self.end][0]}')
            #     log.info(f'value[start:end][0] & self.bit: {value[self.start:self.end][0] & self.bit}')
            #     log.info(f'value[point.start:point.end][0] & point.bit: {value[point.start:point.end][0] & point.bit}')
            return 1 if value[self.start:self.end][0] & (1 << self.bit) else 0
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
    
    def __intFromRaw(self, value):
        try:
            result = int.from_bytes(value[self.start:self.end], byteorder='big', signed=True)
            return result
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
        
    
    def __uIntFromRaw(self, value):
        try:
            return int.from_bytes(value[self.start:self.end], byteorder='big', signed=False)
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
    
    def __dIntFromRaw(self, value):
        try:
            return int.from_bytes(value[self.start:self.end], byteorder='big', signed=True)
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
    
    def __wordFromRaw(self, value):
        try:
            return int.from_bytes(value[self.start:self.end], byteorder='big', signed=False)
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True

    def __lIntFromRaw(self, value):
        try:
            return int.from_bytes(value[self.start:self.end], byteorder='big', signed=True)
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
    
    def __realFromRaw(self, value) -> float | None:
        try:
            # vReal = format(vReal, '.7f') - to be deleted
            return np.frombuffer(value[self.start:self.end], dtype='>f4')[0]
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} {self.start}:{self.end}\n\tfor value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
    
    def __timeFromRaw(self, value):
        try:
            return int.from_bytes(value[self.start:self.end], byteorder='big', signed=True)
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
    
    def __datetimeFromRaw(self, value):
        try:
            v = int.from_bytes(value[self.start + 6:self.start + 8], byteorder='big', signed=False)
            msec1 = v >> 4 & 0b1111
            msec2 = v >> 8 & 0b1111
            msec3 = v >> 12 & 0b1111
            return f'''{self.__intFromByteBy4Bits(value[self.start + 0:self.start + 1])}-\
{self.__intFromByteBy4Bits(value[self.start + 1:self.start + 2])}-\
{self.__intFromByteBy4Bits(value[self.start + 2:self.start + 3])} \
{self.__intFromByteBy4Bits(value[self.start + 3:self.start + 4])}:\
{self.__intFromByteBy4Bits(value[self.start + 4:self.start + 5])}:\
{self.__intFromByteBy4Bits(value[self.start + 5:self.start + 6])}:\
{msec3}{msec2}{msec1}'''
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {value}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True

    def __intFromByteBy4Bits(self, bytes: bytes):
        try:
            value = int.from_bytes(bytes, byteorder='big')
            l = value >> 0 & 0b1111
            h = value >> 4 & 0b1111
            return f'{h}{l}'
        except Exception as error:
            log.error(f'convertion error in tag: {self.path}/{self.name} for value: {bytes}\n\tdetails: {error}')
            self.__status = DSStatus.invalid
            self.changed = True
