import logging
import threading
import src.app_logger as app_logger
from time import sleep
from queue import Queue
from typing import Generator
from threading import Thread
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.ds.ds_data_point_path import DSDataPointPath
from src.infrostructure.s7.s7_client import S7Client
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.s7.s7_read_raw import S7ReadRaw
from src.infrostructure.s7.s7_write_data import S7WriteData, WriteResult
from src.infrostructure.s7.s7_raw_stream import S7RawStream
from src.infrostructure.s7.s7_parse_stream import S7ParseStream

log = app_logger.get_logger('S7Ied', level = logging.INFO)

class S7Ied(Thread):
    '''
    Берет уровень S7DbConfig из S7IedConfig конфигурации
        запускает для каждого S7Db S7ParseStream:
    '''
    def __init__(self,
        path: str,
        name: str,
        config: S7IedConfig,
        s7ClientRead: S7Client,
        s7ClientWrite: S7Client,
        daemon: bool = False
    ) -> None:
        self.__cancel = False
        self.__isActive = False
        self.__path = path
        self.__name = name
        self.__queue = Queue[DSDataPoint]()
        self.__config = config
        self.__s7ClientRead = s7ClientRead
        self.__s7ClientWrite = s7ClientWrite
        self.__dbs: dict[str, S7ParseStream] = {}
        self.__dbStreams: dict[str, Generator[DSDataPoint | None, None, None]] = {}
        self.__readDelay = self.__detectReadDelay()
        super(S7Ied, self).__init__(
            name = f'{self.__config.name}.Thread',
            daemon = daemon,
        )

    def __detectReadDelay(self):
        '''Определяет оптимальный период опроса с учетом задержки во всех DB.
        Берет меньший readDelay (мс) из всех DB и ищет для него делитель из ряда 1,10,100.. 
        который даст результат деления > 10, его использует как основной период опроса.'''
        delays = []
        for dbKey, dbConf in self.__config.dbs.items():
            delay = dbConf.delay
            log.info(f'{self.__name} readDelay: {delay}ms')
            delays.append(delay)
        minDelay = min(delays)
        for k in [1000000000,100000000,10000000,1000000,100000,10000,1000,100,10,1]:
            if (minDelay / k) > 10:
                log.info(f'S7Ied {self.__path}/{self.__name} readDelay: {k}ms')
                return k
        return 1

    def run(self):
        '''Запускайт объект в работу методом start для работы в отдельном потоке.'''
        log.info(f'S7Ied "{self.__config.name}" starting in thread: {threading.current_thread().name}...')
        for dbKey, dbConf in self.__config.dbs.items():
            log.debug(f'dbConfig: {dbConf}')
            # if (not self.__s7ClientRead.active):
            self.__s7ClientRead.connectInThread()
            # if (not self.__s7ClientWrite.active):
            sleep(100 / 1000)
            self.__s7ClientWrite.connectInThread()
            db = S7ParseStream(
                path = self.__path + '/' + self.__name,
                name = dbKey,
                config = dbConf,
                rawStream = S7RawStream(
                    name = dbConf.name,
                    readRaw = S7ReadRaw(
                        dbConfig = dbConf,
                        s7Client = self.__s7ClientRead,
                    ),
                    writeData = S7WriteData(
                        dbConfig = dbConf,
                        s7Client = self.__s7ClientWrite,
                    ),
                )
            )
            self.__dbs[dbKey] = db
            self.__dbStreams[dbKey] = db.stream
        self.__read()
        log.info(f'{self.__path}/{self.__name} exit')
        # log.info(f'S7Ied "{self.__config.name}" started in thread: {threading.current_thread().name}...')

    @property
    def queue(self):
        '''Returns the queue object of [DSDataPoint]'''
        return self.__queue

    def __read(self):
        self.__isActive = True
        log.info(f'{self.__name} started with readDelay: {self.__readDelay}ms')
        while not self.__cancel:
            for dbKey in self.__dbStreams:
                if self.__cancel:
                    break
                dbReady = self.__dbs[dbKey].delayExceeded()
                if dbReady:
                    # log.info(f'{dbKey} ready: {dbReady}')
                    dbStream = self.__dbStreams[dbKey]
                    try:
                        # TODO error handling for queue is full to be implemented
                        self.__readFromDbStream(dbStream)
                    except StopIteration:
                        log.info(f'error: StopIteration')
                        self.cancel()
                        break
            else:           # only executed if the inner loop did NOT break
                sleep(self.__readDelay / 1000)
                continue
            break           # only executed if the inner loop did break
        self.__isActive = False
        # log.info(f'{self.__path}/{self.__name} exit')

    def __readFromDbStream(self, dbStream):
        for event in dbStream:
            # log.info(f'event: {event}')
            if event != None:
                # log.info(f'event: {event}')
                self.__queue.put(event)
            else:
                break

    def requestAll(self):
        '''Команда контроллеру прислать все тэги'''
        log.debug(f'{self.__path}/{self.__name} all tags requested')
        for dbKey in self.__dbs:
            db = self.__dbs[dbKey]
            db.requestAll()    

    def requestList(self, pointNames: set[str]):
        '''Команда контроллеру прислать список тэгов'''
        log.debug(f'{self.__path}/{self.__name} list of tags requested: {pointNames}')
        for dbKey in self.__dbs:
            db = self.__dbs[dbKey]
            db.requestList(pointNames)    

    def writeInt(self,
        path: str,
        name: str, 
        value: int,
    ):
        try:
            db = DSDataPointPath(path).db()
            # log.info(f'db: {db}')
            # log.info(f'db list: {self.__dbs}')
            return self.__dbs[db].writeInt(
                name = name, 
                value = value,
            )
        except (AssertionError, Exception) as err:
            return WriteResult(
                error = Exception(f'Wrong DB name in path: {path},\nerror: {err}')
            )


    def writeReal(self,
        path: str,
        name: str, 
        value: int,
    ):
        db = DSDataPointPath(path).db()
        return self.__dbs[db].writeReal(
            name = name, 
            value = value,
        )

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        for dbKey in self.__dbs:
            db = self.__dbs[dbKey]
            db.cancel()
            while db.isActive:
                log.info(f'{self.__name} waiting for {dbKey} in thread: {threading.current_thread().name}...')
                sleep(500 / 1000)
        self.__s7ClientRead.cancel()
        self.__s7ClientWrite.cancel()
        self.__cancel = True
            # del db
        return CancelResult(
            done = True,
        )

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'{self.__path}/{self.__name} deleted')
