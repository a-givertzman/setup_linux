import logging
import threading
import src.app_logger as app_logger
from typing import Callable
from datetime import datetime
from src.domain.core.result import CancelResult
from src.infrostructure.s7.s7_write_data import S7WriteData
from src.infrostructure.s7.s7_read_raw import ReadResult, S7ReadRaw

log = app_logger.get_logger('S7RawStream', level = logging.INFO)

class S7RawStream:
    '''Этот класс читает данные из S7 IED и выдает их в stream (Generator), 
        объединяет в себе:
        snap7.client.Client() - активное подключение к S7 IED,
        S7ReadRaw - чтение единичного блока данных,
        S7WriteData - запись единичного сигнала.'''
    def __init__(self, 
        readRaw: S7ReadRaw,
        writeData: S7WriteData,
        name: str | None = None
    ):
        self.name = name
        self.__cancel = False
        self.__isActive = False
        self.__readRaw = readRaw
        self.__writeData = writeData
        self.__writingTime = 0
        self.__writeIndex = 0
        self.__lastReadTime = datetime.now()

    @property
    def stream(self):
        '''Returns the stream (Generator) object of raw data'''
        return self.__read()

    def __read(self):
        log.info(f'start reading in thread: {threading.current_thread().name}')
        self.__isActive = True
        while not self.__cancel:
            readResult: ReadResult = self.__readRaw.read()
            # log.info(f'readResult: {readResult}')
            yield readResult
        self.__isActive = False
        # log.info(f'stop reading in thread: {threading.current_thread().name}')
        log.info(f'exit')
        
    def write(self, 
        offset: int, 
        buffer: bytes, 
        onDone: Callable | None = None,
    ):
        # t1 = datetime.datetime.now()
        result = self.__writeData.write(
            offset = offset, 
            buffer = buffer,
            onDone = onDone,
        )
        # t2 = datetime.datetime.now()
        # self.__writingTime = int((t2 - t1).microseconds / 1000)
        return result

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        log.debug(f'cancel in thread: {threading.current_thread().name}...')
        self.__cancel = True
        return CancelResult(done = True)

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')

    def __getIedInfo(self):
        return self.__readRaw.getIedInfo()
