import struct
import logging
import threading
import numpy as np
import src.app_logger as app_logger
from typing import Callable
from src.domain.ds.ds_status import DSStatus
from src.domain.core.filter.filter import Filter
from src.domain.ds.ds_data_type import DSDataType
from src.domain.ds.ds_data_class import DSDataClass
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.core.stream.stream_controller import StreamController
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_parse_point import S7ParsePoint
from src.infrostructure.s7.s7_read_raw import ReadResult
from src.infrostructure.s7.s7_raw_stream import S7RawStream


log = app_logger.get_logger('S7ParseRaw', level = logging.INFO)

class S7ParseRaw:
    '''
    Этот класс читает сырые данные (byteArray) из S7ReadRaw
    и выдает их возвращает формате DSDataPoint, 
    поддерживает типы:
        int
        float
        string
        DateTime
    как читать данные и как их разбирать класс знает из конфигурации S7Config
    '''
    def __init__(self, 
        path: str,
        name: str,
        config: S7DbConfig,
        rawStream: S7RawStream,
    ):
        self.__path = path
        self.__name = name
        self.__rawStream = rawStream
        self.__points: dict[str, S7ParsePoint] = {}
        for dbPointCinfig in config.data:
            self.__points[dbPointCinfig.name] = S7ParsePoint(
                type = dbPointCinfig.type,
                path = dbPointCinfig.path + '/' + self.__name,
                name = dbPointCinfig.name,
                offset = dbPointCinfig.offset,
                bit = dbPointCinfig.boolBit,
                filter = Filter(
                    factor = 1,
                    threshold = dbPointCinfig.threshHold,
                    initialValue= dbPointCinfig.value,
                ) if (dbPointCinfig.threshHold > 0) else None,
            )
        self.isReading = False
        self.isCanceled = False
        self.__streamController = StreamController(
            onPause = None, 
            onResume = None, 
            onCancel = None, 
            onListen = self.__onListen,
        )
        self.__coverts: dict[DSDataType, Callable] = {
            DSDataType.Bool: self.__boolFromRaw,
            DSDataType.Int: self.__intFromRaw,
            DSDataType.UInt: self.__uIntFromRaw,
            DSDataType.DInt: self.__dIntFromRaw,
            DSDataType.Word: self.__wordFromRaw,
            DSDataType.LInt: self.__lIntFromRaw,
            DSDataType.Real: self.__realFromRaw,
            DSDataType.Time: self.__timeFromRaw,
            DSDataType.Date_And_Time: self.__datetimeFromRaw,
        }

    def run(self):
        log.info(f'starting in thread {threading.activeCount()}: {threading.current_thread().name}')
        self.__rawStream.start()
        log.info(f'rawStream started in thread {threading.activeCount()}: {threading.current_thread().name}')

    def __onData(self, event: ReadResult):
        if (event.hasData):
            for key in self.__points:
                point = self.__points[key]
                status = DSStatus.ok
                try:
                    convert = self.__coverts[point.type]
                except Exception as error:
                    log.error(f'uncnoun converter name: {point.type}\n\terror: {error}')
                    status = DSStatus.invalid
                try:
                    value = convert(point, event.data.data)
                except Exception as error:
                    log.error(f'parsing error: {error}')
                    status = DSStatus.invalid
                point.add(
                    value,  #self.__coverts[point.type](point, event.data.data),
                    status,
                    event.data.time
                )
                if (point.changed):
                    dsPoint = DSDataPoint(
                        dsClass = DSDataClass.commonData,
                        type = point.type,
                        path = point.path,
                        name = point.name,
                        value = point.value,
                        status = point.status,
                        timestamp = event.data.time
                    )
                    # log.info(f'[{threading.current_thread().name}] {dsPoint}')
                    self.__streamController.add(dsPoint)
        elif (event.hasError):
            self.__streamController.addError(event.error)

    def __onError(self, error: Exception):
        self.__streamController.addError(error)
        # log.info(f'event.error: {error}')

    def __onDone(self):
        self.__streamController.close()
        log.info(f'Done!')

    def __onListen(self):
        log.info(f'__onListen')
        self.__rawStream.stream().listen(
            onData = self.__onData,
            onDone = self.__onDone,
            onError = self.__onError,            
        )

    @property
    def stream(self):
        '''
        Returns the stream object of raw data
        Args: None\n
        ________________________\n
        Returns: 
            stream: Stream
        '''
        return self.__streamController.stream

    def requestAll(self):
        '''
        Команда прислать все тэги
        '''
        log.info(f'sending all tags:')
        # log.info(self.__points)
        for key in self.__points:
            point = self.__points[key]
            if (point.value != None):
                self.__streamController.add(
                    DSDataPoint(
                        dsClass = DSDataClass.commonData,
                        type = point.type,
                        name = point.name,
                        value = point.value,
                        status = point.status,
                        timestamp = point.time,
                    )
                )

    def writeInt(self, 
        name: str, 
        value: int,
        onDone: Callable = None,
        length: int = 2,
        byteOrder: str = 'big',
        signed: bool = True
    ):
        '''
        Отправляет команду со значением типа int
        name: имя сигнала в db конфигурации,
        value: int value to be written to ied current connection
        onDone: callback on write complete
        '''
        if (name in self.__points.keys()):
            return self.__rawStream.write(
                offset = self.__points[name].start,
                buffer = intToBytearray(value, length, byteOrder, signed),
                onDone = onDone,
            )
        else:
            log.warning(f'write failed: key \"{name}\" is not in configured data list')

    def writeReal(self, 
        name: str, 
        value: float,
        onDone: Callable = None,
        length: int = 4,
        byteOrder: str = 'big',
    ):
        '''
        Отправляет команду со значением типа Real
        name: имя сигнала в db конфигурации,
        value: int value to be written to ied current connection
        onDone: callback on write complete
        '''
        if (name in self.__points.keys()):
            return self.__rawStream.write(
                offset = self.__points[name].start,
                buffer = floatToBytearray(value, length, byteOrder),
                onDone = onDone,
            )
        else:
            log.warning(f'write failed: key \"{name}\" is not in configured data list')

    def __boolFromRaw(self, point: S7ParsePoint, value):
        # if (point.name == 'HPU.Pump1.Active' or point.name == 'HPU.Pump1.Alarm' or point.name == 'HPU.Pump2.Active' or point.name == 'HPU.Pump2.Alarm'):
        #     log.info(f'point.bit: {point.bit}')
        #     log.info(f'value[point.start:point.end][0]: {value[point.start:point.end][0]}')
        #     log.info(f'value[point.start:point.end][0] & point.bit: {value[point.start:point.end][0] & point.bit}')
        return 1 if int(value[point.start:point.end][0] & point.bit) > 0 else 0
    
    def __intFromRaw(self, point: S7ParsePoint, value):
        return int.from_bytes(value[point.start:point.end], byteorder='big', signed=True)
    
    def __uIntFromRaw(self, point: S7ParsePoint, value):
        return int.from_bytes(value[point.start:point.end], byteorder='big', signed=False)
    
    def __dIntFromRaw(self, point: S7ParsePoint, value):
        return int.from_bytes(value[point.start:point.end], byteorder='big', signed=True)
    
    def __wordFromRaw(self, point: S7ParsePoint, value):
        return int.from_bytes(value[point.start:point.end], byteorder='big', signed=False)

    def __lIntFromRaw(self, point: S7ParsePoint, value):
        return int.from_bytes(value[point.start:point.end], byteorder='big', signed=True)
    
    def __realFromRaw(self, point: S7ParsePoint, value):
        return format(np.frombuffer(value[point.start:point.end], dtype='>f4')[0], '.7f')
    
    def __timeFromRaw(self, point: S7ParsePoint, value):
        return int.from_bytes(value[point.start:point.end], byteorder='big', signed=True)
    
    def __datetimeFromRaw(self, point: S7ParsePoint, value):
        v = int.from_bytes(value[point.start + 6:point.start + 8], byteorder='big', signed=False)
        msec1 = v >> 4 & 0b1111
        msec2 = v >> 8 & 0b1111
        msec3 = v >> 12 & 0b1111
        return f'''{self.__intFromByteBy4Bits(value[point.start + 0:point.start + 1])}-\
{self.__intFromByteBy4Bits(value[point.start + 1:point.start + 2])}-\
{self.__intFromByteBy4Bits(value[point.start + 2:point.start + 3])} \
{self.__intFromByteBy4Bits(value[point.start + 3:point.start + 4])}:\
{self.__intFromByteBy4Bits(value[point.start + 4:point.start + 5])}:\
{self.__intFromByteBy4Bits(value[point.start + 5:point.start + 6])}:\
{msec3}{msec2}{msec1}'''

    def __intFromByteBy4Bits(self, bytes: bytearray):
        value = int.from_bytes(bytes, byteorder='big')
        l = value >> 0 & 0b1111
        h = value >> 4 & 0b1111
        return f'{h}{l}'

    async def cancel(self,
        onDone: Callable = None,
    ):
        self.__streamController.close()
        return await self.__rawStream.cancel(
            onDone = onDone,
        )


def intToBytearray(value, length, byteOrder, signed):
    _bytes = int(value).to_bytes(byteorder = byteOrder, signed = signed, length = length)
    # log.info(f'_bytes: {_bytes}')
    # buffer = bytearray(_bytes)
    # log.info(f'buffer: {buffer}')
    return _bytes #buffer

def floatToBytearray(value, length, byteOrder):
    _bytes = struct.pack('>f', value)
    # log.info(f'_bytes: {_bytes}')
    # buffer = bytearray(_bytes)
    # log.info(f'buffer: {buffer}')
    return _bytes #buffer

