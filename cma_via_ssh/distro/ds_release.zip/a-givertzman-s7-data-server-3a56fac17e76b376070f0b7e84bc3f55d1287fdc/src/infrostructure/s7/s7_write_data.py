import threading
import time
import logging
import src.app_logger as app_logger
from enum import Enum, auto
from threading import Thread
from typing import Callable
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_client import S7Client

log = app_logger.get_logger('S7WriteData', level = logging.INFO)

class WriteStatus(Enum):
    done = auto()


class WriteResultData:
    def __init__(self,
        time: str = None,
        queue: str = None,
        code: int = None,
        error: Exception = None,
    ) -> None:
        self.hasData = code != None
        self.hasTime = time != None
        self.hasError = error != None
        self.error = error
        self.code = code
        self.time = time
        self.queue = queue


class WriteResult:
    def __init__(self,
        error: Exception = None,
        data: int = None,
    ) -> None:
        self.hasData = data != None
        self.hasError = error != None
        self.error = error
        self.data = data


class S7WriteData(Thread):
    '''
    Этот класс пишет один блок данных в S7Client
    в отдельном потоке (threading.Tread)
    '''
    def __init__(self, 
        dbConfig: S7DbConfig,
        s7Client: S7Client,
    ):
        assert type(s7Client) is S7Client, 's7Client must be of "S7Client" type'
        assert type(dbConfig) is S7DbConfig, 'dbConfig must be of S7DbConfig type'
        self.__s7Client = s7Client
        self.__connection = s7Client.connection
        self.config = dbConfig
        super(S7WriteData, self).__init__(
            daemon = True,
            name = 'S7WriteData'
        )

    def write(self, 
        offset, 
        buffer,
        onDone: Callable | None = None,
    ) -> WriteResult:
        """
        method make single write to S7 IED: 
            - offset: int - offset of address of data point to be written, 
            - buffer: bytearray - to be written to IED current connection, 
            - onDone: callback(result: WriteResult) - callback method with result in the argument, 
        """
        result = self.run(
            config = self.config,
            offset = offset,
            buffer = buffer,
        )
        if (callable(onDone)):
            onDone(result)
        return result

    def run(self, 
        config: S7DbConfig, 
        offset: int, 
        buffer: bytearray, 
    ) -> WriteResult:
        log.debug(f'write event: {offset}, value: {buffer}')
        if (self.__s7Client.connected):
            connection = self.__s7Client.connection
            if connection:
                try:
                    writeResult = connection.db_write(
                        config.dbNumber, 
                        offset,
                        buffer,
                    )
                    # log.info(f'    writeResult code: {writeResult}')
                    return WriteResult(
                        data = WriteStatus.done if (writeResult == None) else writeResult,
                    )
                except Exception as err:
                    log.warning(f'[{threading.current_thread().name}] write failed (dbNumber: {config.dbNumber}):\n\t{type(err)} : {err.args}')
                    self.__s7Client.disconnect()
                    return WriteResult(
                        error = err,
                    )
            else:
                log.info(f'Write failed, S7Client not connected')
                return WriteResult(
                    error = Exception('Write failed, S7Client not connected'),
                )
        else:
            log.info(f'Write failed, S7Client not connected')
            return WriteResult(
                error = Exception('Write failed, S7Client not connected'),
            )
