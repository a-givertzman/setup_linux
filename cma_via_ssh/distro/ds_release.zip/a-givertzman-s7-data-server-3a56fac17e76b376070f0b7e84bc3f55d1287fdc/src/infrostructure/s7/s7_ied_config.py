import ipaddress
from typing import Any
from src.domain.ds.ds_data_point_attribute import DSDataPointAttribute
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.ds.config.ds_ied_config import DSIedConfig
from src.infrostructure.ds.config.ds_point_config import DSPointConfig

def isIpv4(string):
    try:
        ipaddress.IPv4Network(string)
        return True
    except ValueError:
        return False


class S7IedConfig(DSIedConfig):
    '''
    configuration of S7 IED
        stored in the config file 
        consits of:
            'name': str - the description to identify the IED, 
            'ip': str - ip address of the IED like '192.168.120.141', 
            'rack': int - rack address, 
            'slot': int - slot address, 
            'db': {
                'dbX': {
                    S7DbConfig data
                }
                ...
                'dbN': {
                    S7DbConfig data
                }
            }
    '''
    def __init__(self,
        path: str,
        name: str,
        conf: dict[str, Any],
    ):
        description: str = conf['description']
        ip: str = conf['ip']
        rack: int = conf['rack']
        slot: int = conf['slot']
        db: dict[str, Any] = conf['db']
        port: int = int(conf['port']) if 'port' in conf.keys() else 102
        assert (isinstance(ip, str) and isIpv4(ip)),\
            f'ip address "{ip}" is not valid'
        assert (isinstance(rack, int) and (rack >= 0 and rack <= 31)),\
            f'rack address should be int in between 0...31, but given {rack} {type(rack)}'
        assert isinstance(slot, int) and (slot >= 0 and slot <= 15),\
            f'slot address should be int in between 0...15, but given {slot} {type(slot)}'
        self.path = path
        self.name = name
        self.description = description
        self.ip = ip
        self.rack = rack
        self.slot = slot
        self.port = port
        self.dbs: dict[str, S7DbConfig] = {}
        for key, dbConf in db.items():
            self.dbs[key] = S7DbConfig(
                path = f'{path}/{name}',
                name = key,
                conf = dbConf
            )
        # self.delay = delay

    def points(self, attr: DSDataPointAttribute | None = None, value: Any = None) -> dict[str, DSPointConfig]:
        '''Возвращает конфигурации точек данных,
            - если аттрибут [attr] не задан (None) то метод вернет все точки данных,
            - если аттрибут [attr] присутствует в точке данных, когда [value] не задано (None),
            - если аттрибут [attr] равен [value], когда [value] задано.'''
        points: dict[str, DSPointConfig] = {}
        for pointKey, dbConf in self.dbs.items():
            points.update(
                dbConf.points(attr = attr, value = value)
            )
        return points

    def __repr__(self) -> str:
        return f'S7IedConfig(\npath: {self.path} | name: {self.name} | description: {self.description} | ip: {self.ip} | rack: {self.rack} | slot: {self.slot} | port: {self.port} | db: {self.dbs}\n)'
