import logging
import src.app_logger as app_logger
from src.domain.ds.ds_data_type import DSDataType
from src.infrostructure.ds.store_fault.ds_fault_params import DSFaultParams
from src.infrostructure.ds.config.ds_point_config import DSPointConfig

log = app_logger.get_logger('S7DbPointConf', level = logging.WARNING)

class S7DbPointConf(DSPointConfig):
    '''
    config of raw data point 
        processing parameters stored and loads from config file
        consists of:
            type: S7 Data Type.name - 'Int', 'UInt', 'Real' etc.
            offset: int - address offset in S7 db
            threshold: int - 0...100% parameter for data points to be filtered
    '''
    def __init__(self,
        type: DSDataType,
        path: str,
        name: str,
        history: int,
        alarm: int,
        fr: DSFaultParams | None,
        offset: int,
        boolBit: int = 0x00,
        threshold: int = 0,
        id: str = ''
    ):
        self.id = id
        self.type = type
        self.path = path
        self.name = name
        self.history = history
        self.alarm = alarm
        self.offset = offset
        self.end = offset + self.type.value.length
        self.boolBit = boolBit
        self.threshold = threshold
        self.fr = fr
        self.value = 0.0

    @classmethod
    def fromRow(cls, row: dict, name: str, path: str):
        log.info(f'row: {row}')
        return S7DbPointConf(
            id = row['id'] if 'id' in row else '',
            type = DSDataType.fromString(row['type']),
            path = path,
            name = name,
            history = row['h'] if 'h' in row else 0,
            alarm = row['a'] if 'a' in row else 0,
            fr = DSFaultParams(
                conf = row['fr'],
            ) if 'fr' in row else None,
            offset = row['offset'],
            boolBit = row['bit'] if 'bit' in row else 0x00,
            threshold = row['threshold'] if 'threshold' in row else 0
        )

    def __repr__(self) -> str:
        return f'S7DbPoint( id: {self.id} | type: {self.type} | path: {self.path} | name: {self.name}\n\t\thistory: {self.history} | alarm: {self.alarm}\n\t\toffset: {self.offset} | end: {self.end} | bit: {self.boolBit} | threshold: {self.threshold}\n\t\tfr: {self.fr})'