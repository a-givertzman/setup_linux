import logging
import src.app_logger as app_logger
from typing import Any
from src.domain.ds.ds_data_point_attribute import DSDataPointAttribute
from src.infrostructure.ds.config.ds_point_config import DSPointConfig
from src.infrostructure.s7.s7_point_config import S7DbPointConf

log = app_logger.get_logger('S7DbConfig', level = logging.DEBUG)


class S7DbConfig:
    '''
    configuration of the DB blok of S7 IED
        stored in the config file 
        consits of:
            'number': int - number of the S7 DB block, 
            'offset': int - start adress of block, 
            'size': int - last datapoint offset + last data point size,
            'delay': int - delay in milliseconds between read request to S7 IED for current DB,
            'data': {   - data points
                'name1': {S7PointConfig data },
                ...,
                'nameN': {S7PointConfig data },
            }

    '''
    def __init__(self,
        path: str,
        name: str,
        conf: dict[str, Any]
        # description: str,
        # dbNumber: int,
        # dbOffset: int,
        # dbSize: int,
        # data: dict,
        # delay: int = 100,
    ):
        description: str = conf['description']
        dbNumber: int = conf['number']
        dbOffset: int = conf['offset']
        dbSize: int = conf['size']
        data: dict = conf['data']
        delay: int = int(conf['delay']) if conf['delay'] else 100
        assert isinstance(dbNumber, int) and (dbNumber >= 1 and dbNumber <= 1024),\
            f'dbNumber should be int in between 1...1024, but given {dbNumber} {type(dbNumber)}'
        assert isinstance(dbOffset, int) and (dbOffset >= 0 and dbOffset <= 65534),\
            f'dbOffset should be int in between 0...65534, but given {dbOffset} {type(dbOffset)}'
        assert isinstance(dbSize, int) and (dbSize >= 1 and dbSize <= 65535),\
            f'dbSize should be int in between 1...65535, but given {dbSize} {type(dbSize)}'
        self.path = path
        self.name = name
        self.description = description
        self.dbNumber = dbNumber
        self.dbOffset = dbOffset
        self.dbSize = dbSize
        self.delay = delay
        self.data: dict[str, DSPointConfig] = {}
        for key, row in conf['data'].items():
            self.data[key] = S7DbPointConf.fromRow(
                row = row, 
                name = key, 
                path = path
            )

    def points(self, attr: DSDataPointAttribute | None = None, value: Any = None) -> dict[str, DSPointConfig]:
        '''Возвращает конфигурации точек данных,
            - если аттрибут [attr] не задан (None) то метод вернет все точки данных,
            - если аттрибут [attr] присутствует в точке данных, когда [value] не задано (None),
            - если аттрибут [attr] равен [value], когда [value] задано.'''
        points: dict[str, DSPointConfig] = {}
        if (attr):
            for pointKey, point in self.data.items():
                attrValue = None
                if (attr == DSDataPointAttribute.id):
                    if (point.id):
                        points[pointKey] = point
                        attrValue = point.id
                if (attr == DSDataPointAttribute.pointType):
                    if (point.type):
                        points[pointKey] = point
                        attrValue = point.type
                elif (attr == DSDataPointAttribute.pointPath):
                    if (point.path):
                        points[pointKey] = point
                        attrValue = point.path
                elif (attr == DSDataPointAttribute.pointName):
                    if (point.name):
                        points[pointKey] = point
                        attrValue = point.name
                # elif (attr == DSDataPointAttribute.pointValue):
                #     if (point.value):
                #         points[pointKey] = point
                #         attrValue = point.value
                elif (attr == DSDataPointAttribute.history):
                    if (point.history):
                        points[pointKey] = point
                        attrValue = point.history
                elif (attr == DSDataPointAttribute.alarm):
                    if (point.alarm):
                        points[pointKey] = point
                        attrValue = point.alarm
                elif (attr == DSDataPointAttribute.fr):
                    if (point.fr):
                        points[pointKey] = point
                        attrValue = point.fr
                elif (attr == DSDataPointAttribute.frParams):
                    if (point.frParams):
                        points[pointKey] = point
                        attrValue = point.frParams
                # elif (attr == DSDataPointAttribute.timestamp):
                #     if (points[pointKey].timestamp):
                #         points[pointKey] = point
                #         attrValue = point.timestamp
                else:
                    pass
                if (attrValue):
                    if (value != None):
                        if (attrValue == value):
                            points[pointKey] = point
                    else:
                        points[pointKey] = point
        else:
            for pointKey, point in self.data.items():
                points[pointKey] = point
        return points

    def __repr__(self) -> str:
        return f'S7DbConfig(name: {self.name} | dbNumber: {self.dbNumber} | dbOffset: {self.dbOffset} | dbSize: {self.dbSize} | delay: {self.delay} | db: {self.data}\n)'