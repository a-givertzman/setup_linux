import time
import snap7
import logging
import threading
import src.app_logger as app_logger
from src.infrostructure.s7.s7_ied_config import S7IedConfig

log = app_logger.get_logger('S7Client', level = logging.INFO)


class ConnectResult:
    def __init__(self,
        error: Exception = None,
        pending: bool = False,
        connection: snap7.client.Client = None,
        code: int = None,
    ) -> None:
        self.hasData = connection != None
        self.hasError = error != None
        self.error = error
        self.pending = pending
        self.connection = connection
        self.code = code

    def __repr__(self) -> str:
        return f'ConnectResult(hasData: {self.hasData} | connection: {self.connection} | hasError: {self.hasError} | error: {self.error} | code: {self.code} | pending: {self.pending})'


class S7Client(threading.Thread):
    '''
    Этот класс устанавливает подключение к S7 IED
        - reconnectDelay - таймаут (в миллисекундах) 
        повторного подключени при ошибке
        или при обрыве подключения
    '''
    def __init__(self, 
        iedConfig: S7IedConfig,
        reconnectDelay: int = 0,
        name: str = None
    ):
        '''reconnectDelay: int - delay in milliseconds to wait before reconnect,
            if 0 - without reconnection '''
        assert isinstance(iedConfig, S7IedConfig),\
            'iedConfig must be object instance of IedConfig'
        self.lock = threading.RLock()
        self.__connected = False
        self.__cancel: bool = False
        self.__isActive = False
        self.__pending: bool = False
        self.__config = iedConfig
        self.__reconnectDelay = reconnectDelay
        self.__connection: snap7.client.Client = None
        super(S7Client, self).__init__(
            name = f'{name}.Tread' if name != None else f'S7Client.Thread ({self.__config.name})',
            daemon = True
        )

    @property
    def connected(self):
        return self.__connected

    @property
    def connection(self):
        return self.__connection

    def connect(self):
        self.connectInThread()

    def connectInThread(self):
        config = self.__config
        if (self.__connected):
            log.info(f"[{threading.current_thread().name}] {config.ip} rack {config.rack} slot {config.slot} already connected")
        elif (self.__pending):
            log.info(f"[{threading.current_thread().name}] {config.ip} rack {config.rack} slot {config.slot} pending connection...")
        else:
            self.__pending = True
            self.start()

    def run(self):
        connectionErrArgs = None
        self.__cancel = False
        config = self.__config
        log.info(f"[{threading.current_thread().name}] {config.ip} rack {config.rack} slot {config.slot} connecting...")
        self.__isActive = True
        while not self.__cancel:
            result = ConnectResult(pending = True)
            if not self.__connected:
                self.__connected = False
                self.__pending = True
                try:
                    with self.lock:
                        self.__connection = snap7.client.Client()
                        code = self.__connection.connect(
                            address = config.ip,
                            rack = config.rack,
                            slot = config.slot,
                            tcpport = config.port,
                        )
                        connectionErrArgs = None
                        log.info(f"[{threading.current_thread().name}] {config.ip} rack {config.rack} slot {config.slot} connected")
                        result = ConnectResult(
                            connection = self.__connection,
                            code = code
                        )
                        self.__connected = True
                except Exception as err:
                    if connectionErrArgs != err.args:
                        connectionErrArgs = err.args
                        log.warning(f"[{threading.current_thread().name}] connection failed to {config.ip} rack {config.rack} slot {config.slot}:\n\t{type(err)} | {err.args}")
                    result = ConnectResult(
                        error = err,
                    )
                self.__pending = False
                # log.info(f"[{threading.current_thread().name}] {config.ip} rack {config.rack} slot {config.slot} connection result:\n\t{result}")
            else:
                result = ConnectResult(
                    connection = self.__connection,
                    code = code
                )
            if (self.__reconnectDelay == 0):
                return result
            time.sleep(self.__reconnectDelay / 1000)
        self.__isActive = False
        log.info(f'exit')

    def disconnect(self):
        '''Discinneting snap7.client,
            returns 0 on success disconnected or err code on fail'''
        try:
            code = self.__connection.disconnect()
            with self.lock:
                self.__connected = False
                del self.__connection
            log.info(f'disconnect done')
            log.debug(f'disconnect code:') if code != None else None
            return ConnectResult(
                code = code,
            )
        except Exception as err:
            log.error(f"disconnect error\n\t{self.__config.ip} failed: {type(err)} | {err.args}")
            return ConnectResult(
                error = err,
            )        
        
    def cancel(self):
        self.__cancel = True
        self.disconnect()

    def __del__(self):
        # if (self.__isActive):
        #     self.cancel()
        log.info(f'deleted')

