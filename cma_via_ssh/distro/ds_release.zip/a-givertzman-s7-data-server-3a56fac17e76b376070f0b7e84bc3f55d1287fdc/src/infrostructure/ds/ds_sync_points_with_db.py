import json
import socket
import logging
import src.app_logger as app_logger
from typing import Any
from src.domain.core.result import Result
from src.infrostructure.core.parse_json import ParseJson
from src.infrostructure.core.socket_client import SocketClient
from src.infrostructure.ds.config.ds_point_config import DSPointConfig

log = app_logger.get_logger('DSTagId', level = logging.INFO)


class DSSyncPointsWithDb:
    def __init__(self,
        address: tuple[str, int],
        points: dict[str, DSPointConfig],
        reconnectTimeout: int = 3000,
        daemon: bool = False,
    ) -> None:
        self.__cancel = False
        self.__address = address
        self.__points = points
        self.__sqlRequestSelect: dict[str, Any] = {
            'api-sql': '"select"', 
            'tableName': '"tags"',
            'keys': '["id", "type", "path", "name"]', 
        }
        self.__sqlRequestInsert: dict[str, Any] = {
            'api-sql': '"insert"', 
            'tableName': '"tags"',
            'keys': '["id", "type", "path", "name"]', 
        }
        self.__socketClient = SocketClient(
            address = self.__address,
            onConnected = self.__onConnected,
            reconnectTimeout = reconnectTimeout,
            daemon = daemon,
        )

    def start(self):
        self.__socketClient.start()
        self.__socketClient.join()
        log.info('exit')

    def __onConnected(self, socket: socket.socket | None):
        log.info(f'Syncronizing points with DB...')
        request: dict[str, Any] = {
            'api-sql': '"keep-alive"', 
            'tableName': '"tags"',
            'keys': '["count(*)"]', 
        }
        result = self.__send(request)
        log.debug(f'Connecting to DB result: {result}')
        if (result.hasData):
            self.__isConnected = True
            log.debug(f'Connected to the DB.')
            dbPoints = self.__getAll()
            for key in self.__points:
                if (key in dbPoints.keys()):
                    self.__points[key].id = dbPoints[key]['id']
            maxId = 1
            for key in dbPoints:
                dbPointId = int(dbPoints[key]['id'])
                if (dbPointId >= maxId):
                    maxId = dbPointId + 1
            pointsToUpdateInDb = []
            for key in self.__points:
                if (not key in dbPoints.keys()):
                    point = self.__points[key]
                    point.id = str(maxId)
                    maxId += 1
                    pointsToUpdateInDb.append(point)
            if (pointsToUpdateInDb):
                log.debug(f'adding points to the database: {pointsToUpdateInDb}')
                result = self.__setTags(pointsToUpdateInDb)
                log.debug(f'adding point result: {result}')
                if (result.hasError):
                    log.warning(f'Stored points syncronisation error: {result.error}')
                else:
                    log.info(f'Stored points has been synchronized with DB')
            else:
                log.info(f'Stored points synchronized with DB')
        else:
            log.warning(f'Stored points syncronisation error: {result.error}')
        self.__socketClient.cancel()
        

        # self.__socketClient.send()

    def __send(self, params: dict):
        _jsonData = json.dumps(params)
        _bytes = _jsonData.encode('utf-8')
        errNo = self.__socketClient.send(_bytes)
        if (errNo == 0):
            return Result.fromParseJson(
                ParseJson(next(self.__socketClient.stream))
            )
        return Result(
            error = Exception(f'Ошибка при отправке запроса:\n\t{_jsonData}.')
        )

    def __getAll(self):
        '''Возвращает записи всех тегов из базы данных'''
        points: dict[str, dict] = {}
        result = self.__send(self.__sqlRequestSelect)
        if (result.hasData):
            data: dict = result.data
            for key in data:
                row = data[key]
                points[row['name']] = row
        return points

    def __setTags(self, points: list[DSPointConfig]):
        if (points):
            sqlValues = '['
            for point in points:
                sqlValues += f'["{point.id}", "{point.type.name}", "{point.path}", "{point.name}"],'
            sqlValues = sqlValues[:(len(sqlValues) - 1)]
            sqlValues += ']'
            self.__sqlRequestInsert['values'] = sqlValues
            return self.__send(self.__sqlRequestInsert)
        else:
            return Result(
                error = Exception('No points for synchronization')
            )

    def join(self):
        return self.__socketClient.join()
        
    def cancel(self):
        self.__cancel = True
        self.__socketClient.cancel()




    # def getId(self, id: str):
    #     '''Возвращает запись тега с идентификатором [id] из базы данных'''
    #     request = self.__getRequest.copy()
    #     request['where'] = [
    #         {'operator': 'where', 'field': 'id', 'cond': '=', 'value': id},
    #     ]
    #     # params['orderBy'] = ['id','name']
    #     # params['order'] = ['DESC','ASC']
    #     request['limit'] = [1]
    #     return self.__send(request)

    # def getName(self, name: str):
    #     '''Возвращает запись тега с именем [name] из базы данных'''
    #     request = self.__getRequest.copy()
    #     request['where'] = [
    #         {'operator': 'where', 'field': 'name', 'cond': '=', 'value': name},
    #     ]
    #     # params['orderBy'] = ['id','name']
    #     # params['order'] = ['DESC','ASC']
    #     request['limit'] = [1]
    #     return self.__send(request)

