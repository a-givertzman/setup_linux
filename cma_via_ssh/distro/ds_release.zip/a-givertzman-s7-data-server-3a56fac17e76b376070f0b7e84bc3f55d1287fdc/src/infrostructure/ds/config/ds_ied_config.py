from typing import Any
from abc import abstractclassmethod
from src.domain.ds.ds_data_point_attribute import DSDataPointAttribute
from src.infrostructure.ds.config.ds_point_config import DSPointConfig


class DSIedConfig:
    '''Interface for Ied-level config classes'''
    @abstractclassmethod
    def points(self, attr: DSDataPointAttribute | None = None, value: Any = None) -> dict[str, DSPointConfig]:  # type: ignore
        pass