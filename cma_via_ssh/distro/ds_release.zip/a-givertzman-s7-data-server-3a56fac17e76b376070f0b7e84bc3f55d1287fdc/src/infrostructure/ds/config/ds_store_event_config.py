class DSStoreEventConfig:
    def __init__(self,
        conf: dict[str, dict],
    ) -> None:
        self.enabled: bool = bool(conf['enabled'])

