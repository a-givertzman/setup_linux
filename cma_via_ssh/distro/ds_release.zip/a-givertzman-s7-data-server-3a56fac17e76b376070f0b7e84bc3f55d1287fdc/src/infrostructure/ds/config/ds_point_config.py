from typing import Any
from abc import abstractclassmethod
from src.domain.ds.ds_data_type import DSDataType
from src.infrostructure.ds.store_fault.ds_fault_params import DSFaultParams


class DSPointConfig:
    '''Interface for DataPoint-level config classes'''
    @abstractclassmethod
    def __init__(self,
        path: str,
        name: str,
        conf: dict[str, dict],
    ) -> None:
        self.id: str
        self.type: DSDataType
        self.path: str
        self.name: str
        self.history: int | None
        self.alarm: int | None
        self.fr: DSFaultParams | None
        self.offset: int | None
        # self.end: int
        self.boolBit: int | None
        self.threshold: int | None
        self.initialValue: Any
        # self.value: Any
        # self.timestamp: datetime.datetime