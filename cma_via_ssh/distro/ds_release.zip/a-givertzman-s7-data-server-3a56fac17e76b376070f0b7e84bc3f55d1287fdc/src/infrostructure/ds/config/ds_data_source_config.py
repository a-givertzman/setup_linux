import logging
import src.app_logger as app_logger
from src.domain.ds.ds_data_point_attribute import DSDataPointAttribute
from src.infrostructure.ds.config.ds_line_config import DSLineConfig
from src.infrostructure.ds.config.ds_point_config import DSPointConfig

log = app_logger.get_logger('DSDataSourceConfig', level = logging.DEBUG)


class DSDataSourceConfig:
    def __init__(self,
        conf: dict[str, dict],
    ) -> None:
        self.enabled: bool = bool(conf['enabled'])
        self.path: str = str(conf['path'])
        self.lines: dict[str, DSLineConfig] = {}
        for lineKey, lineConf in conf['lines'].items():
            self.lines[lineKey] = DSLineConfig(
                path = self.path,
                name = lineKey,
                conf = lineConf,
            )

    def points(self,
        attr: DSDataPointAttribute | None = None,
        value = None,
    ) -> dict[str, DSPointConfig]:
        '''Возвращает конфиг точки данных,
            - если аттрибут [attr] не задан (None) то метод вернет все точки данных,
            - если аттрибут [attr] присутствует в точке данных, когда [value] не задано (None),
            - если аттрибут [attr] равен [value], когда [value] задано.'''
        points: dict[str, DSPointConfig] = {}
        for lineKey, lineConf in self.lines.items():
            # log.debug(f'line: {lineKey}')
            points.update(
                lineConf.points(attr = attr, value = value)
            )
        return points
