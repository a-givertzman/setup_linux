class DSFaultConfig:
    def __init__(self,
        conf: dict,
    ) -> None:
        self.enabled: bool = bool(conf['enabled'])
        self.bufferLength: int = int(conf['buffer_length'])
        self.delay: int = int(conf['delay'])
        self.trip: bool = bool(conf['trip'])
        # self.act = DSDaultConfigInterval(conf['interval'])

    def __repr__(self) -> str:
        return f'DSFaultConfig( enabled: {self.enabled} | bufferLength: {self.bufferLength} | interval: {self.delay} | trip: {self.trip})'