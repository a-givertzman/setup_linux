import logging
import src.app_logger as app_logger
from src.domain.ds.ds_data_point_attribute import DSDataPointAttribute
from src.infrostructure.ds.config.ds_ied_config import DSIedConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.ds.config.ds_point_config import DSPointConfig

log = app_logger.get_logger('DSDataSourceConfig', level = logging.DEBUG)


class DSLineConfig:
    def __init__(self,
        path: str,
        name: str,
        conf: dict[str, dict],
    ) -> None:
        self.path: str = path
        self.name: str = name
        self.ieds: dict[str, DSIedConfig] = {}
        for iedKey, iedConf in conf.items():
            self.ieds[iedKey] = S7IedConfig(
                path = path + '/' + name,
                name = iedKey,
                conf = iedConf,
            )

    def points(self,
        attr: DSDataPointAttribute | None = None,
        value = None,
    ) -> dict[str, DSPointConfig]:
        '''Возвращает конфиг точки данных,
            - если аттрибут [attr] не задан (None) то метод вернет все точки данных,
            - если аттрибут [attr] присутствует в точке данных, когда [value] не задано (None),
            - если аттрибут [attr] равен [value], когда [value] задано.'''
        points: dict[str, DSPointConfig] = {}
        for iedKey, iedConf in self.ieds.items():
            # log.debug(f'ied: {iedKey}')
            points.update(
                iedConf.points(attr = attr, value = value)
            )
        return points
