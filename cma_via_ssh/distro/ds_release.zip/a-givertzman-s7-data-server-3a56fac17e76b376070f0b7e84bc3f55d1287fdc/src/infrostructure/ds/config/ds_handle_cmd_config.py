from typing import Any


class DSHandleCmdConfig:
    def __init__(self,
        conf: dict[str, dict],
    ) -> None:
        self.enabled: bool = bool(conf['enabled'])
        self.filter: dict[str, Any] = conf['filter']

