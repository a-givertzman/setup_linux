import json
import logging
import src.app_logger as app_logger
from src.domain.core.result import Result
from src.domain.ds.ds_data_point_attribute import DSDataPointAttribute
from src.infrostructure.ds.ds_sync_points_with_db import DSSyncPointsWithDb
from src.infrostructure.ds.config.ds_data_source_config import DSDataSourceConfig
from src.infrostructure.ds.config.ds_send_event_config import DSSendEventConfig
from src.infrostructure.ds.config.ds_store_event_config import DSStoreEventConfig
from src.infrostructure.ds.config.ds_handle_cmd_config import DSHandleCmdConfig
from src.infrostructure.ds.config.ds_fault_config import DSFaultConfig

log = app_logger.get_logger('DSConfig', level = logging.INFO)

class DSConfig:
    '''Читает файл конфигурации
        формирует объект типа Map с полями:
        name, offset, lenth, type, comment'''
    def __init__(self,
        fileName: str,
        address: tuple[str, int],
    ) -> None:
        self.__fileNmae = fileName
        self.__apiAddress = address
        self.__config = None
        self.__dataSource: DSDataSourceConfig | None = None
        self.__sendEvent: DSSendEventConfig
        self.__storeEvent: DSStoreEventConfig
        self.__storeFault: DSFaultConfig
        self.__handleСmd: DSHandleCmdConfig


    def __build(self) -> dict:
        if (self.__config):
            return self.__config
        else:
            result = self.__load(self.__fileNmae)
            if (result.hasData):
                self.__config = result.data
                self.__dataSource = DSDataSourceConfig(
                    conf = self.__config['data_source']
                )
                self.__sendEvent = DSSendEventConfig(
                    conf = self.__config['send_event']
                )
                self.__storeEvent = DSStoreEventConfig(
                    conf = self.__config['store_event']
                )
                self.__storeFault = DSFaultConfig(
                    conf = self.__config['store_fault']
                )
                self.__handleСmd = DSHandleCmdConfig(
                    conf = self.__config['handle_cmd']
                )
                syncPointsWithDb = DSSyncPointsWithDb(
                    address = self.__apiAddress,
                    points = self.__dataSource.points(),
                )
                syncPointsWithDb.start()
                syncPointsWithDb.join()
                return self.__config
            else:
                raise Exception(f'[DSConfig.__build] Ошибка чтения файла конфигурации из: {self.__fileNmae}\n\tисключение: {result.error}')

    def __load(self, path: str):
        try:
            with open(path, mode = 'r', encoding = 'utf-8') as file:
                config = json.loads(file.read())
                log.debug(f'config: {config}')
                return Result[dict](
                    data = config,
                )
        except Exception as error:
            return Result[dict](
                error = error,
            )

    def root(self) -> dict:
        '''Возвращает корневой узел конфигурации сервера'''
        return self.__build()
    
    @property
    def dataSource(self) -> DSDataSourceConfig:
        '''Возвращает узел data_source конфигурации сервера'''
        if (not self.__config):
            self.__build()
        if (self.__dataSource):
            return self.__dataSource
        raise Exception('Ошибка доступа к self.__dataSource, не инициализирован')

    @property
    def sendEvent(self) -> DSSendEventConfig:
        '''Возвращает узел send_event конфигурации сервера'''
        if (not self.__config):
            self.__build()
        return self.__sendEvent

    @property
    def storeEvent(self) -> DSStoreEventConfig:
        '''Возвращает узел store_event конфигурации сервера'''
        if (not self.__config):
            self.__build()
        return self.__storeEvent

    @property
    def handleCmd(self) -> DSHandleCmdConfig:
        '''Возвращает узел handle_cmd конфигурации сервера'''
        if (not self.__config):
            self.__build()
        return self.__handleСmd

    @property
    def storeFault(self) -> DSFaultConfig:
        '''Возвращает узел store_fault конфигурации сервера'''
        if (not self.__config):
            self.__build()
        return self.__storeFault

    def allPoints(self):
        '''Возвращает dict все точек данных'''
        points = self.dataSource.points()
        log.info(f'all point reading done.')
        return points

    def historyPoints(self):
        '''Возвращает список имен все точек данных, содержащих атрибут "H" / "h",
            и подлежащих сохранению в таблицу "event" базы данных'''
        historyPointsList = self.dataSource.points(
            attr = DSDataPointAttribute.history,
        )
        log.info(f'hystory point reading done.')
        return historyPointsList

    def faultPoints(self):
        '''Возвращает список все точек данных, содержащих атрибут "FR" / "fr",
            и подлежащих сохранению в таблицу "fault" базы данных'''
        faultPointsList = self.dataSource.points(
            attr = DSDataPointAttribute.fr,
        )
        log.info(f'hystory point reading done.')
        return faultPointsList

    def alarmPoints(self):
        '''Возвращает список все точек данных, содержащих атрибут "A" / "a" - аварийные'''
        alarmPointsList = self.dataSource.points(
            attr = DSDataPointAttribute.alarm,
        )
        log.info(f'alarm point reading done.')
        return alarmPointsList
