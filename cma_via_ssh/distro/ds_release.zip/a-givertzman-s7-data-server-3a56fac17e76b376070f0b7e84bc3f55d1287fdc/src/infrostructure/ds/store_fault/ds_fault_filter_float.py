import datetime
import logging
import src.app_logger as app_logger
from src.domain.core.filter.threshold import Threshold, ThresholdPli
from src.domain.ds.ds_status import DSStatus
from src.domain.ds.ds_data_point import DSDataPoint
from src.infrostructure.ds.store_fault.ds_fault_filter import DSFaultFilter
from src.infrostructure.ds.store_fault.ds_fault_filter_nominal_value import DSFaultFilterNominalValue

log = app_logger.get_logger('DSFaultFilter', level = logging.INFO)


class DSFaultFilterFloat(DSFaultFilter):
    '''Фильтрует изменяющуюся входную величину [value] по интегральной мертвой зоне;
        - Принимает входящие значения через метод [add];
        - Величину мертвой зоны вычисляет исходя из входной величины [value] из уравнения threshold = a * (value ^ 2) + b * value + c;
        - Начальное значение [value] фильтр берет из [initial].'''
    def __init__(self,
        id: str,
        nominal: DSFaultFilterNominalValue,
        threshold: Threshold | None = None,
        initial: float = 0.0,
        integralFactor: float = 0.0,
    ) -> None:
        '''- nominal: float - номинальное значение фильтруемой величины;
            - initial: float - начальное значение входной фильтруемой величины;
            - a, b, c: float - коэффициенты уравнения из которого вычисляется текущая мертвая зона\n
            threshold = ( a * (value ^ 2) + b * value + c ) / nominal;
            - integralFactor: float - коэффициен суммирования, влияет на скорость обновления фильтруемой величины,\n
            если integralFactor = 0 то фильтрация будет работать по абсолютному значению разности между новым и сохраненным значением,\n
            если integralFactor > 0 то текущая разность между новым и сохраненным значением фильтруемой величины вычисляется по формуле:\n
            storedDelta = storedDelta + abs(oldValue - newValue)\n
            затем если delta > threshold то значение сразу обновляется, иначе вычисляем storedDelta += delta * integralFactor.'''
        self.id = id
        self.__value: float = initial
        self.__timestamp: datetime.datetime = datetime.datetime.now()
        self.__nominal = nominal
        self.__threshold = threshold
        self.__integralFactor = integralFactor
        self.__relativeDelta = 0
        self.__integralDelta = 0
        self.__isChanged = False
        self.__isUpdated = False

    def __delta(self, value: float):
        self.__relativeDelta = abs(self.__value - value) / self.__nominal.value
        if (self.__integralFactor > 0):
            self.__integralDelta += self.__relativeDelta * self.__integralFactor
        else:
            self.__integralDelta = self.__relativeDelta
        return self.__integralDelta

    def add(self, point: DSDataPoint | None = None):
        value = self.__value
        # log.debug(f'point: {point}')
        # log.debug(f'point.value: {point.value if point else None}')
        if (point and point.status == DSStatus.ok):
            value = point.value
            self.__timestamp = point.timestamp
        if (self.__threshold):
            if (not self.__nominal.value == 0):
                relativeThreahold = self.__threshold.y(value / self.__nominal.value)
                delta = self.__delta(value)
                # log.debug(f'point: \n\tregistered:\t{self.value}\n\tvalue:\t{value}\t{value / self.__nominal} o.e\n\tdelta:\t{delta}\n\tthreahold:\t{relativeThreahold}')
                if (delta >= relativeThreahold):
                    log.debug(f'point: \n\tregistered:\t{self.__value}\tnom: {self.__nominal.value}')
                    # log.debug(f'point: \n\tregistered:\t{self.value}\n\tvalue:\t{value}\t{value / self.__nominal} o.e\n\tdelta:\t{delta}\n\tthreahold:\t{relativeThreahold}')
                    self.__value = value
                    self.__integralDelta = 0
                    self.__isChanged = True
        else:
            # log.debug(f'point: \n\tregistered:\t{self.__value}')
            # log.debug(f'point: \n\tregistered:\t{self.value}\n\tvalue:\t{value}\t{value / self.__nominal} o.e\n\tdelta:\t{delta}\n\tthreahold:\t{relativeThreahold}')
            if (self.__value != value):
                log.debug(f'point: \n\tregistered:\t{self.__value}\tnom: {self.__nominal.value}')
                self.__value = value
                self.__isChanged = True
        self.__isUpdated = True


    @property
    def value(self) -> float:
        self.__isChanged = False
        self.__isUpdated = False
        return self.__value

    @property
    def timestamp(self) -> datetime.datetime:
        return self.__timestamp

    @property
    def isChanged(self):
        return self.__isChanged

    @property
    def isUpdated(self):
        return self.__isUpdated
