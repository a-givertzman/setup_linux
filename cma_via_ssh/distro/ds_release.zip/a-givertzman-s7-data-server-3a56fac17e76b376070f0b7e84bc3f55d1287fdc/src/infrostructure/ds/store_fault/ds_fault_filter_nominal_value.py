import logging
import src.app_logger as app_logger
from src.domain.ds.ds_status import DSStatus
from src.domain.ds.ds_data_point import DSDataPoint
from src.infrostructure.ds.store_fault.ds_fault_filter import DSFaultFilter

log = app_logger.get_logger('DSFaultFilterNominalValue', level = logging.INFO)


class DSFaultFilterNominalValue(DSFaultFilter):
    def __init__(self,
        initial: float,
    ) -> None:
        self.value = initial
        self.__isUpdated = False

    def add(self, point: DSDataPoint | None = None):
        log.debug(f'point: {point}')
        if (point and point.status == DSStatus.ok):
            log.debug(f'point.value: {point.value}')
            self.value = point.value
        self.__isUpdated = True

    @property
    def isChanged(self):
        return False

    @property
    def isUpdated(self):
        return self.__isUpdated
