import time
import socket
import logging
import threading
import src.app_logger as app_logger
from queue import Queue
from typing import Callable
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint
from src.infrostructure.core.socket_client import SocketClient
from src.infrostructure.ds.config.ds_point_config import DSPointConfig
from src.infrostructure.ds.store_fault.ds_fault_send import DSFaultSend
from src.infrostructure.ds.config.ds_fault_config import DSFaultConfig
from src.infrostructure.ds.store_fault.ds_fault_buffer import DSFaultBuffer

log = app_logger.get_logger('DSStoreFault', level = logging.DEBUG)


class DSStoreFault(threading.Thread):
    '''DataServer Store Fault (Fault Registrator) - Регистратор несправностей.
        Получает события (DSDataPoint) из потока в очередь [self.__queue].
        Циклически отправляет накопившиеся события в базу данных (MySql)
        и очищает очередь'''
    IPV4 = socket.AF_INET
    TCP = socket.SOCK_STREAM

    def __init__(self,
        queue: Queue[DSDataPoint],
        faultPoints: dict[str, DSPointConfig],
        config: DSFaultConfig,
        address = ('127.0.0.1', 8080),
        reconnectTimeout: int = 3000,
        requestList: Callable[[set[str]], None] | None = None,
        daemon: bool = False,
    ) -> None:
        '''- queue: Queue[DSDataPoint] - очередь входящих событий;
            - address: tuple[str, int] - адрес API сервера базы данных для регистрация неисправностей;
            - bufferLength: int - длина буфера регистрации неисправностей, буффер будет накапливать заданное количество записей перед отправкой в базу данных;
            - reconnectTimeout: int - таймаут в миллисекунах попытки подключения к базе данных при неудаче;
            - daemon: bool - режим потока, в котором будет запужен данный сервис. 
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__cancel = False
        self.__isActive = False
        self.__config = config
        self.__address = address
        self.__requestList = requestList
        log.debug(f'faultPoints: {faultPoints}')
        self.__faultSend = DSFaultSend(
            socketClient = SocketClient(
                address = self.__address,
                # onConnected = self.__onConnected,
                reconnectTimeout = reconnectTimeout,
                daemon = daemon,
            ),
            faultBuffer = DSFaultBuffer(
                queue = queue,
                faultPoints = faultPoints,
                config = self.__config,
            ),
        )
        super(DSStoreFault, self).__init__(
            name = 'DSStoreFault.Thread',
            daemon = daemon,
        )
        log.debug(f'config : {self.__config}')

    def run(self):
        '''Циклическая отправка данных типа DSDataPoint,
            накопившихся в очереди self.__queue,
            на API Server через self.__clientSocket'''
        log.info(f'starting in thread: {threading.current_thread().name}')
        self.__isActive = True
        if callable(self.__requestList):
            self.__requestList(set(self.__faultSend.fields))
        while not self.__cancel:
            self.__faultSend.exequte()
            time.sleep(self.__config.delay / 1000)
        self.__isActive = False
        log.info(f'exit')

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        self.__cancel = True
        self.__faultSend.cancel()
        return CancelResult(
            done = True
        )

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')



    # @staticmethod
    # def __onConnected(self, socket: socket.socket):
        # log.debug(f'Connected')
        # _jsonData = json.dumps({
        #     'api-sql': '"insert-keep-alive"',
        # })
        # _bytes = _jsonData.encode('utf-8')
        # log.debug(f'length of _bites: {len(_bytes)}')
        # sentLength = socket.send(_bytes)
        # log.debug(f'Send init sentLength: {sentLength}')
        # if sentLength == len(_bytes):
        #     event = socket.recv(4096)
        #     if event and len(event) > 0:
        #         result = event.decode('utf-8')
        #         jsonResult: dict = json.loads(result)
        #         log.debug(f'sql jsonResult: {jsonResult}')
        #         if (jsonResult['errCount'] > 0):
        #             log.error(f'sql result has errors: {jsonResult}')
        #         else:
        #             values = ''

