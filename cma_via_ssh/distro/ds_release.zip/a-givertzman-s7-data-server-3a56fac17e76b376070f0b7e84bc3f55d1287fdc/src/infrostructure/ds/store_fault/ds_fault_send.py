import time
import logging
import datetime
import threading
import src.app_logger as app_logger
from src.infrostructure.core.socket_client import SocketClient
from src.infrostructure.ds.store_fault.ds_fault_buffer import DSFaultBuffer

log = app_logger.get_logger('DSFaultSend', level = logging.DEBUG)

class DSFaultSend:
    '''Посылает списки накопившихся в буфере изменений регистрируемых тэгов в базу данных'''
    def __init__(self,
        socketClient: SocketClient,
        faultBuffer: DSFaultBuffer,
        reconnectTimeout: int = 3000,
    ) -> None:
        self.__cancel = False
        self.__isActive = False
        self.__socketClient = socketClient
        self.__faultBuffer = faultBuffer
        self.__reconnectTimeout = reconnectTimeout
        self.__values: list[tuple[datetime.datetime, str, float]] = []

    def exequte(self):
        self.__isActive = True
        sendParams = {
            'api-sql': '"insert-keep-alive"', 
            'tableName': '"fault"',
            'keys': '["timestamp", "id", "value"]', 
        }
        if (not self.__cancel):
            if (not self.__socketClient.is_alive()):
                self.__socketClient.start()
            if (self.__socketClient.connected):
                # log.debug(f'reading buffer in thread: {threading.current_thread().name}...')
                if (not self.__values):
                    self.__values = self.__faultBuffer.exequte()
                if self.__values:
                    # log.debug(f'values: {self.__values}')
                    sendParams['values'] = f'[{self.__values}]'
                    # log.debug(f'sendParams: {sendParams}')
                    self.__values = []
                # values += f'["{point.type.name.lower()}","{point.path}","{point.name}","{point.value}","{point.status.value}","{point.timestamp}"],'
            #         _jsonData = json.dumps(sendParams)
            #         # log.info(f'sending json: {_jsonData}')
            #         _bytes = _jsonData.encode('utf-8')
            #         errNo = self.__socketClient.send(_bytes)
            #         if errNo == 0:
            #             event = next(self.__socketClient.stream)
            #             if event and len(event) > 0:
            #                 result = event.decode('utf-8')
            #                 jsonResult: dict = json.loads(result)
            #                 log.debug(f'sql jsonResult: {jsonResult}')
            #                 if (jsonResult['errCount'] > 0):
            #                     log.error(f'sql result has errors: {jsonResult}')
            #                 else:
            #                     values = ''

                # time.sleep(100 / 1000)
            else:
                time.sleep(self.__reconnectTimeout / 1000)

        self.__isActive = False

    @property
    def fields(self):
        '''Список имен регистрируемых тегов'''
        return self.__faultBuffer.fields

    def cancel(self):
        self.__cancel = True
        self.__socketClient.cancel()

    def __del__(self):
        if (self.__socketClient):
            if (self.__socketClient.connected):
                self.__socketClient.cancel()
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')



    # @property
    # def sqlQuery(self):
    #     query = ''
        # for timestamp, value in self.__values:
        #     query += f'[{timestamp}, {value}],'
        # return query

