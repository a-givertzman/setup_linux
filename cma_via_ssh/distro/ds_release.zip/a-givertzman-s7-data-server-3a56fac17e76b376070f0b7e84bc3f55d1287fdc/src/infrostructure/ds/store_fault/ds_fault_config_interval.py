class DSDaultConfigInterval:
    def __init__(self,
        conf: dict,
    ) -> None:
        self.__act = []
        self.__max = 1
        rangeMin = 0
        for actKey, interval in conf.items():
            if (interval > self.__max):
                self.__max = interval
            if (actKey.lower() == 'infinity'):
                rangeMax = float('inf')
            else:
                rangeMax = int(actKey)
            self.__act.append(
                {
                    'rangeMin': float(rangeMin),
                    'rangeMax': float(rangeMax),
                    'interval': float(interval),
                }
            )
            rangeMin = rangeMax

    def interval(self, value: float, nom: float):
        valuePercent = 100 * float(value) / nom
        for actItem in self.__act:
            if actItem['rangeMin'] <= valuePercent < actItem['rangeMax']:
                return actItem['interval']

    @property
    def max(self):
        return self.__max