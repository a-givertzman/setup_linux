from typing import Any

class DSFaultParams:
    def __init__(self,
        conf: dict[str, Any],
    ) -> None:
        self.nomConst: float | None = float(conf['nom']) if ('nom' in conf and (type(conf['nom']) == float or type(conf['nom']) == int)) else None
        self.nomPoint: str | None = conf['nom'] if ('nom' in conf and type(conf['nom']) == str) else None
        self.trip: list[int | float] | None = conf['trip'] if ('trip' in conf) else None
        self.alarm: list[int | float] | None = conf['alarm'] if ('alarm' in conf) else None
        self.threshold: dict[str, float] | None = conf['threshold'] if ('threshold' in conf) else None
        self.integralFactor: float | None = conf['integralFactor'] if ('integralFactor' in conf) else None

    def __repr__(self) -> str:
        return f'S7DbPoint( nominal: {self.nomConst if self.nomConst else self.nomPoint} | trip: {self.trip} | alarm: {self.alarm} | threshold: {self.threshold} | integralFactor: {self.integralFactor})'
