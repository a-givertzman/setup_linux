import logging
import datetime
import src.app_logger as app_logger
from queue import Queue
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.core.filter.threshold import ThresholdPli
from src.infrostructure.ds.config.ds_point_config import DSPointConfig
from src.infrostructure.ds.store_fault.ds_fault_filter import DSFaultFilter
from src.infrostructure.ds.store_fault.ds_fault_filter_float import DSFaultFilterFloat
from src.infrostructure.ds.config.ds_fault_config import DSFaultConfig
from src.infrostructure.ds.store_fault.ds_fault_filter_nominal_value import DSFaultFilterNominalValue

log = app_logger.get_logger('DSFaultBuffer', level = logging.DEBUG)

class DSFaultBuffer:
    '''DataServer Store Buffer - Буфер регистратора несправностей.
        - Получает события (DSDataPoint) из потока в методе [add]
        и рассортировывает их в записи с учетом метки времени.
        - Готовые для последеющей в базу данных записи отдает в свиске list
        в свойстве [recors].
        - Длина буфера задается в параметре коструктора [length]'''

    def __init__(self,
        queue: Queue[DSDataPoint],
        config: DSFaultConfig,
        faultPoints: dict[str, DSPointConfig],
    ) -> None:
        '''length: int - длина буфера, 
            fields: list - имена полей буфера, должны быть равны именам точек данных (DSDataPoint)'''
        self.__queue = queue
        self.__config = config
        self.__faultPoints = faultPoints
        self.__buffer: dict[str, DSFaultFilter] = {}
        for key, point in faultPoints.items():
            if (point.fr):
                if (point.fr.nomConst):
                    log.debug(f'const point.fr:\n\t{point.fr}')
                    self.__buffer[key] = DSFaultFilterFloat(
                        id = point.id,  # database id
                        nominal = DSFaultFilterNominalValue(initial = point.fr.nomConst),
                        threshold = ThresholdPli(
                            conf = point.fr.threshold,
                        ) if point.fr.threshold else None,
                        integralFactor = point.fr.integralFactor if (point.fr.integralFactor) else 0.0,
                    )
                elif (point.fr.nomPoint):
                    log.debug(f'dynamic point.fr:\n\t{point.fr}')
                    nominalValue = DSFaultFilterNominalValue(initial = point.fr.nomConst if point.fr.nomConst else 0)
                    self.__buffer[point.fr.nomPoint] = nominalValue
                    self.__buffer[key] = DSFaultFilterFloat(
                        id = point.id,  # database id
                        nominal = nominalValue,
                        threshold = ThresholdPli(
                            conf = point.fr.threshold,
                        ) if point.fr.threshold else None,
                        integralFactor = point.fr.integralFactor if (point.fr.integralFactor) else 0.0,
                    )
                elif (point.fr.trip):
                    log.debug(f'discrete point.fr:\n\t{point.fr}')
                else:
                    log.debug(f'Fault Registrator dependent point:\n\t{point}')
        log.debug(f'config : {self.__config}')
        log.debug(f'buffer : {self.__buffer}')

    def exequte(self):
        '''Чтение очереди входящих событий для регистрации'''
        values: list[tuple[datetime.datetime, str, float]] = []
        if (not self.__queue.empty()):
            # log.debug(f'reading queue of size {self.__queue.qsize()}')
            while not self.__queue.empty():
                point = self.__queue.get()
                # log.debug(f'point:\n\t{point}')
                if (point.name in self.__buffer.keys()):
                    # log.debug(f'point:\n\t{point}')
                    faultFilter: DSFaultFilter = self.__buffer[point.name]
                    faultFilter.add(point)
                else:
                    log.warning(f'recieved ucnown fault point: "{point.name}"')
            self.__queue.task_done()
            for key in self.__buffer:
                faultFilter: DSFaultFilter = self.__buffer[key]
                if (not faultFilter.isUpdated):
                    faultFilter.add()
                if (faultFilter.isChanged):
                    values.append((faultFilter.timestamp, faultFilter.id, faultFilter.value))
                else:
                    faultFilter.value

            # values = values[:len(values) -1]
        return values

    @property
    def fields(self):
        '''Список имен регистрируемых тегов'''
        return self.__faultPoints.keys()

    def __del__(self):
        # if self.__isActive:
            # self.cancel()
        log.info(f'deleted')
