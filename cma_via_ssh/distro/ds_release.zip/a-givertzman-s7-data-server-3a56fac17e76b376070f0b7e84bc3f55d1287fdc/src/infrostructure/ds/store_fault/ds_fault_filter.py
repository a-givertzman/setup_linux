import datetime
from src.domain.ds.ds_data_point import DSDataPoint


class DSFaultFilter:
    '''Interface for Fault Registrator Filter classes'''
    def __init__(self) -> None:
        self.id: str
        self.value: float
        self.timestamp: datetime.datetime
        self.isChanged: bool
        '''Если True то текущее значение фильтра будет зарегистрировано'''
        self.isUpdated: bool
        '''Если True то значение фильтра было только что обновлено, сбрасывается в Falseпри чтении из [value]'''

    def add(self, point: DSDataPoint | None = None):
        pass
