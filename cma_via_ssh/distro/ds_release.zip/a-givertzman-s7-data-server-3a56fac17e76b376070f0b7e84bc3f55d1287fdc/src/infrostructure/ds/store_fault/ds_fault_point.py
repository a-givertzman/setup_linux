import logging
import datetime
import src.app_logger as app_logger

log = app_logger.get_logger('S7ParsePoint', level = logging.INFO)

class DSFaultPoint:
    '''Holds configuration of the point to be stored in to the Fault Recorder
        holds filter for this point, 
        holds offset address of data points in the raw data to fast access during parse cycle
        holds current value of the data point, 
        holds configured filter, 
    '''
    def __init__(self,
        type: DSDataType,
        path: str,
        name: str,
        history: int,
        alarm: int,
        offset: int,
        bit: int = 0x00,
        filter: Filter | None = None,
    ):
        self.type = type
        self.name = name
        self.path = path
        self.history = history
        self.alarm = alarm
        self.start = offset
        self.end = offset + self.type.value.length
        self.bit = bit
        self.isFiltered = filter != None
        self.filter = filter
        self.changed = False
        self.__value = self.__initValue(type)
        self.__status: DSStatus = DSStatus.ok
        self.__time: datetime.datetime = datetime.datetime.now()
        self.__convert = self.__converters(type)

