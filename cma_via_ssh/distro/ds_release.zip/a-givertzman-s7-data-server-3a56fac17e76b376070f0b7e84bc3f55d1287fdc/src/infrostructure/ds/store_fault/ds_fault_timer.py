import logging
import threading
import src.app_logger as app_logger
from typing import Callable

log = app_logger.get_logger('DSFaultTimer', level = logging.DEBUG)


class DSFaultTimer(threading.Thread):
    def __init__(self, 
        interval: float,
        onTimer: Callable[[], None],
        daemon: bool = False,
    ):
        '''interval: float - интервал срабатывания в секундах;'''
        self.interval = interval
        self.__onTimer = onTimer
        super(DSFaultTimer, self).__init__(
            name = 'DSFaultTimer.Thread',
            daemon = daemon,
        )
        self.stopped = threading.Event()

    def run(self):
        while not self.stopped.wait(self.interval):
            log.debug("executing...")
            self.__onTimer()

    def cancel(self):
        self.stopped.set()