import logging
import src.app_logger as app_logger
from queue import Queue
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.ds.ds_data_point_path import DSDataPointPath
from src.infrostructure.ds.config.ds_line_config import DSLineConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.s7.s7_write_data import WriteResult
from src.infrostructure.s7.s7_client import S7Client
from src.infrostructure.s7.s7_ied import S7Ied

log = app_logger.get_logger('DSLine', level = logging.INFO)

class DSLine:
    '''Берет уровень line из S7Config конфигурации
    и запускает каждый вложенный IED как отдельный поток.'''
    def __init__(self, 
        path: str,
        name: str,
        config: DSLineConfig
    ):
        self.__path = path
        self.__name = name
        self.__config = config
        self.__ieds: dict[str, S7Ied] = {}
        self.__queues: list[Queue[DSDataPoint]] = []

    def start(self):
        log.info(f'Communication line starting...')
        for iedKey, iedConf in self.__config.ieds.items():
            log.debug(f'IED Config: {iedConf}')
            s7Ied = S7Ied(
                path = self.__path + '/' + self.__name,
                name = iedKey,
                config = iedConf,
                s7ClientRead = S7Client(
                    iedConfig = iedConf,
                    reconnectDelay = 3000,
                    name = f'{iedKey}.read'
                ),
                s7ClientWrite = S7Client(
                    iedConfig = iedConf,
                    reconnectDelay = 3000,
                    name = f'{iedKey}.write'
                ),
                daemon = False,
            )
            self.__ieds[iedKey] = s7Ied
            self.__queues.append(s7Ied.queue)
            s7Ied.start()
        log.info(f'Communication line started')
        return self.__queues

    def requestAll(self):
        '''Команда прислать все тэги'''
        log.debug(f'{self.__path}/{self.__name} all tags requested')
        for iedKey in self.__ieds:
            ied = self.__ieds[iedKey]
            ied.requestAll()

    def requestList(self, pointNames: set[str]):
        '''Команда прислать список тэгов'''
        log.debug(f'{self.__path}/{self.__name} list of tags requested: {pointNames}')
        for iedKey in self.__ieds:
            ied = self.__ieds[iedKey]
            ied.requestList(pointNames)


    def writeInt(self,
        path: str,
        name: str, 
        value: int,
    ):

        try:
            ied = DSDataPointPath(path).ied()
            return self.__ieds[ied].writeInt(
                path = path,
                name = name, 
                value = value,
            )
        except (AssertionError, Exception) as err:
            return WriteResult(
                error = Exception(f'Wrong IED name in path: {path},\nerror: {err}')
            )

    def writeReal(self,
        path: str,
        name: str, 
        value: int,
    ):
        ied = DSDataPointPath(path).ied()
        return self.__ieds[ied].writeReal(
            path = path,
            name = name, 
            value = value,
        )

    def cancel(self):
        cancelDone = True
        for iedKey in self.__ieds:
            ied = self.__ieds[iedKey]
            result = ied.cancel()
            cancelDone = cancelDone and result.done
            # log.info(f'result: {result}')
        return CancelResult(
            done = cancelDone,
        )

    def __del__(self):
        log.info(f'{self.__path}/{self.__name} deleted')
