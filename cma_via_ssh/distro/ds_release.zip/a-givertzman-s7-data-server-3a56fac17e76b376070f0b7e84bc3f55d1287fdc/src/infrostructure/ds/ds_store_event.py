import json
import socket
import datetime
import logging
import threading
import src.app_logger as app_logger
from time import sleep
from queue import Queue
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint
from src.infrostructure.core.socket_client import SocketClient
from src.infrostructure.ds.config.ds_point_config import DSPointConfig

log = app_logger.get_logger('DSStoreEvent', level = logging.INFO)

class DSStoreEvent(threading.Thread):
    '''DataServer Store Event - Регистратор исторических событий.
        Получает события (DSDataPoint) из потока в очередь [self.__queue].
        Циклически отправляет накопившиеся события в базу данных (MySql)
        и очищает очередь'''
    IPV4 = socket.AF_INET
    TCP = socket.SOCK_STREAM

    def __init__(self,
        queue: Queue[DSDataPoint],
        historyPoints: dict[str, DSPointConfig],
        address = ('127.0.0.1', 8080),
        reconnectTimeout: int = 3000,
        daemon: bool = False,
    ) -> None:
        '''- queue: Queue[DSDataPoint] - очередь для аккумулирования входящих событий;
            - historyPoints: dict[str, DSPointConfig], - конфигурации сигналов;
            - address: tuple[str, int] - адрес (ip, port) API сервера для хранения исторических данных;
            - reconnectTimeout: int - таймаут в миллисекунах попытки подключения к базе данных при неудаче;
            - daemon: bool - режим работы потока в котором будет запущен данный сервис;
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__cancel = False
        self.__isActive = False
        self.__address = address
        self.__reconnectTimeout = reconnectTimeout
        self.__queue = queue
        self.__historyPoints = historyPoints
        self.__socketClient: SocketClient | None = None
        super(DSStoreEvent, self).__init__(
            name = 'DSStoreEvent.Thread',
            daemon = daemon,
        )

    def run(self):
        '''Циклическая отправка данных типа DSDataPoint,
            накопившихся в очереди self.__queue,
            на API Server через self.__clientSocket'''
        log.info(f'starting in thread: {threading.current_thread().name}')
        self.__isActive = True
        self.__socketClient = SocketClient(
            address = self.__address,
            onConnected = self.__onConnected,
            reconnectTimeout = self.__reconnectTimeout,
            daemon = self.daemon,
        )
        self.__socketClient.start()
        log.info(f'started in thread: {threading.current_thread().name}')
        self.__sendData()
        self.__isActive = False
        log.info(f'exit')

    # @staticmethod
    def __onConnected(self, socket: socket.socket):
        _jsonData = json.dumps({
            'api-sql': '"keep-alive"', 
            'tableName': '"tags"',
            'keys': '["count(*)"]', 
        })
        _bytes = _jsonData.encode('utf-8')
        if (self.__socketClient):
            self.__socketClient.send(_bytes)
            event = next(self.__socketClient.stream)
            if event and len(event) > 0:
                result = event.decode('utf-8')
                jsonResult: dict = json.loads(result)
                log.debug(f'sql jsonResult: {jsonResult}')
                if (jsonResult['errCount'] > 0):
                    log.error(f'sql result has errors: {jsonResult}')

    def __sendData(self):
        log.info(f'started in thread: {threading.current_thread().name}')
        sendParams = {
            'api-sql': '"insert"', 
            'tableName': '"event"',
            'keys': '["pid", "value", "status", "timestamp"]', 
        }
        values = ''
        while not self.__cancel:
            if (self.__socketClient and self.__socketClient.connected):
                log.debug(f'server connected, cheking queue...')
                if (values == ''):
                    values = self.__readQueue()
                if values:
                    log.debug(f'values: {values}')
                    sendParams['values'] = f'[{values}]'
                    _jsonData = json.dumps(sendParams)
                    # log.info(f'sending json: {_jsonData}')
                    _bytes = _jsonData.encode('utf-8')
                    errNo = self.__socketClient.send(_bytes)
                    if errNo == 0:
                        event = next(self.__socketClient.stream)
                        if event and len(event) > 0:
                            result = event.decode('utf-8')
                            jsonResult: dict = json.loads(result)
                            log.debug(f'sql jsonResult: {jsonResult}')
                            if (jsonResult['errCount'] > 0):
                                log.error(f'sql result has errors: {jsonResult}')
                            else:
                                values = ''

                sleep(100 / 1000)
            else:
                sleep(self.__reconnectTimeout / 1000)

    def __readQueue(self):
        values = ''
        if (not self.__queue.empty()):
            log.debug(f'reading queue of size {self.__queue.qsize()}')
            while not self.__queue.empty():
                point = self.__queue.get()
                pointConf = self.__historyPoints.get(point.name)
                if (pointConf):
                    pointId = pointConf.id
                    pointValue = 1 if point.value > 0 else 0
                    values += f'["{pointId}","{pointValue}","{point.status.value}","{point.timestamp}"],'
                else:
                    log.warning(f'Can`t find cinfiguration DSPointConfig for point: {point}')
            self.__queue.task_done()
            values = values[:len(values) -1]
        return values

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        self.__cancel = True
        if (self.__socketClient):
            self.__socketClient.cancel()
        return CancelResult(
            done = True
        )

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')
