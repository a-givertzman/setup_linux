import time
import logging
import threading
import src.app_logger as app_logger
from queue import Queue
from src.domain.core.result import CancelResult
from src.domain.core.merge_queues import MergeQueues
from src.domain.ds.ds_data_type import DSDataType
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.ds.ds_data_point_path import DSDataPointPath
from src.infrostructure.ds.ds_line import DSLine
from src.infrostructure.ds.config.ds_config import DSDataSourceConfig

log = app_logger.get_logger('DSDataSource', level = logging.INFO)


class DSDataSource(threading.Thread):
    '''Рассылает подписчикам события [DSDataPoint], 
    приходящие из входного потока [stream] (Generator).
    - Подписаться можно на все события методом queue(), без параметров,
    - или на конкретные события, если передать в метод queue(pointNames: list[str])
    список имен необходимых тегов.'''
    def __init__(self,
        config: DSDataSourceConfig,
        daemon: bool = False,
    ) -> None:
        '''- mergeQueues: MergeQueues - очереди входящих событий типа [DSDataPoint];
            - dsConfig: DSConfig - конфигурация сервера данных;
            - daemon: bool - режим потока, в котором будет запужен данный сервис;
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__cancel = False
        self.__isActive = False
        self.__config = config
        self.__lines: dict[str, DSLine] = {}
        self.__queues: list[Queue[DSDataPoint]] = []
        self.__mergeQueues = MergeQueues[DSDataPoint](
            queues = self.__queues,
        )
        self.__stream = self.__mergeQueues.stream
        self.__subscribers: dict[str, list[Queue[DSDataPoint]]] = self.__setupSubscribers(config)
        super(DSDataSource, self).__init__(
            name = f'DSDataSource.Thread',
            daemon = daemon
        )

    def __setupSubscribers(self, config: DSDataSourceConfig):
        subscribers: dict[str, list[Queue[DSDataPoint]]] = {}
        for lineKey, lineConf in config.lines.items():
            for iedKey, iedConf in lineConf.ieds.items():
                for pointKey, pointConf in iedConf.points().items():
                    subscribers[pointKey] = []
                    log.debug(f'point: {pointKey}: {pointConf}')
        return subscribers

    def __setupLines(self, config: DSDataSourceConfig):
        '''Создает и запускает в работу объекты [S7Line]'''
        for lineKey, lineConf in config.lines.items():
            log.info(f'configuring line: {lineKey}...')
            self.__lines[lineKey] = DSLine(
                path = config.path,
                name = lineKey,
                config = lineConf
            )
            lineQueue = self.__lines[lineKey].start()
            self.__queues.extend(lineQueue)
            time.sleep(100 / 1000)
        # for lineKey in self.__lines:
        #     line = self.__lines[lineKey]
        #     log.info(f'starting line: {lineKey}...')
        #     lineQueue = line.start()
        #     self.__queues.extend(lineQueue)
        #     time.sleep(100 / 1000)


    def queue(self, pointNames: list[str] | None = None):
        '''Возвращает очередь Queue[DSDataPoint].
        Если [pointNames] != None то в очередь попадут только
        события с именами указанными в [pointNames].'''
        queue = Queue[DSDataPoint]()
        if (pointNames != None):
            for subscriberKey in pointNames:
                if subscriberKey in self.__subscribers.keys():
                    self.__subscribers[subscriberKey].append(queue)
                else:
                    log.error('Unknown data point name: {subscriberKey}')
                    raise Exception('Unknown data point name: {subscriberKey}')
        else:
            for subscriberKey in self.__subscribers:
                self.__subscribers[subscriberKey].append(queue)
        return queue

    def run(self):
        self.__isActive = True
        '''Запуск опроса подчиненных устройств'''
        self.__setupLines(self.__config)
        for event in self.__stream:
            subscribers = self.__subscribers[event.name]
            for subscriber in subscribers:
                subscriber.put(event)
            del subscribers
            if self.__cancel:
                break
        self.__isActive = False
        log.info(f'exit')

    @property
    def lines(self):
        return self.__lines

    @property
    def isActive(self):
        return self.__isActive

    def onRequestAll(self):
        log.info(f'all tags requested')
        for line in self.__lines.values():
            line.requestAll()

    def onRequestList(self, pointNames: set[str]):
            log.debug(f'list of tags requested: {pointNames}')
            for lineKey in self.__lines:
                line = self.__lines[lineKey]
                line.requestList(pointNames)

    def onCommonCmd(self, event: DSDataPoint):
        try:
            lineName = DSDataPointPath(event.path).line()
            line = self.__lines[lineName]
            if (event.type == DSDataType.Int):
                log.info(f'sending IntCmd:\n\t{event}')
                line.writeInt(
                    path = event.path,
                    name = event.name,
                    value = event.value
                )
            if (event.type == DSDataType.Real):
                log.info(f'sending RealCmd: {event}')
                line.writeReal(
                    path = event.path,
                    name = event.name,
                    value = event.value
                )
        except (AssertionError, Exception) as err:
            log.warning(f'Wrong Line name in event: {event},\nerror: {err}')

    def cancel(self):
        self.__cancel = True
        for lineKey, line in self.__lines.items():
            result = line.cancel()
            log.debug(f'Cancel line {lineKey} result: {result}')
        self.__mergeQueues.cancel()
        return CancelResult(
            done = True,
        )

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')











    # def __logPoint(self, 
    #     name: str, 
    #     event: DSDataPoint, 
    #     writeBack: bool = False,
    #     path: str = None,
    # ):
    #     if (name in event.name):
    #         tNow = datetime.datetime.now()
    #         dt = 0
    #         try:
    #             dt = (tNow - self.__t[name]).microseconds / 1000
    #         except:
    #             pass
    #         self.__t[name] = tNow
    #         print(event)
    #         # print(dt, event.timestamp, event.name, event.value)
    #         # if (event.value != 5) and (self.__v[name] != event.value -1):
    #         #     print('\n', event.timestamp, 'value skiped', self.__v[name], event.value)
    #         # self.__v[name] = event.value
    #         if (dt > 65):
    #             print(dt)
    #             # print(dt, end = ' ')
    #         if (writeBack):
    #             line = DSDataPointPath(path).line()
    #             # self.__lines[line].writeInt(
    #             #     path = path,
    #             #     name = 'HPU.Pump2',
    #             #     value = event.value,
    #             # ),
    #             # self.__lines[line].writeFloat(
    #             #     path = path,
    #             #     name = 'HPU.Pump2',
    #             #     value = event.value,
    #             # ),
    #             # self.__lines[line].writeFloat(
    #             #     path = path,
    #             #     name = 'AnalogSensors.Winch.LVDT2',
    #             #     value = event.value,
    #             # ),
    #             # self.__lines[line].writeFloat(
    #             #     path = path,
    #             #     name = 'AnalogSensors.Winch.PressureLineA_1',
    #             #     value = event.value,
    #             # ),
    #             # self.__lines[line].writeFloat(
    #             #     path = path,
    #             #     name = 'AnalogSensors.Winch.PressureLineA_2',
    #             #     value = event.value,
    #             # ),

