import logging
import threading
import src.app_logger as app_logger
from time import sleep
from typing import Callable, Generator
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint
from src.domain.ds.ds_data_class import DSDataClass
from src.domain.core.locked_iterator import LockedIterator

log = app_logger.get_logger('DSHandleClientCmd', level = logging.INFO)

class DSHandleClientCmd(threading.Thread):
    '''Получает комманды пользователя от [SocketServer] 
        в потоке [Generator[bytes]], парсит их из bytes в [DSDataPoint],
        в зависимости от класса [DSDataClass] вызывает соответствующий метод.'''
    def __init__(self,
        stream: LockedIterator | Generator[bytes, None, None],
        onRequestAll: Callable | None,
        onRequestPath: Callable[[DSDataPoint], None] | None,
        onRequestList: Callable[[set[str]], None] | None,
        onRequestAlarms: Callable[[DSDataPoint], None] | None,
        onRequestTime: Callable[[DSDataPoint], None] | None,
        onSyncTime: Callable[[DSDataPoint], None] | None,
        onCommonCmd: Callable[[DSDataPoint], None] | None,
        daemon: bool = False,
    ) -> None:
        '''- stream: Generator[DSDataPoint, None, None] - поток входящих команд типа [DSDataPoint];
            - daemon: bool - режим работы потока в котором будет запущен данный сервис;
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__cancel = False
        self.__isActive = False
        self.__stream = stream
        self.__onRequestAll = onRequestAll
        self.__onRequestPath = onRequestPath
        self.__onRequestList = onRequestList
        self.__onRequestAlarms = onRequestAlarms
        self.__onRequestTime = onRequestTime
        self.__onSyncTime = onSyncTime
        self.__onCommonCmd = onCommonCmd
        super(DSHandleClientCmd, self).__init__(
            name = 'DSHandleClientCmd.Thread',
            daemon = daemon
        )

    def run(self):
        log.info(f'started in thread: {threading.current_thread().name}')
        self.__isActive = True
        while not self.__cancel:
            log.info(f'parsing stream in thread: {threading.current_thread().name}: {self.__stream}')
            for event in self.__stream:
                log.debug(f'event: {event}')
                self.__parseEvent(event)
                if self.__cancel:
                    break
            sleep(10 / 1000)
        self.__isActive = False
        log.info(f'exit')

    def __parseEvent(self, event: bytes):
        log.debug(f'event: {event}')
        point = DSDataPoint.fromBytes(event)
        log.info(f'received point: {point}')
        if point:
            if (point.dsClass == DSDataClass.requestAll):
                # log.info(f'received requestAll command')
                if callable(self.__onRequestAll):
                    self.__onRequestAll()
            elif (point.dsClass == DSDataClass.requestPath):
                if callable(self.__onRequestPath):
                    self.__onRequestPath(point)
            elif (point.dsClass == DSDataClass.requestList):
                if callable(self.__onRequestList):
                    self.__onRequestList(point.value)
            elif (point.dsClass == DSDataClass.requestAlarms):
                if callable(self.__onRequestAlarms):
                    self.__onRequestAlarms(point)
            elif (point.dsClass == DSDataClass.requestTime):
                if callable(self.__onRequestTime):
                    self.__onRequestTime(point)
            elif (point.dsClass == DSDataClass.syncTime):
                if callable(self.__onSyncTime):
                    self.__onSyncTime(point)
            elif (point.dsClass == DSDataClass.commonCmd):
                if callable(self.__onCommonCmd):
                    self.__onCommonCmd(point)
            else:
                raise Exception(f'Uncnown data class: {point.dsClass}')

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self) -> CancelResult:
        self.__cancel = True
        # self.__stream.send(None)
        # self.__stream.close()
        return CancelResult(done = True)

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')
