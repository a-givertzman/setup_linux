import logging
import threading
import src.app_logger as app_logger
from time import sleep
from queue import Queue
from typing import Callable, Generator
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint

log = app_logger.get_logger('DSSendEvent', level = logging.INFO)

class DSSendEvent(threading.Thread):
    '''Получает события [DSDataPoint] в очереди,
        в независимом потоке читает события из очереди в буфер [list],
        отправляет события из буфера вызовом метода [onData(bytes)]'''
    def __init__(self,
        onEvent: Callable[[bytes], int],
        queue: Queue[DSDataPoint],
        daemon: bool = False,
    ) -> None:
        '''- onEvent: Callable[[bytes], int] - метод, который будет вызван при наличии данных для отправки клиентам;
            - queue: Queue[DSDataPoint] - очередь для аккумулирования входящих событий;
            - daemon: bool - режим работы потока в котором будет запущен данный сервис;
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__cancel = False
        self.__isActive = False
        self.__onEvent = onEvent
        self.__queue = queue
        self.__queueLimit = 100
        self.__sendBuffer: list[DSDataPoint] =  []
        super(DSSendEvent, self).__init__(
            name = 'DSSendEvent.Thread',
            daemon = daemon,
        )

    def run(self):
        '''Циклическая отправка данных типа DSDataPoint,
            накопившихся в очереди self.__queue,
            клиентам через self.__socketServer'''
        log.info(f'started in thread {threading.current_thread().name}')
        self.__isActive = True
        while not self.__cancel:
            if ((len(self.__sendBuffer) == 0) and (not self.__queue.empty())):
                # log.info(f'reading queue {self.__queue}')
                self.__readQueue()
            if (len(self.__sendBuffer) > 0):
                _bytes = self.__encodeSendBuffer()
                result = -1
                while result != 0:
                    if self.__cancel:
                        break
                    result = self.__onEvent(_bytes)
                    if result != 0:
                        sleep(100/1000)
                    else:
                        self.__sendBuffer.clear()
            if (len(self.__sendBuffer) > 0):
                self.__validateQueueSize(self.__queue.qsize())
            sleep(10/1000)
        self.__isActive = False
        log.info(f'exit')

    def __readQueue(self):
        '''Потокобезопасное чтение данных из очереди в локальный буфер для отправки клинтам.'''
        log.debug(f'reading queue size of {self.__queue.qsize()}\n\t to the buffer size of: {len(self.__sendBuffer)}')
        while not self.__queue.empty():
            self.__sendBuffer.append(
                self.__queue.get()
            )
        self.__queue.task_done()

    def __encodeSendBuffer(self):
        log.debug(f'encoding sendBuffer size of {len(self.__sendBuffer)}')
        _jsonData = ''
        for point in self.__sendBuffer:
            _jsonData += point.toJson()
            _jsonData += '|||'
        # log.info(f'sending json: {_jsonData}')
        _bytes = _jsonData.encode('utf-8')
        return _bytes

    def __validateQueueSize(self, size: int):
        if size >= self.__queueLimit:
            self.__queueLimit *= 10
            if (size > 100000):
                log.warning(f'approximate queue.qsize: {size}')
            else:
                log.info(f'approximate queue.qsize: {size}')

    @property
    def isActive(self):
        return self.__isActive

    def cancel(self):
        self.__cancel = True
        return CancelResult(done = True)

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info(f'deleted')
