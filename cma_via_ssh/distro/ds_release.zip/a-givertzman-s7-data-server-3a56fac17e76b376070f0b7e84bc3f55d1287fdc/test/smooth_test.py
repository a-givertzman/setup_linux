import os
import sys
import inspect
import unittest
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.domain.core.filter.smooth as smooth
import src.app_logger as app_logger

log = app_logger.get_logger('SmoothTest')

class SmoothTest(unittest.TestCase):

    def test_Smooth_create(self):
        thisMathodName = sys._getframe(  ).f_code.co_name
        with self.assertRaises(Exception):
            s = smooth.Smooth(
                initialValue = 0,
                factor = 0.9999999,
            )

        with self.assertRaises(Exception):
            s = smooth.Smooth(
                initialValue = 0,
                factor = 129,
            )
        
        try:
            s = smooth.Smooth(
                initialValue = 0,
                factor = 1,
            )
            self.assertIsInstance(s, smooth.Smooth)
        except Exception as err:
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Smooth_add(self):
        s = smooth.Smooth(
            initialValue = 0,
            factor = 1,
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                # log.info(f'{i}\t:{input[i]}')
                s.add(input[i])
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Smooth_out(self):
        s = smooth.Smooth(
            initialValue = 0,
            factor = 1,
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                s.add(input[i])
                out = s.out()
                # log.info(f'{i}\tin: {input[i]}\tout: {out}')
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Smooth_factor1(self):
        s = smooth.Smooth(
            initialValue = 0,
            factor = 1,
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                s.add(input[i])
                out = s.out()
                self.assertEqual(input[i], out)
                # log.info(f'{i}\tin: {input[i]}\tout: {out}')
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Smooth_factorAny(self):
        s = smooth.Smooth(
            initialValue = -1,
            factor = 1.5,
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 1, 1, 2, -3, -3, -3, -3, -3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                s.add(input[i])
                out = s.out()
                self.assertNotEqual(input[i], out)
                log.info(f'{i}\tin: {input[i]}\tout: {out}')
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')


if __name__ == '__main__':
    unittest.main()