import datetime
import inspect
import os
import sys
import threading
from time import sleep
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.infrostructure.s7.s7_client as s7_client
import src.app_logger as app_logger
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.domain.core.stream.stream_controller import StreamController

log = app_logger.get_logger('S7ClientTest2')

class TaskThread(threading.Thread):
    def __init__(self,
        name: str
    ) -> None:
        self.__name = name
        self.__streamController = StreamController()
        self._stream = self.__streamController.stream
        super().__init__(
            name = name, 
            daemon = False
        )

    @property
    def stream(self):
        return self.__streamController.stream

    def run(self):
        log.info(f'[{self.__name}] client connecting...')
        client = s7_client.S7Client(
            # reconnectDelay = 0,
            iedConfig = S7IedConfig(
                path = '/test/',
                name = 'test.ied',
                description = 'test.ied',
                ip = '192.168.120.241',
                # ip = '192.168.120.141',
                rack = 0,
                slot = 1,
                db = {},
            )
        )
        client.connectInThread()
        if (client.connected):
            log.info(f'[{self.__name}] client connected...\n\t{connectionResult}')
            for value in range(1000):
                readResult = client.connection.db_read(902, 0, 32)
                readResult = client.connection.db_read(903, 0, 164)
                readResult = client.connection.db_read(904, 0, 18)
                readResult = client.connection.db_read(905, 0, 128)
                readResult = client.connection.db_read(906, 0, 108)
                self.__streamController.add(f'[{self.__name}] readResult[{value}]...\n\t{readResult}')
        return client

    def __onConnectDone(result: s7_client.ConnectResult):
        if (result.hasData):
            finished1 = True

    def __onDisconnectDone(self, result):
        log.info(f'[{self.__name}] ')
        log.info(f'[{self.__name}] disconnected successful')



    def onConnection(self, result: s7_client.ConnectResult):
        if (result.hasData): 
            log.info(f'[{self.__name}] disconnecting...\n\t{result.connection}')
            result.connection.disconnect()
        else:
            log.info(f'[{self.__name}] disconnecting...\n\t{result.error}')
        self.__onDisconnectDone(result)

def __onData(event):
    log.info(event)

if __name__ == '__main__':

    t1 = datetime.datetime.now()

    tasks:list[TaskThread] = []
    for value in range(10):
        t3 = datetime.datetime.now()
        task = TaskThread(
            name = f'Task {value}',
        )
        tasks.append(task)
        task.stream.listen(
            onData=__onData
        )
        task.start()

    for task in tasks:
        task.join()


    t2 = datetime.datetime.now()
    log.info(f'[] dt: {t1}')
    log.info(f'[] dt: {t2}')
    dtf = t2 - t1
    log.info(f'[] dt: {dtf}')
