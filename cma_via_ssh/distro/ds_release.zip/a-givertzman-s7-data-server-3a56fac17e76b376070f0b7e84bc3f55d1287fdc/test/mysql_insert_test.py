import os
import sys
import json
import inspect
import unittest
import mysql.connector as MySql
import src.app_logger as app_logger
from src.domain.core.cache.cached import Cached
from src.infrostructure.mysql.mysql_config import MySqlConfig
from src.infrostructure.mysql.mysql_result import MySqlResult
from src.infrostructure.mysql.mysql_select import MySqlSelect
from src.infrostructure.mysql.mysql_insert import MySqlInsert
from src.infrostructure.mysql.mysql_request import MySqlRequest
from src.infrostructure.mysql.mysql_connect import MySqlConnect
from src.infrostructure.mysql.mysql_convert import MySqlConvertToString

log = app_logger.get_logger('MySqlInsertTest')

class MySqlInsertTest(unittest.IsolatedAsyncioTestCase):
    def test_insert(self):
        with self.assertRaises(Exception):
            mySqlConnect = MySqlSelect()  # type: ignore
        self.select = MySqlSelect(
            connection = Cached[MySqlConnect](
                MySqlConnect(
                    config = MySqlConfig(
                        host = '127.0.0.1',
                        database = 'crane_data_server',
                        user = 'crane_data_server',
                        password = '00d0-25e4-*&s2-ccds',
                        converter_class = MySqlConvertToString,
                        raise_on_warnings = False,
                    )
                )
            )  # type: ignore
        )
        self.insert = MySqlInsert(
            connection = Cached[MySqlConnect](
                MySqlConnect(
                    config = MySqlConfig(
                        host = '127.0.0.1',
                        database = 'crane_data_server',
                        user = 'crane_data_server',
                        password = '00d0-25e4-*&s2-ccds',
                        converter_class = MySqlConvertToString,
                        raise_on_warnings = True,
                    )
                )
            )  # type: ignore
        )
        dropTableSql = """
DROP TABLE IF EXISTS `app_user_test`;
        """
        createSql = """
CREATE TABLE `app_user_test` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `group` enum('admin','operator') CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT 'operator' COMMENT 'Признак группировки',
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT 'ФИО Потльзователя',
  `login` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL COMMENT ' Логин',
  `pass` varchar(2584) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '' COMMENT 'Пароль',
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`,`login`),
  UNIQUE KEY `login_UNIQUE` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='Потльзователи';
        """
        insertSql = """
INSERT INTO app_user_test (`group`,name,login,pass,created,updated,deleted) VALUES
	 ('operator','anton lobanov','anton.lobanov1','3201,3202,3203','2022-04-26 15:46:54','2022-04-28 16:20:47',NULL),
	 ('admin','anton lobanov','anton.lobanov2','3201,3202,3203','2022-04-26 15:48:03','2022-05-24 18:07:21',NULL),
	 ('operator','anton lobanov','anton.lobanov3','3201,3202,3203','2022-04-26 15:48:32','2022-04-28 16:20:47',NULL),
	 ('operator','anton lobanov','anton.lobanov4','3201,3202,3203','2022-04-26 15:52:28','2022-04-28 16:20:47',NULL),
	 ('operator','anton lobanov','anton.lobanov5','3201,3202,3203','2022-04-26 15:46:22','2022-04-28 16:20:47',NULL),
	 ('operator','anton lobanov','anton.lobanov6','3201,3202,3203','2022-04-26 15:46:22','2022-04-28 16:25:32',NULL);
        """
        result = self.select.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': '"sql"', 'sql': json.dumps(dropTableSql)
                }).encode('utf-8')
            )
        )
        result = self.select.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': '"sql"', 'sql': json.dumps(createSql)
                }).encode('utf-8')
            )
        )
        # result = self.select.execute({
        #     'sql': json.dumps(insertSql)
        # })
        result = self.insert.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': json.dumps('insert'), 
                    'tableName': json.dumps('app_user_test'), 
                    'keys': json.dumps(["group", "name","login","pass"]), 
                    'values': json.dumps([["admin","anton lobanov","anton.lobanov","3201,3202,3203"]]), 
                }).encode('utf-8')
            )
        )
        self.assertIsInstance(result, MySqlResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, {})
        result = self.insert.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': json.dumps('insert'), 
                    'tableName': json.dumps('app_user_test'), 
                    'keys': json.dumps(["group", "name","login","pass","created"]), 
                    'values': json.dumps([["admin","anton lobanov","anton.lobanov0","3201,3202,3203","2022-04-26 15:48:03"]]), 
                }).encode('utf-8')
            )
        )
        self.assertIsInstance(result, MySqlResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, {})
        result = self.insert.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': json.dumps('insert'), 
                    'tableName': json.dumps('app_user_test'), 
                    'keys': json.dumps(["group", "name","login","pass","created"]), 
                    'values': json.dumps([["admin","anton lobanov","anton.lobanov1","3201,3202,3203","2022-04-26 15:48:03"],["admin","anton lobanov","anton.lobanov2","3201,3202,3203","2022-04-26 15:48:03"],["admin","anton lobanov","anton.lobanov3","3201,3202,3203","2022-04-26 15:48:03"]]), 
                }).encode('utf-8')
            )
        )
        self.assertIsInstance(result, MySqlResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, {})
        result = self.select.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': json.dumps('sql'), 
                    'sql': json.dumps('select * from app_user_test'), 
                }).encode('utf-8')
            )
        )
        self.assertIsInstance(result, MySqlResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, {})


        for i in range(0, 500):
            result = self.insert.execute(
                MySqlRequest(
                    raw = json.dumps({
                        'api-sql': json.dumps('insert'), 
                        'tableName': json.dumps('app_user_test'), 
                        'keys': json.dumps(["group", "name","login","pass","created"]), 
                        'values': json.dumps([["admin","anton lobanov",f'anton.lobanov_{i}',"3201,3202,3203","2022-04-26 15:48:03"]]), 
                    }).encode('utf-8')
                )
            )
            # log.info(f'result: {result}')
            self.assertIsInstance(result, MySqlResult)
            self.assertEqual(result.hasData, True)
            self.assertEqual(result.hasError, False)
            self.assertEqual(result.errors, {})
            # self.assertIsInstance(result.connection, MySql.MySQLConnection)
        result = self.select.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': '"sql"', 'sql': json.dumps('select count(*) from `app_user_test`')
                }).encode('utf-8')
            )
        )
        self.assertIsInstance(result, MySqlResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, {})
        self.assertEqual(result.data[0], {'count(*)': '505'})
        result = self.select.execute(
            MySqlRequest(
                raw = json.dumps({
                    'api-sql': '"sql"', 'sql': json.dumps(dropTableSql)
                }).encode('utf-8')
            )
        )
        self.assertIsInstance(result, MySqlResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, {})

if __name__ == '__main__':
    unittest.main()

