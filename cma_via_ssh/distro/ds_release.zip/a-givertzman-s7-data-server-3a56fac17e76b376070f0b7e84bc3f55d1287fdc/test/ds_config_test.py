import os
import sys
import json
import inspect
import unittest
import src.app_logger as app_logger
from src.infrostructure.ds.config.ds_config import DSConfig
from src.infrostructure.ds.config.ds_data_source_config import DSDataSourceConfig
from src.infrostructure.ds.config.ds_send_event_config import DSSendEventConfig
from src.infrostructure.ds.config.ds_store_event_config import DSStoreEventConfig
from src.infrostructure.ds.config.ds_handle_cmd_config import DSHandleCmdConfig
from src.infrostructure.ds.config.ds_fault_config import DSFaultConfig

log = app_logger.get_logger('DSConfigTest')

configFileName = 'conf.json'

class DSConfiigTest0(unittest.IsolatedAsyncioTestCase):
    async def test_DSConfig_create(self):
        with self.assertRaises(Exception):
            dsConfig = DSConfig()  # type: ignore
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        self.assertIsInstance(dsConfig, DSConfig)

    async def test_DSConfig_dataSource(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.dataSource
        self.assertIsInstance(config, DSDataSourceConfig)
        log.info(f'config: {config}')

    async def test_DSConfig_sendEvent(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.sendEvent
        self.assertIsInstance(config, DSSendEventConfig)
        log.info(f'config: {config}')

    async def test_DSConfig_storeEvent(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.storeEvent
        self.assertIsInstance(config, DSStoreEventConfig)
        log.info(f'config: {config}')

    async def test_DSConfig_handleCmd(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.handleCmd
        self.assertIsInstance(config, DSHandleCmdConfig)
        log.info(f'config: {config}')

    async def test_DSConfig_storeFault(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.storeFault
        self.assertIsInstance(config, DSFaultConfig)
        log.info(f'config: {config}')

    async def test_DSConfig_allPoints(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.allPoints()
        # self.assertIsInstance(config, )
        log.info(f'config: {config}')

    async def test_DSConfig_historyPoints(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.historyPoints()
        # self.assertIsInstance(config, )
        log.info(f'config: {config}')

    async def test_DSConfig_faultPoints(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.faultPoints()
        # self.assertIsInstance(config, )
        log.info(f'config: {config}')

    async def test_DSConfig_faultPointKeys(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.faultPointKeys()
        # self.assertIsInstance(config, )
        log.info(f'config: {config}')

    async def test_DSConfig_alarmPoints(self):
        dsConfig = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        config = dsConfig.alarmPoints()
        # self.assertIsInstance(config, )
        log.info(f'config: {config}')

if __name__ == '__main__':
    unittest.main()
