import inspect
import os
import sys
import unittest
import src.app_logger as app_logger
from src.infrostructure.s7.s7_ied_config import S7IedConfig

log = app_logger.get_logger('S7IedConfigTest')

class S7IedConfigTest(unittest.TestCase):

    def test_S7Client_create(self):
        thisMathodName = sys._getframe(  ).f_code.co_name
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                    'ip': '192.168.120.300', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                    'ip': '192.168.120.141', 'rack': -1, 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 32, 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': -1, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 16, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 0, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1025, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': -1, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': 65535, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 0,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 65536,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': '0', 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': '0', 'dbNumber': 1, 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': '1', 'dbOffset': 0, 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': '0', 'dbSize': 1,
                }
            )
        with self.assertRaises(Exception):
            iedConfig = S7IedConfig(
                path = 'test.path/',
                name = 'test.name',
                conf = {
                'ip': '192.168.120.141', 'rack': 0, 'slot': 0, 'dbNumber': 1, 'dbOffset': 0, 'dbSize': '12',
                }
            )

if __name__ == '__main__':
    unittest.main()