import os
import sys
import inspect
import unittest
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from src.domain.core.stream.stream_controller import StreamController
from src.domain.core.stream.stream_subscription import StreamSubscription

log = app_logger.get_logger('StreamControllerTest')

class StreamData:
    def __init__(self,
        value1: int = None,
        value2: str = None,
    ) -> None:
        self.value1 = value1
        self.value2 = value2
    def __str__(self) -> str:
        # return f'[StreamData] \t{self.value1}({type(self.value1)}) \t{self.value2}({type(self.value2)})'
        return f'[StreamData] \t{self.value1} \t{self.value2})'

class StreamControllerTest0(unittest.IsolatedAsyncioTestCase):
    async def test_StreamController_onListen_callback(self):
        self.sourceDataIndex = 0
        self.__onListen_called = False
        def __onListen():
            log.info(f'__onListen called')
            self.__onListen_called = True
        sourceData =  [
            StreamData(717,'StreamController test data - the first'),
            StreamData(718,'StreamController test data 0'),
            StreamData(719,'StreamController test data 1'),
            StreamData(719,'StreamController test data 2'),
            StreamData(719,'StreamController test data 3'),
            StreamData(720,'StreamController test data - the last'),
        ]
        streamController = StreamController[StreamData](
            onListen = __onListen,
        )
        def onData(data: StreamData):
            log.info(f'data: {data}')
        def onDone():
            log.info(f'')
        def onError(error: Exception):
            log.error(f'error: {error}')
            # self.fail('Только данные дожны быть, без ошибок')
        subscription = streamController.stream.listen(
            onData = onData,
            onDone = onDone,
            onError = onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        self.assertEqual(self.__onListen_called, True)
        for d in sourceData:
            streamController.add(d)
        streamController.close()


class StreamControllerTest1(unittest.IsolatedAsyncioTestCase):
    def test_StreamController_create(self):
        with self.assertRaises(Exception):
            stream = StreamController[int](onListen='string')
        stream = StreamController[int](
        )
        self.assertIsInstance(stream, StreamController)


    async def test_StreamController_add_data(self):
        self.sourceDataIndex = 0
        sourceData =  [
            StreamData(717,'StreamController test data - the first'),
            StreamData(718,'StreamController test data 0'),
            StreamData(719,'StreamController test data 1'),
            StreamData(719,'StreamController test data 2'),
            StreamData(719,'StreamController test data 3'),
            StreamData(720,'StreamController test data - the last'),
        ]
        streamController = StreamController[StreamData](
        )
        def onData(data: StreamData):
            log.info(f'data: {data}')
            self.assertEqual(data, sourceData[self.sourceDataIndex])
            self.sourceDataIndex += 1
        def onDone():
            log.info(f'')
        def onError(error: Exception):
            log.error(f'error: {error}')
            self.fail('Только данные дожны быть, без ошибок')
        subscription = streamController.stream.listen(
            onData = onData,
            onDone = onDone,
            onError = onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        for d in sourceData:
            streamController.add(d)
        streamController.close()

    async def test_StreamController_add_error(self):
        self.test_StreamController_add_data_completted = False
        sourceData =  [
            Exception('StreamController test error 0 - the first'),
            Exception('StreamController test error 1'),
            Exception('StreamController test error 2'),
            Exception('StreamController test error 3'),
            Exception('StreamController test error 4 - the last'),
        ]
        streamController = StreamController[StreamData](
        )
        def onData(data: StreamData):
            log.info(f'data: {data}')
            self.fail('Только ошибки дожны быть, без данных')
        def onDone():
            log.info(f'')
        def onError(error: Exception):
            log.error(f'error: {error}')
            self.assertTrue(issubclass(type(error), Exception))
        subscription = streamController.stream.listen(
            onData = onData,
            onDone = onDone,
            onError = onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        for d in sourceData:
            streamController.addError(d)

        streamController.close()


if __name__ == '__main__':
    unittest.main()