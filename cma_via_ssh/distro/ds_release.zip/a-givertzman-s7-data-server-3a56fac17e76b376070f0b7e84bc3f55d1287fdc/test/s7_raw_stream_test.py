import asyncio
import inspect
import logging
import os
import sys
import unittest
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from src.domain.core.stream.stream import Stream
from src.domain.core.stream.stream_subscription import StreamSubscription
from src.infrostructure.s7.s7_client import S7Client
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.s7.s7_raw_stream import S7RawStream
from src.infrostructure.s7.s7_write_data import S7WriteData, WriteResult
from src.infrostructure.s7.s7_read_raw import ReadResult, S7ReadRaw

log = app_logger.get_logger('S7RawStreamTest', level = logging.INFO)

iedConfig = S7IedConfig(
    path = '/test/',
    name = 'test.point',
    description = 'test.point',
    ip = '192.168.120.141',
    rack = 0,
    slot = 1,
    db = {},
)
dbConfig = S7DbConfig(
    path = '/test/',
    name = 'test.point',
    description = 'test.point',
    dbNumber = 17,
    dbOffset = 0,
    dbSize = 44,
    delay = 10,
    data = {},
)

class S7RawStreamTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        self.s7Client = S7Client(
            iedConfig = iedConfig,
        )
        connectResult = await self.s7Client.connect()
        if (connectResult.hasError):
            self.fail(f'could not establish a connection to {iedConfig.ip}\nerror: {connectResult.error}')
        else:
            log.info(f'connection established to {iedConfig.ip}')
            self.rawStream = S7RawStream(
                readDelayMilliseconds = dbConfig.delay,
                readRaw = S7ReadRaw(
                    dbConfig = dbConfig,
                    s7Client = self.s7Client,
                ),
                writeData = S7WriteData(
                    dbConfig = dbConfig,
                    s7Client = self.s7Client,
                ),
            )
        return await super().asyncSetUp()


    async def test_S7RawStream_create(self):
    #     with self.assertRaises(Exception):
    #         readRaw = S7RawStream(
    #             connection = self.connection,
    #             iedConfig = 123,
    #         )
    #     with self.assertRaises(Exception):
    #         readRaw = S7RawStream(
    #             connection = 123,
    #             iedConfig = config,
    #         )
    #     readRaw = S7RawStream(
    #         connection = self.connection,
    #         iedConfig = config,
    #     )
        self.assertIsInstance(self.rawStream, S7RawStream)


    async def test_S7RawStream_get_stream(self):
        stream = self.rawStream.stream()
        self.assertIsInstance(stream, Stream)


    async def test_S7RawStream_listen_data(self):
        self.errorCount = 0
        self.__listen_data_doneCalled = False
        stream = self.rawStream.stream()
        self.assertIsInstance(stream, Stream)
        def __onData(event):
            if (issubclass(type(event), ReadResult)):
                if (event.hasError):
                    self.errorCount += 1
                    log.info(f'event.error: {event.error}')
                elif (event.hasData):
                    log.info(f'event.data: {event.data.data}')
            self.assertIsInstance(event, ReadResult)
        def __onError(error):
            self.errorCount += 1
            log.info(f'event.error: {error}')
            # self.fail(f'Ошибка: {error}\nОшибок в потоке быть не должно, тест ожидает только данные, ')
        def __onDone():
            self.__listen_data_doneCalled = True
            log.info(f'Done!')
        log.info(f'stream.listen')
        subscription = stream.listen(
            onData=__onData,
            onDone=__onDone,
            onError=__onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        count = 0
        # tasks = asyncio.all_tasks()
        # await asyncio.gather(*tasks)
        while not self.__listen_data_doneCalled and count < 10:
            # for thread in threading.enumerate(): 
            #     print(f'thread.name: {thread.name}')
            # tasks = asyncio.all_tasks()
        #     for t in tasks:
        #         log.info(f'task: {t.get_name()} {t._state}')
            await asyncio.sleep(100/1000)
            count += 1
        await self.rawStream.cancel()
        self.assertEqual(self.errorCount, 0)
        # self.assertEqual(self.__listen_data_doneCalled, True)



    async def test_S7RawStream_write_data(self):
        self.errorCount = 0
        self.__write_data_doneCalled = False
        stream = self.rawStream.stream()
        self.assertIsInstance(stream, Stream)
        def __onDone(result: WriteResult):
            if (result.hasError):
                self.errorCount += 1
                log.info(f'write error: {result.error}')
            if (result.hasData):
                log.info(f'write result: {result.data}')
                self.__write_data_doneCalled = True
            log.info(f'write Done!')
        self.rawStream.write(
            offset = 2,
            buffer = b'0000101',
            onDone =__onDone,
        )
        await self.rawStream.cancel()
        self.assertEqual(self.errorCount, 0)
        self.assertEqual(self.__write_data_doneCalled, True)


    async def test_S7RawStream_write_error(self):
        self.errorCount = 0
        self.__write_error_doneCalled = False
        stream = self.rawStream.stream()
        self.assertIsInstance(stream, Stream)
        def __onDone(result: WriteResult):
            if (result.hasError):
                log.info(f'write error: {result.error}')
                self.__write_error_doneCalled = True
            if (result.hasData):
                self.errorCount += 1
                log.info(f'write result: {result.data}')
            log.info(f'write Done!')
        self.rawStream.write(
            offset = 2000000000,
            buffer = b'0000001',
            onDone =__onDone,
        )
        await self.rawStream.cancel()
        self.assertEqual(self.errorCount, 0)
        self.assertEqual(self.__write_error_doneCalled, True)

if __name__ == '__main__':
    unittest.main()