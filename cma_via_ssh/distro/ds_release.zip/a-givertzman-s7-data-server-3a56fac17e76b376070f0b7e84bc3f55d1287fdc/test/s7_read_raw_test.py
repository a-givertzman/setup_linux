import asyncio
import logging
import unittest
import os
import sys
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from src.infrostructure.s7.s7_client import S7Client
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.s7.s7_read_raw import ReadResult, ReadResultData, S7ReadRaw

log = app_logger.get_logger('S7ReadRawTest', level = logging.INFO)

iedConfig = S7IedConfig(
    path = '/test/',
    name = 'test.ied',
    description = 'test.ied',
    ip = '192.168.120.141',
    rack = 0,
    slot = 1,
    db = {},
)
dbConfig = S7DbConfig(
    path = '/test/',
    name = 'test.db',
    description = 'test.db',
    dbNumber = 17,
    dbOffset = 0,
    dbSize = 44,
    data = {},
)
wrongDbConfig = S7DbConfig(
    path = '/test/',
    name = 'test.db',
    description = 'test.db',
    dbNumber = 17,
    dbOffset = 0,
    dbSize = 44,
    data = {},
)
wrongDbConfig.dbNumber = -1

class S7ReadRawTest(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self) -> None:
        self.s7Client = S7Client(
            iedConfig = iedConfig,
        )
        await self.s7Client.connect()
        return await super().asyncSetUp()


    async def test_S7ReadRaw_create(self):
        with self.assertRaises(Exception):
            readRaw = S7ReadRaw(
                s7Client = self.s7Client,
                dbConfig = 123,
            )
        with self.assertRaises(Exception):
            readRaw = S7ReadRaw(
                s7Client = 123,
                dbConfig = dbConfig,
            )
        readRaw = S7ReadRaw(
            s7Client = self.s7Client,
            dbConfig = dbConfig,
        )
        self.assertIsInstance(readRaw, S7ReadRaw)
        await asyncio.sleep(1)


    async def test_S7ReadRaw_read_data(self):
        readCount = 100
        log.info(f'\n')
        s7ReadRaw = S7ReadRaw(
            s7Client = self.s7Client,
            dbConfig = dbConfig,
        )
        self.assertIsInstance(s7ReadRaw, S7ReadRaw)
        for i in range(readCount):
            readResult = await s7ReadRaw.read()
            self.assertIsInstance(readResult, ReadResult)
            self.assertIsInstance(readResult.data, ReadResultData)
            # log.info(f'readResult: {readResult}')
            # log.info(f'readResult.data: {readResult.data}')
            # log.info(f'readResult.data: {readResult.data.data}')
        await asyncio.sleep(1)


    async def test_S7ReadRaw_read_error(self):
        readCount = 3
        ok = False
        log.info(f'\n')
        readRaw = S7ReadRaw(
            s7Client = self.s7Client,
            dbConfig = wrongDbConfig,
        )
        self.assertIsInstance(readRaw, S7ReadRaw)
        for i in range(readCount):
            readResult = await readRaw.read()
            if (readResult.hasData):
                self.fail('Данных быть не должно')
            elif (readResult.hasError):
                ok = True
        self.assertEqual(ok, True)
        await asyncio.sleep(1)


    async def test_S7ReadRaw_read_data_onDone(self):
        readCount = 100
        log.info(f'\n')
        readRaw = S7ReadRaw(
            s7Client = self.s7Client,
            dbConfig = dbConfig,
        )
        self.assertIsInstance(readRaw, S7ReadRaw)
        self.controlIndex = 0
        def __onDone(readResult: ReadResult):
            if (readResult.hasError):
                self.fail(readResult.error)
            elif (readResult.hasData):
                self.assertIsInstance(readResult, ReadResult)
                self.assertIsInstance(readResult.data, ReadResultData)
                # log.info(f'readResult: {readResult}')
                # log.info(f'readResult.data: {readResult.data}')
                # log.info(f'readResult.data: {readResult.data.data}')
                self.controlIndex += 1
        # while self.controlIndex < readCount:
        self.exTaskStack = []
        while self.controlIndex < readCount:
        # for i in range(readCount+ 1):
            self.exTaskStack.append(readRaw.read(
                onDone = __onDone)
            )
            await asyncio.sleep(5/1000)

        while self.controlIndex < readCount:
            await asyncio.sleep(10/1000)
        self.assertEqual(self.controlIndex, readCount)
        await asyncio.sleep(1)


    async def test_S7ReadRaw_read_error_onDone(self):
        readCount = 3
        log.info(f'\n')
        readRaw = S7ReadRaw(
            s7Client = self.s7Client,
            dbConfig = wrongDbConfig,
        )
        self.assertIsInstance(readRaw, S7ReadRaw)
        self.controlIndex = 0
        def __onDone(readResult: ReadResult):
            if (readResult.hasError):
                self.controlIndex += 1
            elif (readResult.hasData):
                self.fail('Должны быть только ошибки')
        self.exTaskStack = []
        while self.controlIndex < readCount:
            self.exTaskStack.append(readRaw.read(
                onDone = __onDone)
            )
            await asyncio.sleep(10/1000)

        while self.controlIndex < readCount:
            await asyncio.sleep(10/1000)
        self.assertEqual(self.controlIndex, readCount)
        await asyncio.sleep(1)


if __name__ == '__main__':
    unittest.main()