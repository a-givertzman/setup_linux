import os
import sys
import inspect
import unittest
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from ds_data_point_path import DSDataPointPath

log = app_logger.get_logger('DSDataPointPathTest')

class DSDataPointPathTest(unittest.IsolatedAsyncioTestCase):
    _path = 'line1.ied11.db902_panel_controls'
    def setUp(self) -> None:
        return super().setUp()
    
    def test_DSDataPointPathT(self):
        with self.assertRaises(Exception):
            dsDataPointPath = DSDataPointPath('')
        with self.assertRaises(Exception):
            dsDataPointPath = DSDataPointPath('...')
        with self.assertRaises(Exception):
            dsDataPointPath = DSDataPointPath('..')
        with self.assertRaises(Exception):
            dsDataPointPath = DSDataPointPath('.s.s')
        with self.assertRaises(Exception):
            dsDataPointPath = DSDataPointPath('s..s')
        with self.assertRaises(Exception):
            dsDataPointPath = DSDataPointPath('s.s.')
        dsDataPointPath = DSDataPointPath(
            self._path
        )
        self.assertIsInstance(dsDataPointPath, DSDataPointPath)
        self.assertEqual(self._path.split('.')[0], dsDataPointPath.line())
        self.assertEqual(self._path.split('.')[1], dsDataPointPath.ied())
        self.assertEqual(self._path.split('.')[2], dsDataPointPath.db())



if __name__ == '__main__':
    unittest.main()

