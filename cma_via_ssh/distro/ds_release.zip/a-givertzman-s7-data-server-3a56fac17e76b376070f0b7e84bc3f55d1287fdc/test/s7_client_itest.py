import os
import sys
import inspect
import datetime
import multiprocessing
from time import sleep
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
import src.infrostructure.s7.s7_client as s7_client
from src.infrostructure.s7.s7_ied_config import S7IedConfig

log = app_logger.get_logger('S7ClientTest1')

pName = multiprocessing.current_process().name
log.info(f'[{pName}] ')
finished1 = False
completted1 = False

def __onConnectDone(result: s7_client.ConnectResult):
    pName = multiprocessing.current_process().name
    if (result.hasData):
        finished1 = True

def __onDisconnectDone(result):
    pName = multiprocessing.current_process().name
    log.info(f'[{pName}] ')
    log.info(f'[{pName}] disconnected successful')
    completted1 = True

def connect():
    pName = multiprocessing.current_process().name
    log.info(f'[{pName}] client connecting...')
    client = s7_client.S7Client(
        # reconnectDelay = 0,
        iedConfig = S7IedConfig(
            ip = '192.168.120.241',
            # ip = '192.168.120.141',
            rack = 0,
            slot = 1,
        )
    )
    connectionResult = client.connectInThread()
    if (connectionResult.hasData):
        log.info(f'[{pName}] client connected...\n\t{connectionResult}')
        for value in range(1000):
            readResult = connectionResult.connection.db_read(902, 0, 32)
            readResult = connectionResult.connection.db_read(903, 0, 164)
            readResult = connectionResult.connection.db_read(904, 0, 18)
            readResult = connectionResult.connection.db_read(905, 0, 128)
            readResult = connectionResult.connection.db_read(906, 0, 108)
            log.info(f'[{pName}] readResult[{value}]...\n\t{readResult}')
    return connectionResult

def onConnection(result: s7_client.ConnectResult):
    pName = multiprocessing.current_process().name
    if (result.hasData): 
        log.info(f'[{pName}] disconnecting...\n\t{result.connection}')
        result.connection.disconnect()
    else:
        log.info(f'[{pName}] disconnecting...\n\t{result.error}')
    __onDisconnectDone(result)

if __name__ == '__main__':
    taskCount = 5
    cpuCount = multiprocessing.cpu_count()
    cpuFactor = round(taskCount / cpuCount) + 1
    pName = multiprocessing.current_process().name
    log.info(f'[{pName}] cpuCount: {cpuCount}\tcpuFactor: {cpuFactor}\tpool: {cpuCount * cpuFactor}')

    t1 = datetime.datetime.now()

    with multiprocessing.Pool(
        cpuCount * cpuFactor
    ) as multiprocessingPool:
        for value in range(taskCount):
            pName = multiprocessing.current_process().name
            log.info(f'[{pName}] task {value} running...')
            multiprocessingPool.apply_async(
                connect,
                # args=(),
                callback=onConnection
            )
        multiprocessingPool.close()
        multiprocessingPool.join()


    # for value in range(taskCount):
    #     pName = multiprocessing.current_process().name
    #     log.info(f'[{pName}] task {value} running...')
    #     onConnection(connect()),


    t2 = datetime.datetime.now()
    log.info(f'[{pName}] dt: {t1}')
    log.info(f'[{pName}] dt: {t2}')
    dtf = t2 - t1
    log.info(f'[{pName}] dt: {dtf}')
