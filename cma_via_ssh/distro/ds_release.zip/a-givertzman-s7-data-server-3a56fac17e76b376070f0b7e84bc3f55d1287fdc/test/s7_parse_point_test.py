import datetime
import inspect
import os
import sys
import unittest
import src.app_logger as app_logger
from src.domain.core.filter.filter import Filter
from src.domain.ds.ds_status import DSStatus
from src.domain.ds.ds_data_type import DSDataType
from src.infrostructure.s7.s7_parse_point import S7ParsePoint

log = app_logger.get_logger('S7ParsePointTest')

class S7ParsePointTest(unittest.TestCase):

    def test_S7ParsePoint_create(self):
        with self.assertRaises(Exception):
            point = S7ParsePoint()  # type: ignore
        point = S7ParsePoint(
            type = DSDataType.Bool,
            path = '/test/',
            name = 'test.point',
            history = 0,
            alarm = 0,
            offset = 0,
            bit = 0x01,
        )
    
    def test_S7ParsePoint_add_Bool(self):
        print(f'add bool')
        inputVal = [1,1,0,0,1]
        outputVal = [1,1,0,0,1]
        isChanged = [1,0,1,0,1]
        point = S7ParsePoint(
            type = DSDataType.Bool,
            path = '/test/',
            name = 'test.point',
            history = 0,
            alarm = 0,
            offset = 0,
            bit = 0x01,
        )
        for iv, ov, isch in zip(inputVal, outputVal, isChanged):
            point.add(
                value = iv,
                status = DSStatus.ok,
                time = datetime.datetime.now(),
            )
            print(f'input: {iv}\tpoint.value: {point.value}\tis changed: {point.changed}')
            self.assertEqual(point.value, ov)
            self.assertEqual(point.changed, isch)
        point = S7ParsePoint(
            type = DSDataType.Bool,
            path = '/test/',
            name = 'test.point',
            history = 0,
            alarm = 0,
            offset = 0,
            bit = 0x01,
        )
        for iv, ov, isch in zip(inputVal, outputVal, isChanged):
            point.add(
                value = iv > 0,
                status = DSStatus.ok,
                time = datetime.datetime.now(),
            )
            print(f'input: {iv > 0}\tpoint.value: {point.value}\tis changed: {point.changed}')
            self.assertEqual(point.value, ov)
            self.assertEqual(point.changed, isch > 0)


    def test_S7ParsePoint_add_Int(self):
        print(f'add int')
        inputVal = [7,7,3,4,3,2,-2,-1]
        outputVal = [7,7,3,4,3,2,-2,-1]
        isChanged = [1,0,1,1,1,1,1,1]
        point = S7ParsePoint(
            type = DSDataType.Int,
            path = '/test/',
            name = 'test.point',
            history = 0,
            alarm = 0,
            offset = 0,
        )
        for iv, ov, isch in zip(inputVal, outputVal, isChanged):
            point.add(
                value = iv,
                status = DSStatus.ok,
                time = datetime.datetime.now(),
            )
            print(f'input: {iv}\tpoint.value: {point.value}\tis changed: {point.changed}')
            self.assertEqual(point.value, ov)
            self.assertEqual(point.changed, isch > 0)
    
    def test_S7ParsePoint_add_Int_Filtered(self):
        print(f'add int filtered')
        inputVal = [7,7,3,4,3,2,-2,-1]
        outputVal = [7,7,3,3,3,2,-2,-2]
        isChanged = [1,0,1,0,0,1,1,0]
        point = S7ParsePoint(
            type = DSDataType.Int,
            path = '/test/',
            name = 'test.point',
            history = 0,
            alarm = 0,
            offset = 0,
            filter = Filter(
                factor = 1,
                threshold = 2,
                initialValue = 7
            )
        )
        for iv, ov, isch in zip(inputVal, outputVal, isChanged):
            point.add(
                value = iv,
                status = DSStatus.ok,
                time = datetime.datetime.now(),
            )
            print(f'input: {iv}\tpoint.value: {point.value}\tis changed: {point.changed}')
            self.assertEqual(point.value, ov)
            self.assertEqual(point.changed, isch > 0)

if __name__ == '__main__':
    unittest.main()