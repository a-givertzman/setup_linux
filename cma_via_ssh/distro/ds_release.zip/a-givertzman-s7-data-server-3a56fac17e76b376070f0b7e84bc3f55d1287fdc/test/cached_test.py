import os
import sys
import inspect
import unittest
import logging
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from src.domain.core.cache.cached import Cached

log = app_logger.get_logger('CachedTest', level = logging.INFO)

originCalled = 0

class CachedTest(unittest.IsolatedAsyncioTestCase):
    class ClassToBeCached:
        def __init__(self,
            val
        ) -> None:
            self.__val = val
        def value(self):
            log.info('calculating')
            global originCalled
            originCalled += 1
            return self.__val * 3
    def setUp(self) -> None:
        return super().setUp()
    def test_Cached(self):
        v = 7
        with self.assertRaises(Exception):
            cache = Cached()
        cache = Cached(
            self.ClassToBeCached(v)
        )
        self.assertIsInstance(cache, Cached)
        self.assertEqual(cache.value(), v * 3)
        self.assertEqual(cache.value(), v * 3)
        self.assertEqual(cache.value(), v * 3)
        self.assertEqual(originCalled, 1)



if __name__ == '__main__':
    unittest.main()

