import inspect
import os
import sys
import unittest
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
import src.domain.core.filter.filter as filter

log = app_logger.get_logger('FilterTest')

class FilterTest(unittest.TestCase):

    def test_Filter_create(self):
        thisMathodName = sys._getframe(  ).f_code.co_name
        with self.assertRaises(Exception):
            s = filter.Filter(
                initialValue = 0,
                factor = 0.9999999,
            )
        with self.assertRaises(Exception):
            s = filter.Filter(
                initialValue = 0,
                factor = 129,
            )
        
        with self.assertRaises(Exception):
            s = filter.Filter(
                initialValue = 0,
                factor = 1,
                threshold = -0.9
            )
        with self.assertRaises(Exception):
            s = filter.Filter(
                initialValue = 0,
                factor = 1,
                threshold = 100.0000009
            )
        
        try:
            s = filter.Filter(
                initialValue = 0,
                factor = 1,
                threshold = 10,
            )
            self.assertIsInstance(s, filter.Filter)
        except Exception as err:
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Filter_add(self):
        s = filter.Filter(
            initialValue = 0,
            factor = 1,
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                # log.info(f'{i}\t:{input[i]}')
                s.add(input[i])
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Filter_out(self):
        s = filter.Filter(
            initialValue = 0,
            factor = 1,
            threshold = 1,
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                s.add(input[i])
                out = s.out()
                # log.info(f'{i}\tin: {input[i]}\tout: {out}')
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Filter_threshold0(self):
        s = filter.Filter(
            initialValue = 0,
            factor = 1,
            threshold = 0
        )
        input = [-10, -5, -3 -1, -1, 0, 1, 1, 2, 3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                s.add(input[i])
                out = s.out()
                self.assertEqual(input[i], out)
                # log.info(f'{i}\tin: {input[i]}\tout: {out}')
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')

    def test_Filter_factorAny(self):
        s = filter.Filter(
            initialValue = -1,
            factor = 1.5,
            threshold = 10,
        )
        input = [0, 1, 1, 1, 1, 2, -3, -3, -3, -3, -3, 5, 8, 13, 21, 34, 55, 89, 144, 233, 377, 610, 987, 1597, 2584, 4181, 6765, 10946, 17711, 28657, 46368, 75025, 121393, 196418, 317811]
        try:
            for i in range(len(input)):
                s.add(input[i])
                out = s.out()
                # self.assertNotEqual(input[i], out)
                log.info(f'{i}\tin: {input[i]}\tout: {out}')
        except Exception as err:
            thisMathodName = sys._getframe(  ).f_code.co_name
            self.fail(f'[{thisMathodName}] error:  {type(err)} | {err.args}')


if __name__ == '__main__':
    unittest.main()