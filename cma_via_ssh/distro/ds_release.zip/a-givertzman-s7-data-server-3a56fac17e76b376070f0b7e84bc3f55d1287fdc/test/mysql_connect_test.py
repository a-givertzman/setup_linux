import os
import sys
import inspect
import unittest
import mysql.connector as MySql
import src.app_logger as app_logger
from src.domain.core.cache.cached import Cached
from src.infrostructure.mysql.mysql_config import MySqlConfig
from src.infrostructure.mysql.mysql_connect import MySqlConnect, MySqlConnectResult
from src.infrostructure.mysql.mysql_convert import MySqlConvertToString

log = app_logger.get_logger('MySqlConnectTest')

class MySqlConnectTest(unittest.IsolatedAsyncioTestCase):
    def test_connection(self):
        with self.assertRaises(Exception):
            mySqlConnect = MySqlConnect()  # type: ignore
        mySqlConnect = MySqlConnect(
            config = MySqlConfig(
                host = '127.0.0.1',
                database = 'crane_data_server',
                user = 'crane_data_server',
                password = '00d0-25e4-*&s2-ccds',
                converter_class = MySqlConvertToString,
                raise_on_warnings = True,
            )
        )
        result = mySqlConnect.connect()
        self.assertIsInstance(result, MySqlConnectResult)
        self.assertEqual(result.hasData, True)
        self.assertEqual(result.hasError, False)
        self.assertEqual(result.errors, [])
        self.assertEqual(isinstance(result.connection, (MySql.MySQLConnection, MySql.CMySQLConnection)), True)
        log.info(f'connection_id: {result.connection.connection_id}')

    def test_cached_connection(self):
        with self.assertRaises(Exception):
            mySqlConnect = MySqlConnect()  # type: ignore
        mySqlConnect = Cached[MySqlConnect](
            MySqlConnect(
                config = MySqlConfig(
                    host = '127.0.0.1',
                    database = 'crane_data_server',
                    user = 'crane_data_server',
                    password = '00d0-25e4-*&s2-ccds',
                    converter_class = MySqlConvertToString,
                    raise_on_warnings = True,
                )
            )
        )
        connection_id = None
        for i in range(1000):
            result = mySqlConnect.connect()
            self.assertIsInstance(result, MySqlConnectResult)
            self.assertEqual(result.hasData, True)
            self.assertEqual(result.hasError, False)
            self.assertEqual(result.errors, [])
            self.assertEqual(isinstance(result.connection, (MySql.MySQLConnection, MySql.CMySQLConnection)), True)
            if (connection_id == None):
                connection_id = result.connection.connection_id
            else:
                self.assertEqual(connection_id, result.connection.connection_id)
            log.info(f'connection_id: {result.connection.connection_id}')



if __name__ == '__main__':
    unittest.main()

