import asyncio
import logging
import unittest
import os
import sys
import inspect
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from src.infrostructure.s7.s7_write_data import S7WriteData, WriteResult, WriteStatus
from src.infrostructure.s7.s7_db_config import S7DbConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.s7.s7_client import S7Client

log = app_logger.get_logger('S7WriteData.Test', level = logging.INFO)

iedConfig = S7IedConfig(
    path = '/test/',
    name = 'test.ied',
    description = 'test.ied',
    ip = '192.168.120.141',
    rack = 0,
    slot = 1,
    db = {},
)
dbConfig = S7DbConfig(
    path = '/test/',
    name = 'test.ied',
    description = 'test.ied',
    dbNumber = 17,
    dbOffset = 0,
    dbSize = 26,
    data = {},
)
wrongdbConfig = S7DbConfig(
    path = '/test/',
    name = 'test.ied',
    description = 'test.ied',
    dbNumber = 17,
    dbOffset = 0,
    dbSize = 26,
    data = {},
)
wrongdbConfig.dbNumber = -1

class S7WriteDataTest(unittest.IsolatedAsyncioTestCase):

    async def asyncSetUp(self) -> None:
        self.s7Client = S7Client(
            iedConfig = iedConfig,
        )
        await self.s7Client.connect()
        return await super().asyncSetUp()


    async def test_S7WriteData_create(self):
        with self.assertRaises(Exception):
            s7WriteData = S7WriteData(
                s7Client = self.s7Client,
                dbConfig = 123,
            )
        with self.assertRaises(Exception):
            s7WriteData = S7WriteData(
                s7Client = 123,
                dbConfig = dbConfig,
            )
        s7WriteData = S7WriteData(
            s7Client = self.s7Client,
            dbConfig = dbConfig,
        )
        self.assertIsInstance(s7WriteData, S7WriteData)
        await asyncio.sleep(1)
    async def test_S7WriteData_write_data(self):
        readCount = 100
        log.info(f'\n')
        s7WriteData = S7WriteData(
            s7Client = self.s7Client,
            dbConfig = dbConfig,
        )
        self.assertIsInstance(s7WriteData, S7WriteData)
        for i in range(readCount):
            writeResult = s7WriteData.write(
                offset = 2,
                buffer = b'0001',
            )
            log.info(f'writeResult.data: {writeResult.data}')
            await asyncio.sleep(1/1000)
            self.assertIsInstance(writeResult, WriteResult)
            self.assertEqual(writeResult.hasData, True)
            self.assertEqual(writeResult.hasError, False)
            # log.info(f'writeResult.data: {writeResult.data}')
        await asyncio.sleep(1)


    async def test_S7WriteData_write_error(self):
        readCount = 3
        log.info(f'\n')
        s7WriteData = S7WriteData(
            s7Client = self.s7Client,
            dbConfig = dbConfig,
        )
        self.assertIsInstance(s7WriteData, S7WriteData)
        for i in range(readCount):
            writeResult = s7WriteData.write(
                offset = -1,
                buffer = b'0001',
            )
            log.info(f'writeResult.data: {writeResult.data}')
            await asyncio.sleep(1/1000)
            self.assertIsInstance(writeResult, WriteResult)
            self.assertEqual(writeResult.hasData, False)
            self.assertEqual(writeResult.hasError, True)
            # log.info(f'writeResult.data: {writeResult.data}')
        await asyncio.sleep(1)


if __name__ == '__main__':
    unittest.main()