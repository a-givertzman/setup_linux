import os
import sys
import inspect
import threading
import unittest
import tracemalloc
from threading import Thread
currentdir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir)
import src.app_logger as app_logger
from src.domain.core.stream.stream import Stream
from src.domain.core.stream.stream_subscription import StreamSubscription

log = app_logger.get_logger('StreamTest')

class StreamData:
    def __init__(self,
        value1: int = None,
        value2: str = None,
    ) -> None:
        self.value1 = value1
        self.value2 = value2
    def __str__(self) -> str:
        # return f'[StreamData] \t{self.value1}({type(self.value1)}) \t{self.value2}({type(self.value2)})'
        return f'[StreamData] \t{self.value1} \t{self.value2})'

class TraceThread(threading.Thread):
    def __init__(self,  *args, **kwargs):
        super(TraceThread, self).__init__(*args, **kwargs)
        self._stop_event = threading.Event()

    def stop(self):
        self._stop_event.set()
        print('TraceThread stoped')

    def stopped(self):
        return self._stop_event.is_set()


class StreamTest(unittest.IsolatedAsyncioTestCase):
    def traceProcces(self):
        print('TraceThread started')
        # tracemalloc.start(25)
        # while True:
        #     snap = tracemalloc.take_snapshot()
        #     domainFilter = tracemalloc.DomainFilter(True, 0)
        #     snap = snap.filter_traces([domainFilter])
        #     topStats = snap.statistics('lineno', True)
        #     for stat in topStats[:10]:
        #         print(stat)
        
    async def asyncSetUp(self) -> None:
        self.traceThread: Thread = None
        return await super().asyncSetUp()

    def test_Stream_create(self):
        with self.assertRaises(Exception):
            stream = Stream[int](1)
        stream = Stream[int]()
        self.assertIsInstance(stream, Stream)
        stream = Stream.fromIterable(
            [0,1,2,3,4,5]
        )
        self.assertIsInstance(stream, Stream)

    async def test_Stream_listen_data(self):
        self.test_Stream_listen_data_completted = 0
        sourceData =  [
            StreamData(0,'Stream test data'),
            StreamData(1,'Stream test data'),
            StreamData(2,'Stream test data'),
        ]
        stream = Stream[StreamData].fromIterable(
            sourceData
        )
        def __onData(data: StreamData):
            log.info(f'data: {data}')
            self.assertEqual(type(data), StreamData)
            self.test_Stream_listen_data_completted += data.value1
        def __onDone():
            self.test_Stream_listen_data_completted += 10
            log.info(f'done')
        def __onError(error: Exception):
            log.error(f'error: {error}')
            self.test_Stream_listen_data_completted -= 10
            self.fail('Только данные дожны быть, без ошибок')
        subscription = stream.listen(
            onData = __onData,
            onDone = __onDone,
            onError = __onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        subscription.cancel()
        self.assertEqual(self.test_Stream_listen_data_completted, 13)

    async def test_Stream_listen_error(self):
        self.test_Stream_listen_error_completted = 0
        sourceData =  [
            Exception('Stream test exception'), 
            Exception('Stream test exception'), 
            Exception('Stream test exception'), 
        ]
        stream = Stream[StreamData].fromIterable(sourceData)
        def onData(data: StreamData):
            log.info(f'data: {data}')
            self.test_Stream_listen_error_completted -= 10
            self.fail('Только ошибка дожна быть, без данных')
        def onDone():
            self.test_Stream_listen_error_completted += 10
            log.info(f'done')
        def onError(error: Exception):
            log.error(f'error: {error}')
            self.test_Stream_listen_error_completted += 1
        subscription = stream.listen(
            onData = onData,
            onDone = onDone,
            onError = onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        subscription.cancel()
        self.assertEqual(self.test_Stream_listen_error_completted, 13)

    async def test_Stream_listen(self):
        self.test_Stream_listen_completted = 0
        sourceData =  [
                StreamData(5,'5 - the first'), 
                Exception('Ошибка в генераторе'), 
                StreamData(3, '3'),
                StreamData(0, '0'), 
                StreamData(1, '1'),
                StreamData(555,'555 - the last'),
        ]
        self.traceThread = TraceThread(target=self.traceProcces)
        self.traceThread.start()
        # self.traceProcess.join()
        def __onListen(subscription):
            self.test_Stream_listen_completted += 333
            log.info(f'subscription: {subscription}')
            self.assertEqual(type(subscription), StreamSubscription)
            for e in sourceData:
                stream.sink.send(e)
            # for e in range(1000):
            #     stream.sink.send(StreamData(e, f'{e}'))
        stream = Stream[StreamData](
            onListen = __onListen
        )
        def __onData(data: StreamData):
            log.info(f'data: {data}')
            self.assertEqual(type(data), StreamData)
            self.test_Stream_listen_completted += data.value1

        def __onDone():
            self.test_Stream_listen_completted += 10            
            log.info(f'done')

        def __onError(error: Exception):
            log.error(f'error: {error}')
            self.test_Stream_listen_completted += 1000

        subscription = stream.listen(
            onData = __onData,
            onDone = __onDone,
            onError = __onError,
        )
        self.assertIsInstance(subscription, StreamSubscription)
        subscription.cancel()
        self.traceThread.stop()
        log.info(f'score: {self.test_Stream_listen_completted}')
        self.assertEqual(self.test_Stream_listen_completted, 1907)


if __name__ == '__main__':
    unittest.main()

