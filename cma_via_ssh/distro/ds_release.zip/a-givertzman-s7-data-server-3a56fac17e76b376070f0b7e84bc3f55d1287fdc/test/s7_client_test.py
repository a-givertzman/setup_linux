import os
import sys
import snap7
import asyncio
import inspect
import unittest
from time import sleep
import src.app_logger as app_logger
from src.infrostructure.s7.s7_client import S7Client
from src.infrostructure.s7.s7_ied_config import S7IedConfig

log = app_logger.get_logger('S7ClientTest')

class S7ClientTest(unittest.IsolatedAsyncioTestCase):
# class S7ClientTest(unittest.TestCase):

    def test_S7Client_create(self):
        log.info('')
        with self.assertRaises(Exception):
            client = S7Client()  # type: ignore
        client = S7Client(
            reconnectDelay = 0,
            iedConfig = S7IedConfig(
                path = '/test/',
                name = 'test.ied',
                conf = {
                    'description': 'test.ied',
                    'ip': '192.168.120.243',
                    'rack': 0,
                    'slot': 1,
                    'db': {},
                }
            ),
        )
        self.assertIsInstance(client, S7Client)

    async def test_S7Client_connect_succes(self):
        log.info('')
        count = 0
        client = S7Client(
            reconnectDelay = 0,
            iedConfig = S7IedConfig(
                path='',
                name='',
                conf = {
                    'description': 'test.ied',
                    'ip': '192.168.120.243',
                    'rack': 0,
                    'slot': 1,
                    'db': {},
                }
            ),
        )
        client.connect()
        log.info(f'awaiting while normal connection to be established...')
        while (True):
            if (client.connected):
                self.assertIsInstance(client.connection, snap7.client.Client)
                log.info(f'connected successful')
                break
            elif (count >= 200):
                self.assertEqual(client.connected, True)
                break
            await asyncio.sleep(100/1000)
            count += 1
        log.info(f'disconnecting...')
        client.cancel()
        client.join

    async def test_S7Client_connect_fail(self):
        log.info('')
        count = 0
        client = S7Client(
            reconnectDelay = 3000,
            iedConfig = S7IedConfig(
                path = '',
                name = '',
                conf = {
                    'description': 'test.ied',
                    'ip': '192.168.120.253',
                    'rack': 0,
                    'slot': 1,
                    'db': {},
                }
            ),
        )
        client.connect()
        log.info(f'awaiting while wrong connection to be failed...')
        while True:
            if (client.connected):
                self.assertEqual(client.connected, False)
                break
            elif (count >= 200):
                log.info(f'wrong connection not connected successful')
                break
            await asyncio.sleep(100/1000)
            count += 1
        log.info(f'disconnecting any way...')
        client.cancel()
        client.join()


if __name__ == '__main__':
    unittest.main()