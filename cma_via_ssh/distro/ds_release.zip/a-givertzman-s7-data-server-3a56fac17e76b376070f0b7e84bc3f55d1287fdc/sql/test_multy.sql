drop table if exists `test_multy`;

CREATE TABLE `test_multy` ( 
  `timestamp` TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ,
  `id` TINYINT NOT NULL,
  `value` DECIMAL(8,2) NOT NULL DEFAULT 0.00  COMMENT 'Нагрузка лебедки 1 (тонны)' ,
  CONSTRAINT `PRIMARY` PRIMARY KEY (`timestamp`, `id`)
);

ALTER TABLE `test_multy` ADD INDEX `id_idx` (`id`);
ALTER TABLE `test_multy` ADD INDEX `timestamp_idx` (`timestamp`);

drop procedure if exists `testLoop`;

DELIMITER //
CREATE PROCEDURE `testLoop`()
BEGIN
    DECLARE vIndex INT unsigned DEFAULT 0;
    DECLARE vMax int unsigned DEFAULT 10000000;
    declare vId int unsigned default 1;
    -- truncate table `test_multy`;
    start transaction;
    WHILE vIndex < vMAx DO
        -- start transaction;
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 1, floor(0 + (rand() * 65535)) );
        -- do sleep(1e-6); #CURRENT_TIMESTAMP(6);
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 2, floor(0 + (rand() * 65535)) );
        -- do sleep(1e-6); #CURRENT_TIMESTAMP(6);
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 3, floor(0 + (rand() * 65535)) );
        -- do sleep(1e-6); #CURRENT_TIMESTAMP(6);
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 4, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 5, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 6, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 7, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 8, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 9, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 10, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 11, floor(0 + (rand() * 65535)) );
        insert into `test_multy` (`timestamp`, `id`, `value`) values ( CURRENT_TIMESTAMP(6), 12, floor(0 + (rand() * 65535)) );
        set vIndex = vIndex + 1;
        -- commit;
    END WHILE;
    commit;
END
DELIMITER ;

call `testLoop`();

drop procedure if exists `testLoop`;