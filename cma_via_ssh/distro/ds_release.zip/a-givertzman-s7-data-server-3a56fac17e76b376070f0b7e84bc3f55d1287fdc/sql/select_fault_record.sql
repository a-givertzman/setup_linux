select @tripId, @tripT;
select `id`, `timestamp`  into @tripId, @tripT from `test_multy` limit 500000,1;
set @tDiff = (select min(`diff`) as diff
    from
      ( select *, TIMESTAMPDIFF(MICROSECOND, `timestamp`, @tripT) as `diff`
        from `test_multy` where `timestamp` <= @tripT #and t2.`id` != @tripId
      ) t1
    group by `id`
    order by `diff` desc
    limit 1);
select @tDiff;

select *, TIMESTAMPDIFF(MICROSECOND, `timestamp`, @tripT)
from `test_multy`
where TIMESTAMPDIFF(MICROSECOND, `timestamp`, @tripT) between 0 and @tDiff;

