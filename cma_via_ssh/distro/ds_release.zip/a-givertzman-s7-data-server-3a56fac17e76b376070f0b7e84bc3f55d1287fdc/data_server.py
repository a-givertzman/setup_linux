import logging
import threading
import src.app_logger as app_logger
from src.domain.core.result import CancelResult
from src.infrostructure.core.socket_server import SocketServer
from src.infrostructure.ds.config.ds_config import DSConfig
from src.infrostructure.ds.ds_send_event import DSSendEvent
from src.infrostructure.ds.ds_data_source import DSDataSource
from src.infrostructure.ds.ds_store_event import DSStoreEvent
from src.infrostructure.ds.store_fault.ds_store_fault import DSStoreFault
from src.infrostructure.ds.ds_handle_client_cmd import DSHandleClientCmd

log = app_logger.get_logger('DataServer', level = logging.INFO)

class DataServer(threading.Thread):
    def __init__(self,
        configFileName: str,
        dataServerAddress: tuple[str, int] = ('127.0.0.1', 16688),
        apiServerAddress: tuple[str, int] = ('127.0.0.1', 8080),
        daemon: bool = True,
    ) -> None:
        '''- configFileName: str - путь к файлу конфигурации,
            - dataServerAddress: tuple[str, int] - (ip, port) адрес, на котором будет запущен данный сервер
            - apiServerAddress: tuple[str, int] - (ip, port) адрес api сервера,
            - daemon: bool - режим потока, в котором будет запужен данный сервис. 
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        # self.__cancel = False
        # self.__isActive = False
        self.__configFileName = configFileName
        self.__dataServerAddress = dataServerAddress
        self.__apiServerAddress = apiServerAddress
        self.__socketServer: SocketServer | None = None
        self.__sendEvent: DSSendEvent | None = None
        self.__storeEvent: DSStoreEvent | None = None
        self.__storeFault: DSStoreFault | None = None
        self.__handleClientCmd: DSHandleClientCmd | None = None
        super(DataServer, self).__init__(
            name = 'DataServer.Thread',
            daemon = daemon,
        )        

    def run(self):
        '''Запускает в работу [DataServer]'''
        # self.__isActive = True
        dsConfig = DSConfig(
            fileName = self.__configFileName,
            address = self.__apiServerAddress,
        )
        '''Запуск контейнера для сбора данных со всех подчиненных устройст'''
        if dsConfig.dataSource.enabled:
            self.__dataSource = DSDataSource(
                config = dsConfig.dataSource,
            )
            self.__dataSource.start()
        else:
            log.info('Сервис [DSDataSource] контейнер данных для аккумулирования данных со всех подчиненных устройст отключен в конфигурации')
        '''Запуск сервера для подключения фронтендов'''
        self.__socketServer = SocketServer(
            address = self.__dataServerAddress,
            reconnectTimeout = 3000,
            daemon = False,
        )
        self.__socketServer.start()
        '''Трансляция всех событий фронтендам'''
        if dsConfig.sendEvent.enabled:
            self.__sendEvent = DSSendEvent(
                queue = self.__dataSource.queue(),
                onEvent = self.__socketServer.send,
                daemon = True,
            )
            self.__sendEvent.start()
        else:
            log.info('Сервис [DSSendEvent] трансляции событий клиентам отключен в конфигурации')
        '''Регистрация исторических событий'''
        if dsConfig.storeEvent.enabled:
            self.__storeEvent = DSStoreEvent(
                queue = self.__dataSource.queue(
                    list(dsConfig.historyPoints().keys())
                ),
                historyPoints = dsConfig.historyPoints(),
                address = self.__apiServerAddress,
            )
            # dsConfig.alarmPoints()
            self.__storeEvent.start()
        else:
            log.info('Сервис [DSStoreEvent] регистрации исторических событий отключен в конфигурации')
        '''Регистрация аварий'''
        if dsConfig.storeFault.enabled:
            self.__storeFault = DSStoreFault(
                queue = self.__dataSource.queue(
                    list(dsConfig.faultPoints().keys())
                ),
                faultPoints = dsConfig.faultPoints(),
                address = self.__apiServerAddress,
                config = dsConfig.storeFault,
                requestList = self.__dataSource.onRequestList,
            )
            self.__storeFault.start()
        else:
            log.info('Сервис [DSStoreFault] регистрации аварий отключен в конфигурации')
        '''Трансляция команд управления подчиненным устройствам'''
        if dsConfig.handleCmd.enabled:
            self.__handleClientCmd = DSHandleClientCmd(
                stream = self.__socketServer.stream,
                onRequestAll = self.__dataSource.onRequestAll,
                onRequestList = self.__dataSource.onRequestList,
                onRequestTime = None,
                onRequestAlarms = None,
                onRequestPath = None,
                onSyncTime = None,
                onCommonCmd = self.__dataSource.onCommonCmd,
            )
            self.__handleClientCmd.start()
        else:
            log.info('Сервис [DSHandleClientCmd] трансляции команд управления отключен в конфигурации')
        # if (self.__socketServer):
        #     self.__socketServer.join()
        #     log.info(f'SocketServer stopped')
        # if (self.__handleClientCmd):
        #     self.__handleClientCmd.join()
        #     log.info(f'DSHandleClientCmd stopped')
        # if (self.__dataSource):
        #     self.__dataSource.join()
        #     log.info(f'DSDataSource stopped')
        # if (self.__storeEvent):
        #     self.__storeEvent.join()
        #     log.info(f'DSStoreEvent stopped')
        # if (self.__storeFault):
        #     self.__storeFault.join()
        #     log.info(f'DSStoreFault stopped')
        # if (self.__sendEvent):
        #     self.__sendEvent.join()
        #     log.info(f'DSSendEvent stopped')
        # if (self.__dsTagId):
        #     self.__dsTagId.join()
        #     log.info(f'DSTagId stopped')
        log.info(f'exit')

    def cancel(self) -> CancelResult:
        # self.__cancel = True
        if (self.__socketServer):
            self.__socketServer.cancel()
        # log.info(f'Stopping SocketServer...')
        if (self.__handleClientCmd):
            self.__handleClientCmd.cancel()
        # log.info(f'Stopping DSHandleClientCmd...')
        if (self.__dataSource):
            self.__dataSource.cancel()
        # log.info(f'Stopping DSDataSource...')
        if (self.__storeEvent):
            self.__storeEvent.cancel()
        # log.info(f'Stopping DSStoreEvent...')
        if (self.__storeFault):
            self.__storeFault.cancel()
        # log.info(f'Stopping DSStoreFault...')
        if (self.__sendEvent):
            self.__sendEvent.cancel()
        # log.info(f'Stopping DSSendEvent...')
        log.info(f'Cancel done.')
        return CancelResult(done = True)
