# import os
import sys
import signal
import pathlib
import threading
import faulthandler
import src.app_logger as app_logger
from data_server import DataServer

sys.setrecursionlimit(10**6)
threading.stack_size(2**26)
faulthandler.enable()
# sys.settrace
log = app_logger.get_logger('sdsRun')

dataServer: DataServer | None = None

def haltHandler(signum = None, frame = None):
    log.info(f'Signal handler called with signal: {signum}')
    # time.sleep(1)  #here check if process is done
    log.info('Stoping services...')
    if (dataServer):
        dataServer.cancel()

if __name__ == '__main__':
    for sig in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGQUIT]:
        signal.signal(sig, haltHandler)

    log.info(f'DataServer creating...')
    path = pathlib.Path(__file__).parent.resolve()
    log.info(f'DataServer path: {path}')
    dataServer = DataServer(
        configFileName = f'{path}/conf.json',
        dataServerAddress = ('127.0.0.1', 16688),
        apiServerAddress = ('127.0.0.1', 8080),
    )
    log.info(f'DataServer creating done')
    log.info(f'DataServer runing...')
    dataServer.start()
    log.info(f'DataServer runing done')
    dataServer.join()
