import os.path
import datetime
import logging
import src.app_logger as app_logger
from src.domain.core.result import CancelResult
from src.domain.ds.ds_data_point import DSDataPoint
from src.infrostructure.ds.ds_line import DSLine
from src.infrostructure.ds.config.ds_config import DSConfig
from obsolete.ds_socket import DSSocket

log = app_logger.get_logger('DataServerEmulate', level = logging.INFO)

class DataServerEmulate:
    def __init__(self,
        configFileName: str,
        dsSocket: DSSocket,
    ) -> None:
        path = os.path.dirname(os.path.abspath(__file__)) + '/'
        assert os.path.isfile(path + configFileName), f'configuration file not found: "{path + configFileName}"'
        self.__configFileName = path = configFileName
        self.__dsSocket = dsSocket
        self.__cancel = False
        self.__lines: dict[str, DSLine] = {}
        self.__serverConnected = False
        self.__t = {}
        self.__t['send'] = datetime.datetime.now()
        self.__v = {}


    def run(self):
        __config = DSConfig(
            fileName = self.__configFileName,
        ).build()

        for lineKey in __config:
            lineConfig = __config[lineKey]
            log.info(f'line: {lineKey}')
            line = DSLine(
                config = lineConfig
            )
            streams = line.start()
            self.__lines[lineKey] = line
            for stream in streams:
                stream.listen(
                    onData = self.__onData,
                    onError = self.__onError,
                    onDone = self.__onDone,
                )
        self.__dsSocket.start()
        log.info(f'exit')

    def __logPoint(self, 
        name: str, event: DSDataPoint, writeBack: bool = False,
        line: str = None,
        ied: str = None,
        db: str = None,
    ):
        if (name in event.name):
            tNow = datetime.datetime.now()
            dt = 0
            try:
                dt = (tNow - self.__t[name]).microseconds / 1000
            except:
                pass
            self.__t[name] = tNow
            # print(event)
            # print(dt, event.timestamp, event.name, event.value)
            # if (event.value != 5) and (self.__v[name] != event.value -1):
            #     print('\n', event.timestamp, 'value skiped', self.__v[name], event.value)
            # self.__v[name] = event.value
            if (dt > 65):
                print(dt)
                # print(dt, end = ' ')
            if (writeBack):
                self.__lines[line].writeInt(
                    ied = ied,
                    db = db,
                    name = 'AnalogSensors.Winch.EncoderBR2',
                    value = event.value,
                ),
                self.__lines[line].writeReal(
                    ied = ied,
                    db = db,
                    name = 'AnalogSensors.Winch.LVDT1',
                    value = event.value,
                ),
                self.__lines[line].writeReal(
                    ied = ied,
                    db = db,
                    name = 'AnalogSensors.Winch.LVDT2',
                    value = event.value,
                ),
                # self.__lines[line].writeFloat(
                #     ied = ied,
                #     db = db,
                #     name = 'AnalogSensors.Winch.PressureLineA_1',
                #     value = event.value,
                # ),
                # self.__lines[line].writeFloat(
                #     ied = ied,
                #     db = db,
                #     name = 'AnalogSensors.Winch.PressureLineA_2',
                #     value = event.value,
                # ),


    def __onData(self, event: DSDataPoint):
        # print('event: ', event)
        self.__logPoint(
            writeBack = True,
            line = 'line1',
            ied = 'ied11',
            db = 'db905_visual_data',
            name = 'AnalogSensors.Winch.EncoderBR1', 
            event = event,
        )
            # try:
        # tNow = datetime.datetime.now()
        self.__dsSocket.add(event)
        # dt = (tNow - self.__t['send']).microseconds / 1000
        # log.info(f'send event dt: {dt}')
                # log.info(f'sent event: {event}')
            # except Exception as error:
                # log.error(f'socket.sendall failed: {type(error)} : {error.args}')
                    
        
    def __onError(self, error: Exception):
        print('error: ', error)
        
    def __onDone(self, event = None):
        print('done: ', event)
        

    async def cancel(self) -> CancelResult:
        self.__cancel = True
        self.__dsSocket.cancel()
        __done = False
        for lineKey in self.__lines:
            line = self.__lines[lineKey]
            result = await line.cancel()
            log.info(f'result: {result}')
        return CancelResult(
            done = __done
        )
