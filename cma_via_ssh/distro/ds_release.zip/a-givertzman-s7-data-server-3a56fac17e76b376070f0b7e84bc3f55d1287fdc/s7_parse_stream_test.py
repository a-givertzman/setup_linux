import os
import sys
import asyncio
import datetime
import inspect
import logging
from typing import Generator
import unittest
import src.app_logger as app_logger
from src.infrostructure.s7.s7_client import S7Client
from src.infrostructure.ds.config.ds_config import DSConfig
from src.infrostructure.s7.s7_ied_config import S7IedConfig
from src.infrostructure.s7.s7_parse_stream import S7ParseStream
from src.infrostructure.s7.s7_raw_stream import S7RawStream
from src.infrostructure.s7.s7_write_data import S7WriteData
from src.infrostructure.s7.s7_read_raw import S7ReadRaw
from src.infrostructure.ds.config.ds_line_config import DSLineConfig
from src.domain.ds.ds_data_point import DSDataPoint

log = app_logger.get_logger('S7ParseStreamTest', level = logging.INFO)


configFileName = 'conf.json'

class S7ParseStreamTest(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self) -> None:
        config = DSConfig(
            fileName = configFileName,
            address = ('127.0.0.1', 8080),
        )
        line = config.dataSource.lines.get('line1')
        self.assertIsInstance(line, DSLineConfig)
        if (line):
            iedConfig: S7IedConfig = line.ieds.get('ied11')  # type: ignore
            if (iedConfig and type(iedConfig) == S7IedConfig):
                self.s7Client1 = S7Client(
                    iedConfig = iedConfig,
                )
                self.s7Client1.connect()
                count = 0
                while (not self.s7Client1.connected and count < 100):
                    await asyncio.sleep(10 / 1000)
                    count += 1
                self.s7Client2 = S7Client(
                    iedConfig = iedConfig,
                )
                self.s7Client2.connect()
                count = 0
                while (not self.s7Client2.connected and count < 100):
                    await asyncio.sleep(10 / 1000)
                    count += 1
                if (not self.s7Client2.connected):
                    # error = connectResult.error if connectResult.hasError else connectResult1.error
                    self.fail(f"could not establish a connection to {iedConfig.ip}")
                else:
                    log.info(f"connection established to {iedConfig.ip}")
                self.__parseStreams: list[S7ParseStream] = []
                self.__configs = []
                for key, dbConfig in iedConfig.dbs.items():
                    # formatted = json.dumps(dbConfig, indent = 4)
                    # log.info(f"dbConfig: {formatted}")
                    parseStream = S7ParseStream(
                        path = dbConfig.path,
                        name = dbConfig.name,
                        config = dbConfig,
                        rawStream = S7RawStream(
                            readRaw = S7ReadRaw(
                                dbConfig = dbConfig,
                                s7Client = self.s7Client1,
                            ),
                            writeData = S7WriteData(
                                dbConfig = dbConfig,
                                s7Client = self.s7Client2,
                            ),
                        )
                    )
                    self.__parseStreams.append(
                        parseStream,
                    )
                    self.__configs.append(
                        dbConfig,
                    )
        return await super().asyncSetUp()


    async def test_S7ParseStream_create(self):
        for parseStream in self.__parseStreams:
            log.info(f'parseStream: {parseStream.name}')
            self.assertIsInstance(parseStream, S7ParseStream)


    async def test_S7ParseStream_get_stream(self):
        for parseStream in self.__parseStreams:
            stream = parseStream.stream
            self.assertIsInstance(stream, Generator)


    def write(self, name, value):
        # print('enter', datetime.datetime.now(), 'name:', name, 'value:', value)
        print('stream: ', self.__parseStreams[0].name)
        return self.__parseStreams[0].writeInt(
            name = name,
            value = value,
        )
        # print('exit', datetime.datetime.now())

    async def test_S7ParseStream_listen_data(self):
        self.errorCount = 0
        self.__listen_data_doneCalled = 0
        self.t = {}
        self.t['common'] = datetime.datetime.now()
        self.t['Drive.Speed'] = datetime.datetime.now()
        self.t['Drive.Speed'] = datetime.datetime.now()
        self.v = {}
        self.v['Drive.Speed'] = 0
        def __onData(event: DSDataPoint):
            # tNow = datetime.datetime.now()
            # dt = (tNow - self.t['common']).microseconds / 1000
            # self.t['common'] = tNow
            # print(dt, event)
            # print(dt, event.timestamp, event.name, event.value)
            # log.info(f'{event}')
            # if ('AnalogSensors.Winch.EncoderBR2' in event.name):
            #     tNow = datetime.datetime.now()
            #     dt = (tNow - self.t['AnalogSensors.Winch.EncoderBR2']).microseconds / 1000
            #     self.v['AnalogSensors.Winch.EncoderBR2'] = event.value
            #     self.t['AnalogSensors.Winch.EncoderBR2'] = tNow
            #     print(dt, event.time, event.name, event.value)
            if (event.name == 'Drive.Speed'):
                tNow = datetime.datetime.now()
                dt = (tNow - self.t['Drive.Speed']).microseconds / 1000
                self.t['Drive.Speed'] = tNow
                # print(dt, event.timestamp, event.name, event.value)
                if (event.value != 5) and (self.v['Drive.Speed'] != event.value -1):
                    log.info('\n', event.timestamp, 'value skiped', self.v['Drive.Speed'], event.value)
                self.v['Drive.Speed'] = event.value
                self.__parseStreams[2].writeInt(
                    name = 'Drive.Speed',
                    value = event.value,
                )

        log.info(f'listening streams: {len(self.__parseStreams)}')
        for parseStream in self.__parseStreams:
            count = 0
            cancel = False
            stream = parseStream.stream
            log.info(f'listening stream: {parseStream.name}\tis active: {parseStream.isActive}')
            self.assertIsInstance(stream, Generator)
            for event in parseStream.stream:
                if (event):
                    log.info(f'event: {event}')
                    self.assertIsInstance(event, DSDataPoint)
                    __onData(event = event)
                else:
                    # log.info(f'empty event: {event}')
                    break
                # count += 1
            parseStream.cancel()
            for event in parseStream.stream:
                if (event):
                    pass
                else:
                    break
            log.info(f'exit listening stream: {parseStream.name}')
            log.info(f'\tread count: {count}')
        log.info(f'exit listening streams: {len(self.__parseStreams)}')
        self.assertEqual(self.errorCount, 0)
        # self.assertEqual(self.__listen_data_doneCalled, True)



if __name__ == '__main__':
    unittest.main()