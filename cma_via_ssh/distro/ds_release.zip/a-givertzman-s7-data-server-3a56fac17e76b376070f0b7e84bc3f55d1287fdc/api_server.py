import json
import signal
import socket
import logging
import threading
import src.app_logger as app_logger
from threading import Thread
from datetime import date, datetime
from src.infrostructure.core.api_service import APIService
from src.infrostructure.mysql.mysql_config import MySqlConfig
from src.infrostructure.mysql.mysql_connect import MySqlConnect
from src.infrostructure.mysql.mysql_request import MySqlRequest
from src.infrostructure.mysql.mysql_convert import MySqlConvertToString
from src.infrostructure.mysql.mysql_insert import MySqlInsert
from src.infrostructure.mysql.mysql_select import MySqlSelect
from src.infrostructure.mysql.mysql_select import MySqlResult
from src.infrostructure.mysql.mysql_keep_alve import MySqlKeepAlive
from src.infrostructure.mysql.mysql_insert_keep_alve import MySqlInsertKeepAlive

log = app_logger.get_logger('APIServer', level = logging.DEBUG)

class APIServer(Thread):
    IPV4 = socket.AF_INET
    TCP = socket.SOCK_STREAM
    def __init__(self,
        address: tuple[str, int],
        mySqlConnection: MySqlConnect,
        daemon: bool = False,
    ) -> None:
        '''- address: tuple[str, int] - адрес api сервера;
            - mySqlConnection: MySqlConnect - объект подключения к базе данных;
            - daemon: bool - режим потока, в котором будет запужен данный сервис. 
                Daemon threads are abruptly stopped at shutdown. Their resources (such as open files, database transactions, etc.) 
                may not be released properly. If you want your threads to stop gracefully, make them non-daemonic and use a 
                suitable signalling mechanism such as an Event.'''
        self.__cancel = False
        self.__isActive = False
        self.__clients: list[socket.socket] = []
        self.__services: list[APIService] = []
        self.__address = address
        self.__dbConnection = mySqlConnection
        self.__socket = socket.socket(self.IPV4, self.TCP)
        self.__socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        super(APIServer, self).__init__()
        self.daemon = daemon
        self.__thread1 = None


    def __receiveAll(self, sock: socket.socket):
        data = bytearray()
        buff_size = 4096
        while True: 
            part = sock.recv(buff_size)
            data.extend(part)
            if len(part) < buff_size:
                break
        return data

    def __registerClient(self, clientSocket: socket.socket, address):
        self.__clients.append(clientSocket)
        rawRequest = self.__receiveAll(clientSocket)
        log.info(f'raw request: {rawRequest}')
        mySqlRequest = MySqlRequest(rawRequest)
        if (mySqlRequest.ready):
            log.info(f'request: {mySqlRequest}')
            # if ( 'api-sql'):
            sqlResult = None
            if (mySqlRequest.apiSql == 'select'):
                sqlResult = MySqlSelect(
                    self.__dbConnection,
                ).execute(mySqlRequest)
            if (mySqlRequest.apiSql == 'insert'):
                sqlResult = MySqlInsert(
                    self.__dbConnection,
                ).execute(mySqlRequest)
            if (mySqlRequest.apiSql == 'keep-alive'):
                sqlResult = MySqlSelect(
                    self.__dbConnection,
                ).execute(mySqlRequest)
                service = MySqlKeepAlive(
                    self.__dbConnection,
                    clientSocket,
                )
                self.__services.append(service)
                service.start()
                # sqlResult = MySqlResult(
                #     data = {},
                # )
            if (mySqlRequest.apiSql == 'insert-keep-alive'):
                sqlResult = MySqlInsert(
                    self.__dbConnection,
                ).execute(mySqlRequest)
                service = MySqlInsertKeepAlive(
                    self.__dbConnection,
                    clientSocket,
                )
                self.__services.append(service)
                service.start()
            log.info(f'sqlResult: {sqlResult}')
            if (sqlResult and isinstance(sqlResult, MySqlResult)):
                # log.info(f'response.data: {sqlResult.data}')
                # log.info(f'response.errCount: {sqlResult.errCount}')
                # log.info(f'response.errors: {sqlResult.errors}')
                response = {
                    'data': sqlResult.data,
                    'errCount': sqlResult.errCount,
                    'errDump': sqlResult.errors,
                }
                _jsonData = json.dumps(response)
                _bytes = _jsonData.encode('utf-8')
                clientSocket.sendall(_bytes)
            # else:
            #     log.warning(f'uncnown request: {requestDecoded}')
        else:
            log.info(f'The Api request building error: {mySqlRequest.sql.error}')
        clientSocket.close()

    def __handleClients(self):
        self.__isActive = True
        while not self.__cancel:
            try:
                clientSocket, address = self.__socket.accept()
                log.info(f'clientSocket: {clientSocket}')
                log.info(f'address: {address}')
                threading.Thread(
                    target = self.__registerClient,
                    args = (clientSocket, address)
                ).start()
            except Exception as error:
                log.warning(f'error: {error}')
        self.__isActive = False

    def run(self):
        try:
            self.__socket.bind(self.__address)
            self.__socket.listen()
            log.info('call __handleClients')
            self.__thread1 = threading.Thread(target = self.__handleClients, daemon = self.daemon)
            self.__thread1.start()
            self.__thread1.join()
            log.info('exit')
        except Exception as error:
            log.error(f'error: {error}')
            try:
                self.__socket.shutdown(socket.SHUT_RDWR)
            except:
                pass
        log.info(f'exit')

    def __del__(self):
        if self.__isActive:
            self.cancel()
        log.info('deleted')

    def cancel(self):
        self.__cancel = True
        for service in self.__services:
            service.cancel()
        for client in self.__clients:
            try:
                client.shutdown(socket.SHUT_RD)
            except OSError as error:
                log.error(f'client socket shutdown error:\n\t{type(error)}\n\t{error.args}')
            
            # client.close()
        try:
            # self.__socket.close()
            if (self.__socket):
                self.__socket.shutdown(socket.SHUT_RD)
        except OSError as error:
            log.error(f'socket shutdown error:\n\t{type(error)}\n\t{error.args}')


def json_serial(obj):
    """JSON serializer for objects not serializable by default json code"""

    if isinstance(obj, (datetime, date)):
        return obj.strftime('%Y-%m-%d %H:%M:%S.%f')
    return obj
    # raise TypeError ("Type %s not serializable" % type(obj))



if __name__ == '__main__':
    apiServer: APIServer | None = None
    def haltHandler(signum = None, frame = None):
        log.info(f'Signal handler called with signal: {signum}')
        # time.sleep(1)  #here check if process is done
        log.info('Stoping services...')
        if apiServer:
            apiServer.cancel()
    for sig in [signal.SIGTERM, signal.SIGINT, signal.SIGHUP, signal.SIGQUIT]:
        signal.signal(sig, haltHandler)

    log.info(f'ApiServer creating...')

    apiServer = APIServer(
        address = ('localhost', 8080),
        # address = ('127.0.0.1', 8080),
        mySqlConnection = MySqlConnect(
                config = MySqlConfig(
                    host = '127.0.0.1',
                    database = 'crane_data_server',
                    user = 'crane_data_server',
                    password = '00d0-25e4-*&s2-ccds',
                    converter_class = MySqlConvertToString,
                    raise_on_warnings = False,
                ),
        ),
    )
    log.info(f'ApiServer creating done')
    log.info(f'ApiServer runing...')
    apiServer.run()
    log.info(f'ApiServer runing done')
    apiServer.join()
